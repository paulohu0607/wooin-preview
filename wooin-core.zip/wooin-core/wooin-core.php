<?php
/**
 * Plugin Name: Wooin Core
 * Description: 법률사무소 우인 사이트 기능 — 콘텐츠 유형, 분류, 필드, 역할·권한, 공통정보. 화면 표현은 wooin 테마가 담당합니다.
 * Version: 0.8.3
 * Requires at least: 6.6
 * Requires PHP: 8.0
 * Author: 법률사무소 우인 제작팀
 * License: Proprietary
 * Text Domain: wooin-core
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

const WOOIN_CORE_VERSION = '0.8.3';
const WOOIN_CORE_FILE    = __FILE__;
define( 'WOOIN_CORE_DIR', plugin_dir_path( __FILE__ ) );

require_once __DIR__ . '/includes/capabilities.php';
require_once __DIR__ . '/includes/post-types.php';
require_once __DIR__ . '/includes/taxonomies.php';
require_once __DIR__ . '/includes/case-meta.php';
require_once __DIR__ . '/includes/case-blocks.php';
require_once __DIR__ . '/includes/reviews.php';
require_once __DIR__ . '/includes/boards.php';
require_once __DIR__ . '/includes/faq.php';
require_once __DIR__ . '/includes/setup.php';
require_once __DIR__ . '/includes/site-info.php';
require_once __DIR__ . '/includes/home-fields.php';
require_once __DIR__ . '/includes/home-settings.php';
require_once __DIR__ . '/includes/person-fields.php';
require_once __DIR__ . '/includes/admin-ui.php';
require_once __DIR__ . '/includes/videos.php';
require_once __DIR__ . '/includes/video-blocks.php';

register_activation_hook(
	__FILE__,
	static function () {
		wooin_core_sync_roles();
		wooin_core_register_post_types();
		wooin_core_register_taxonomies();
		wooin_core_register_videos();
		wooin_core_register_news();
		wooin_news_default_terms();
		flush_rewrite_rules();
	}
);

register_deactivation_hook(
	__FILE__,
	static function () {
		wp_clear_scheduled_hook( WOOIN_YT_CRON );
		flush_rewrite_rules();
	}
);

// 플러그인 버전이 바뀌면 역할·권한을 다시 맞춘다.
add_action(
	'admin_init',
	static function () {
		if ( get_option( 'wooin_core_roles_version' ) !== WOOIN_CORE_VERSION ) {
			wooin_core_sync_roles();
		}
	}
);
