// 우인 관리자 화면 — 탭 · 사진/영상 고르기 · 섹션 끌어 옮기기 · 기본 문구 되돌리기 · 저장 안 한 변경 경고
( function ( $ ) {
	// 탭
	var $form = $( '[data-wooin-form]' );
	function showTab( key ) {
		var $panel = $( '[data-wooin-panel="' + key + '"]' );
		if ( ! $panel.length ) {
			return;
		}
		$( '[data-wooin-panel]' ).attr( 'hidden', true );
		$panel.removeAttr( 'hidden' );
		$( '[data-wooin-tab]' ).removeClass( 'is-active' ).filter( '[data-wooin-tab="' + key + '"]' ).addClass( 'is-active' );
		$( '[data-wooin-tab-input]' ).val( key );
	}
	$( document ).on( 'click', '[data-wooin-tab]', function ( e ) {
		e.preventDefault();
		var key = $( this ).data( 'wooin-tab' );
		showTab( key );
		if ( window.history.replaceState ) {
			var url = new URL( window.location.href );
			url.searchParams.set( 'tab', key );
			url.searchParams.delete( 'wooin_notice' );
			window.history.replaceState( null, '', url );
		}
	} );

	// 사진·영상 고르기 (WordPress 미디어 창)
	$( document ).on( 'click', '[data-media-pick]', function () {
		var $box = $( this ).closest( '[data-wooin-media]' );
		var kind = $box.data( 'wooin-media' );
		var frame = wp.media( {
			title: kind === 'video' ? '영상 고르기' : '사진 고르기',
			button: { text: '이것으로 사용' },
			library: { type: kind === 'video' ? 'video' : 'image' },
			multiple: false
		} );
		frame.on( 'select', function () {
			var a = frame.state().get( 'selection' ).first().toJSON();
			$box.find( 'input' ).val( a.id ).trigger( 'change' );
			var src = kind === 'video' ? a.url : ( a.sizes && a.sizes.medium ? a.sizes.medium.url : a.url );
			$box.find( '.wooin-media-preview' ).html( kind === 'video' ? $( '<video muted>' ).attr( 'src', src ) : $( '<img alt="">' ).attr( 'src', src ) );
			$box.find( '[data-media-clear]' ).removeAttr( 'hidden' );
		} );
		frame.open();
	} );
	$( document ).on( 'click', '[data-media-clear]', function () {
		var $box = $( this ).closest( '[data-wooin-media]' );
		$box.find( 'input' ).val( '' ).trigger( 'change' );
		$box.find( '.wooin-media-preview' ).html( '<span>' + ( $box.data( 'wooin-media' ) === 'video' ? '영상 없음' : '기본 사진 사용 중' ) + '</span>' );
		$( this ).attr( 'hidden', true );
	} );

	// 처음 문구로
	$( document ).on( 'click', '[data-reset]', function () {
		var $input = $( this ).closest( '.wooin-field' ).find( 'input[type="text"], textarea' ).first();
		$input.val( $input.data( 'default' ) ).trigger( 'change' );
	} );

	// 섹션 순서
	var $list = $( '[data-wooin-sortable]' );
	function paintOff() {
		$list.children( 'li' ).each( function () {
			$( this ).toggleClass( 'is-off', ! $( this ).find( 'input[type="checkbox"]' ).prop( 'checked' ) );
		} );
	}
	if ( $list.length ) {
		$list.sortable( { handle: '.wooin-handle', axis: 'y', placeholder: 'ui-sortable-placeholder', update: function () { $form.trigger( 'change' ); } } );
		paintOff();
		$list.on( 'change', 'input', paintOff );
		$list.on( 'click', '[data-move]', function () {
			var $li = $( this ).closest( 'li' );
			if ( $( this ).data( 'move' ) < 0 ) {
				$li.prev().before( $li );
			} else {
				$li.next().after( $li );
			}
			$form.trigger( 'change' );
		} );
	}

	// 저장 안 한 변경
	var dirty = false;
	$form.on( 'change input', function () {
		dirty = true;
		$( '[data-wooin-dirty]' ).removeAttr( 'hidden' );
	} );
	$form.on( 'submit', function ( e ) {
		var target = e.originalEvent && e.originalEvent.submitter;
		// 미리보기(새 탭)는 이 화면에 머무르므로 변경 표시를 유지하지 않는다 — 임시저장된 상태
		dirty = false;
		if ( target && target.value === 'preview' ) {
			$( '[data-wooin-dirty]' ).attr( 'hidden', true );
		}
	} );
	$( window ).on( 'beforeunload', function () {
		if ( dirty ) {
			return '저장하지 않은 변경이 있습니다.';
		}
	} );
} )( jQuery );
