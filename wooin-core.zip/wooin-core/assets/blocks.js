// 서버 렌더링 블록을 편집기에서 미리보기로 보여준다 (빌드 도구 없이 동작).
( function ( wp ) {
	var el = wp.element.createElement;
	var ServerSideRender = wp.serverSideRender;
	var useBlockProps = wp.blockEditor.useBlockProps;

	[
		[ 'wooin/video-latest', '유튜브 · 최신 영상' ],
		[ 'wooin/video-channel', '유튜브 · 채널 홈' ],
		[ 'wooin/video-grid', '유튜브 · 재생목록 영상' ],
		[ 'wooin/video-player', '유튜브 · 영상 플레이어' ],
		[ 'wooin/case-table', '해결 사례 표' ],
		[ 'wooin/review-board', '후기 게시판 목록' ],
		[ 'wooin/review-detail', '후기 상세' ],
		[ 'wooin/review-carousel', '후기 캐러셀 (메인)' ],
	].forEach( function ( block ) {
		wp.blocks.registerBlockType( block[ 0 ], {
			apiVersion: 3,
			title: block[ 1 ],
			icon: 'video-alt3',
			category: 'widgets',
			supports: { align: [ 'wide', 'full' ], html: false },
			edit: function ( props ) {
				return el(
					'div',
					useBlockProps(),
					el( ServerSideRender, { block: block[ 0 ], attributes: props.attributes } )
				);
			},
			save: function () {
				return null;
			},
		} );
	} );
} )( window.wp );
