<?php
/**
 * 업무사례 필드 (관리자설계 v0.2 6절, 10절 키 예시 — 확정 전).
 *
 * 1차로 공개 출력 대상 필드만 등록한다. 공개 검수(사실·익명화·공개 권한) 메타는
 * 공개 REST 응답에 노출되지 않는 방식으로 별도 구현한다.
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'wooin_core_register_case_meta' );

function wooin_core_register_case_meta(): void {
	$auth = static function ( $allowed, $meta_key, $post_id ) {
		return current_user_can( 'edit_post', $post_id );
	};

	$fields = array(
		'case_summary'      => array(
			'type'              => 'string',
			'description'       => '사건 요약',
			'default'           => '',
			'sanitize_callback' => 'sanitize_textarea_field',
		),
		'case_track'        => array(
			'type'              => 'string',
			'description'       => '구분 personal(개인) | corporate(법인)',
			'default'           => 'personal',
			'sanitize_callback' => static fn( $v ) => 'corporate' === $v ? 'corporate' : 'personal',
		),
		'client_profile'    => array(
			'type'              => 'string',
			'description'       => '의뢰인 개요 (예: 40대 · 생활비) — 개인 식별 정보 금지',
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		),
		'industry'          => array(
			'type'              => 'string',
			'description'       => '업종 (법인)',
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		),
		'debt_before'       => array(
			'type'              => 'string',
			'description'       => '채무 규모 (화면 표기, 예: 1억 5천만 원)',
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		),
		'debt_result'       => array(
			'type'              => 'string',
			'description'       => '결과 금액 표기 (예: 전액 탕감, 2억 1천만 원 탕감)',
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		),
		'reduction_rate'    => array(
			'type'              => 'string',
			'description'       => '탕감률 (예: 69%)',
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		),
		'repay_period'      => array(
			'type'              => 'string',
			'description'       => '변제 기간 (예: 5년, 파산은 비움)',
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		),
		'result_stage'      => array(
			'type'              => 'string',
			'description'       => '결과 단계 (예: 면책결정, 인가결정, 개시결정)',
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		),
		'decision_date'     => array(
			'type'              => 'string',
			'description'       => '결정일 YYYY-MM-DD (게시일과 별도)',
			'default'           => '',
			'sanitize_callback' => 'wooin_core_sanitize_date',
		),
		// 꺼져 있으면 금액을 출력하지 않는다. 비공개를 0 으로 출력하지 않는다.
		'amount_visibility' => array(
			'type'        => 'boolean',
			'description' => '금액 공개 여부',
			'default'     => false,
		),
	);

	foreach ( $fields as $key => $args ) {
		register_post_meta(
			'wooin_case',
			$key,
			array_merge(
				$args,
				array(
					'single'        => true,
					'show_in_rest'  => true,
					'auth_callback' => $auth,
					'revisions_enabled' => true,
				)
			)
		);
	}
}

function wooin_core_sanitize_date( $value ): string {
	$value = is_string( $value ) ? trim( $value ) : '';
	if ( '' === $value ) {
		return '';
	}
	$date = DateTimeImmutable::createFromFormat( '!Y-m-d', $value );
	return ( $date && $date->format( 'Y-m-d' ) === $value ) ? $value : '';
}
