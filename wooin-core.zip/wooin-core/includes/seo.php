<?php
/**
 * 검색 노출 정리 — 원고 없는 「준비 중」 페이지와 워드프레스 기본 「Sample Page」는
 * 검색 결과(noindex)와 사이트맵에서 뺀다. 원고가 들어가 「준비 중」 패턴이 빠지면 자동으로 다시 노출된다.
 *
 * The SEO Framework 가 켜져 있으면 그 플러그인의 필터로, 꺼져 있으면 워드프레스 기본 기능으로 처리한다.
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

/** 검색에서 뺄 페이지 ID. */
function wooin_seo_hidden_ids(): array {
	static $ids = null;
	if ( null !== $ids ) {
		return $ids;
	}
	$ids = array();
	foreach ( get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => -1, 's' => 'wooin/coming-soon', 'fields' => 'ids' ) ) as $id ) {
		if ( str_contains( (string) get_post_field( 'post_content', $id ), 'wooin/coming-soon' ) ) {
			$ids[] = (int) $id;
		}
	}
	$sample = get_page_by_path( 'sample-page' );
	if ( $sample ) {
		$ids[] = (int) $sample->ID;
	}
	return $ids;
}

// The SEO Framework: 사이트맵에서 제외
add_filter( 'the_seo_framework_sitemap_exclude_ids', static fn( $ids ) => array_merge( (array) $ids, wooin_seo_hidden_ids() ) );

// The SEO Framework: noindex
add_filter(
	'the_seo_framework_robots_meta_array',
	static function ( $meta, $args = null ) {
		$id = null === $args ? ( is_singular() ? get_queried_object_id() : 0 ) : ( empty( $args['tax'] ) && empty( $args['pta'] ) ? (int) ( $args['id'] ?? 0 ) : 0 );
		if ( $id && in_array( (int) $id, wooin_seo_hidden_ids(), true ) ) {
			$meta['noindex'] = 'noindex';
		}
		return $meta;
	},
	10,
	2
);

// SEO 플러그인이 없을 때: 워드프레스 기본 robots · 사이트맵
add_filter(
	'wp_robots',
	static function ( $robots ) {
		if ( is_singular() && in_array( get_queried_object_id(), wooin_seo_hidden_ids(), true ) ) {
			$robots['noindex'] = true;
		}
		return $robots;
	}
);
add_filter(
	'wp_sitemaps_posts_query_args',
	static function ( $args, $post_type ) {
		if ( 'page' === $post_type ) {
			$args['post__not_in'] = array_merge( (array) ( $args['post__not_in'] ?? array() ), wooin_seo_hidden_ids() );
		}
		return $args;
	},
	10,
	2
);
