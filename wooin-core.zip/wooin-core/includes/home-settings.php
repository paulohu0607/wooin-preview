<?php
/**
 * 메인 화면 편집 — 임시저장 / 미리보기 / 게시 / 이전 버전 복원.
 *
 * 저장소 (WordPress 기본 옵션 저장 대신 직접 분리 — CLAUDE.md 「초안/게시 분리는 기본 기능이 해 준다고 가정하지 않는다」):
 * - wooin_home_live    공개 화면이 읽는 게시본
 * - wooin_home_draft   편집 중 임시저장본 (공개 화면에 영향 없음)
 * - wooin_home_history 최근 게시본 10개 (복원용: 값 · 시각 · 게시한 사람)
 * - wooin_home_review  검토 요청 (요청한 사람 · 시각)
 *
 * 권한: wooin_edit_home 임시저장·미리보기·검토 요청 / wooin_publish_home 게시·복원.
 * 미리보기는 ?wooin_preview=1 + wooin_edit_home 권한일 때만 임시저장본을 보여준다.
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

const WOOIN_HOME_LIVE    = 'wooin_home_live';
const WOOIN_HOME_DRAFT   = 'wooin_home_draft';
const WOOIN_HOME_HISTORY = 'wooin_home_history';
const WOOIN_HOME_REVIEW  = 'wooin_home_review';

/* ---------------------------------------------------------------- 값 읽기 */

function wooin_home_is_preview(): bool {
	return ! is_admin() && isset( $_GET['wooin_preview'] ) && current_user_can( 'wooin_edit_home' ); // phpcs:ignore WordPress.Security.NonceVerification
}

function wooin_home_stored( string $which ): array {
	$data = get_option( $which, array() );
	return is_array( $data ) ? $data : array();
}

/** 화면에 쓸 값 묶음 (미리보기면 임시저장본, 아니면 게시본). 빠진 키는 기본값. */
function wooin_home_values( ?string $which = null ): array {
	static $cache = array();
	$which = $which ?? ( wooin_home_is_preview() ? WOOIN_HOME_DRAFT : WOOIN_HOME_LIVE );
	if ( isset( $cache[ $which ] ) ) {
		return $cache[ $which ];
	}
	$stored = wooin_home_stored( $which );
	if ( WOOIN_HOME_DRAFT === $which && ! $stored ) {
		$stored = wooin_home_stored( WOOIN_HOME_LIVE );
	}
	$values = array();
	foreach ( wooin_home_fields() as $key => $f ) {
		$values[ $key ] = array_key_exists( $key, $stored ) ? $stored[ $key ] : $f[2];
	}
	$values['sections'] = wooin_home_normalize_sections( $values['sections'] );
	$cache[ $which ] = $values;
	return $values;
}

/** 값 하나 (테마 패턴에서 사용). */
function wooin_home( string $key ) {
	$values = wooin_home_values();
	$value  = $values[ $key ] ?? '';
	return is_string( $value ) && function_exists( 'wooin_yt_fill' ) ? wooin_yt_fill( $value ) : $value;
}

/** 꾸밈 규칙을 HTML 로: 줄바꿈 → <br>, [강조] → $em, **굵게** → <strong>. */
function wooin_home_format( string $text, string $em = 'mark' ): string {
	$html = esc_html( $text );
	$open = '<' . $em . '>';
	$shut = '</' . strtok( $em, ' ' ) . '>';
	$html = preg_replace( '/\*\*(.+?)\*\*/u', '<strong>$1</strong>', $html );
	$html = preg_replace( '/\[(.+?)\]/u', $open . '$1' . $shut, $html );
	return nl2br( trim( $html ), false );
}

/** 섹션 목록을 [[키, 표시], ...] 로 정리 — 새로 생긴 섹션은 뒤에 표시 상태로 붙인다. */
function wooin_home_normalize_sections( $list ): array {
	$known = wooin_home_sections();
	$out   = array();
	foreach ( (array) $list as $row ) {
		$key = is_array( $row ) ? (string) ( $row[0] ?? '' ) : '';
		if ( isset( $known[ $key ] ) && ! isset( $out[ $key ] ) ) {
			$out[ $key ] = array( $key, ! empty( $row[1] ) );
		}
	}
	foreach ( array_keys( $known ) as $key ) {
		if ( ! isset( $out[ $key ] ) ) {
			$out[ $key ] = array( $key, true );
		}
	}
	return array_values( $out );
}

/** 사진·영상 주소 (없으면 ''). */
function wooin_home_media_url( string $key, string $size = 'full' ): string {
	$id = (int) wooin_home( $key );
	if ( ! $id ) {
		return '';
	}
	$url = wp_attachment_is_image( $id ) ? wp_get_attachment_image_url( $id, $size ) : wp_get_attachment_url( $id );
	return $url ? (string) $url : '';
}

/** 사이트 안 주소는 / 로 시작해도 되게. */
function wooin_home_url( string $key ): string {
	$url = trim( (string) wooin_home( $key ) );
	if ( '' === $url ) {
		return '';
	}
	return str_starts_with( $url, '/' ) ? home_url( $url ) : $url;
}

// 미리보기 화면은 캐시하지 않고, 위에 안내 띠를 띄운다.
add_action(
	'template_redirect',
	static function () {
		if ( wooin_home_is_preview() ) {
			nocache_headers();
			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true );
			}
		}
	}
);
add_action(
	'wp_footer',
	static function () {
		if ( ! wooin_home_is_preview() ) {
			return;
		}
		printf(
			'<div style="position:fixed;left:50%%;bottom:20px;transform:translateX(-50%%);z-index:99999;background:#111;color:#fff;padding:12px 20px;border-radius:999px;font-size:14px;box-shadow:0 8px 30px rgba(0,0,0,.35)">👀 임시저장본 미리보기 — 아직 방문자에게는 보이지 않습니다 · <a style="color:#ffb4b4" href="%s">편집으로 돌아가기</a></div>',
			esc_url( admin_url( 'admin.php?page=wooin-home' ) )
		);
	}
);

/* ---------------------------------------------------------------- 저장 */

function wooin_home_sanitize( array $input ): array {
	$clean = array();
	foreach ( wooin_home_fields() as $key => $f ) {
		$raw = $input[ $key ] ?? '';
		switch ( $f[1] ) {
			case 'sections':
				$rows = array();
				foreach ( (array) ( $input['sections_order'] ?? array() ) as $sec ) {
					$sec    = sanitize_key( $sec );
					$rows[] = array( $sec, ! empty( $input['sections_on'][ $sec ] ) );
				}
				$clean[ $key ] = wooin_home_normalize_sections( $rows );
				break;
			case 'image':
			case 'video':
				$clean[ $key ] = absint( $raw );
				break;
			case 'url':
				$raw           = trim( (string) $raw );
				$clean[ $key ] = str_starts_with( $raw, '/' ) ? '/' . ltrim( sanitize_text_field( $raw ), '/' ) : esc_url_raw( $raw );
				break;
			case 'text':
				$clean[ $key ] = sanitize_text_field( (string) $raw );
				break;
			default: // lines · textarea · list
				$clean[ $key ] = trim( str_replace( "\r", '', sanitize_textarea_field( (string) $raw ) ) );
		}
	}
	return $clean;
}

function wooin_home_publish( array $values, string $note = '' ): void {
	$history = wooin_home_stored( WOOIN_HOME_HISTORY );
	$user    = wp_get_current_user();
	array_unshift(
		$history,
		array(
			'time'   => time(),
			'user'   => $user->display_name,
			'note'   => $note,
			'values' => $values,
		)
	);
	update_option( WOOIN_HOME_HISTORY, array_slice( $history, 0, 10 ), false );
	update_option( WOOIN_HOME_LIVE, $values );
	update_option( WOOIN_HOME_DRAFT, $values, false );
	delete_option( WOOIN_HOME_REVIEW );
	update_option( 'wooin_home_live_meta', array( 'time' => time(), 'user' => $user->display_name ), false );
	// 캐시 플러그인을 쓰면 메인 캐시를 비운다.
	do_action( 'wooin_home_published' );
	if ( function_exists( 'wp_cache_clear_cache' ) ) {
		wp_cache_clear_cache();
	}
}

add_action(
	'admin_post_wooin_home_save',
	static function () {
		if ( ! current_user_can( 'wooin_edit_home' ) ) {
			wp_die( '메인 화면을 편집할 권한이 없습니다.', 403 );
		}
		check_admin_referer( 'wooin_home_save' );
		$do     = sanitize_key( wp_unslash( $_POST['wooin_do'] ?? 'draft' ) );
		$values = wooin_home_sanitize( wp_unslash( (array) ( $_POST['home'] ?? array() ) ) );
		$tab    = sanitize_key( wp_unslash( $_POST['wooin_tab'] ?? '' ) );
		$back   = admin_url( 'admin.php?page=wooin-home' . ( $tab ? '&tab=' . $tab : '' ) );

		update_option( WOOIN_HOME_DRAFT, $values, false );
		update_option( 'wooin_home_draft_meta', array( 'time' => time(), 'user' => wp_get_current_user()->display_name ), false );

		if ( 'publish' === $do ) {
			if ( ! current_user_can( 'wooin_publish_home' ) ) {
				wp_die( '게시 권한이 없습니다. 「검토 요청」을 눌러 주세요.', 403 );
			}
			wooin_home_publish( $values );
			$notice = 'published';
		} elseif ( 'review' === $do ) {
			update_option( WOOIN_HOME_REVIEW, array( 'time' => time(), 'user' => wp_get_current_user()->display_name ), false );
			$notice = 'review';
		} elseif ( 'preview' === $do ) {
			wp_safe_redirect( add_query_arg( 'wooin_preview', '1', home_url( '/' ) ) );
			exit;
		} else {
			$notice = 'saved';
		}
		wp_safe_redirect( add_query_arg( 'wooin_notice', $notice, $back ) );
		exit;
	}
);

// 임시저장 버리기 (게시본으로 되돌림) · 이전 게시본 불러오기
add_action(
	'admin_post_wooin_home_restore',
	static function () {
		check_admin_referer( 'wooin_home_restore' );
		$what = sanitize_key( wp_unslash( $_GET['what'] ?? '' ) );
		if ( 'discard' === $what ) {
			if ( ! current_user_can( 'wooin_edit_home' ) ) {
				wp_die( '권한이 없습니다.', 403 );
			}
			delete_option( WOOIN_HOME_DRAFT );
			delete_option( 'wooin_home_draft_meta' );
			$notice = 'discarded';
		} else {
			if ( ! current_user_can( 'wooin_publish_home' ) ) {
				wp_die( '권한이 없습니다.', 403 );
			}
			$history = wooin_home_stored( WOOIN_HOME_HISTORY );
			$i       = absint( $_GET['i'] ?? 0 );
			if ( ! isset( $history[ $i ] ) ) {
				wp_die( '해당 버전을 찾지 못했습니다.' );
			}
			update_option( WOOIN_HOME_DRAFT, $history[ $i ]['values'], false );
			update_option( 'wooin_home_draft_meta', array( 'time' => time(), 'user' => wp_get_current_user()->display_name ), false );
			$notice = 'restored';
		}
		wp_safe_redirect( add_query_arg( 'wooin_notice', $notice, admin_url( 'admin.php?page=wooin-home' ) ) );
		exit;
	}
);

/** 임시저장본이 게시본과 다른가. */
function wooin_home_has_changes(): bool {
	$draft = wooin_home_stored( WOOIN_HOME_DRAFT );
	return $draft && wooin_home_values( WOOIN_HOME_DRAFT ) !== wooin_home_values( WOOIN_HOME_LIVE );
}

/* ---------------------------------------------------------------- 편집 화면 */

function wooin_home_render_page(): void {
	if ( ! current_user_can( 'wooin_edit_home' ) ) {
		return;
	}
	wp_enqueue_media();
	$values   = wooin_home_values( WOOIN_HOME_DRAFT );
	$tabs     = wooin_home_tabs();
	$current  = sanitize_key( wp_unslash( $_GET['tab'] ?? 'hero' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$current  = isset( $tabs[ $current ] ) ? $current : 'hero';
	$live     = get_option( 'wooin_home_live_meta' );
	$draft    = get_option( 'wooin_home_draft_meta' );
	$review   = get_option( WOOIN_HOME_REVIEW );
	$changed  = wooin_home_has_changes();
	$can_pub  = current_user_can( 'wooin_publish_home' );
	$notice   = sanitize_key( wp_unslash( $_GET['wooin_notice'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$messages = array(
		'saved'     => array( 'success', '임시저장했습니다. 방문자 화면은 아직 그대로입니다. 「미리보기」로 확인한 뒤 게시하세요.' ),
		'published' => array( 'success', '게시했습니다. 지금부터 방문자에게 새 메인 화면이 보입니다.' ),
		'review'    => array( 'info', '검토를 요청했습니다. 검수자가 확인한 뒤 게시합니다.' ),
		'discarded' => array( 'info', '임시저장본을 버리고 현재 게시본으로 되돌렸습니다.' ),
		'restored'  => array( 'info', '선택한 이전 버전을 불러왔습니다. 미리보기로 확인한 뒤 「게시하기」를 누르면 적용됩니다.' ),
	);
	?>
	<div class="wrap wooin-admin">
		<?php wooin_admin_header( '메인 화면 편집', '문구·사진·버튼·섹션 순서를 바꿉니다. 「임시저장」은 방문자 화면에 영향이 없고, 「게시하기」를 눌러야 적용됩니다.' ); ?>

		<?php if ( isset( $messages[ $notice ] ) ) : ?>
			<div class="notice notice-<?php echo esc_attr( $messages[ $notice ][0] ); ?> is-dismissible"><p><?php echo esc_html( $messages[ $notice ][1] ); ?></p></div>
		<?php endif; ?>

		<div class="wooin-status">
			<span class="wooin-status-item"><b>게시본</b> <?php echo is_array( $live ) ? esc_html( wp_date( 'Y-m-d H:i', $live['time'] ) . ' · ' . $live['user'] ) : '기본 시안 문구'; ?></span>
			<?php if ( $changed ) : ?>
				<span class="wooin-status-item is-warn"><b>게시 안 된 변경 있음</b> <?php echo is_array( $draft ) ? esc_html( wp_date( 'm-d H:i', $draft['time'] ) . ' · ' . $draft['user'] ) : ''; ?>
					· <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wooin_home_restore&what=discard' ), 'wooin_home_restore' ) ); ?>" onclick="return confirm('임시저장한 변경을 모두 버리고 현재 게시본으로 되돌릴까요?')">변경 버리기</a></span>
			<?php endif; ?>
			<?php if ( is_array( $review ) ) : ?>
				<span class="wooin-status-item is-info"><b>검토 요청됨</b> <?php echo esc_html( wp_date( 'm-d H:i', $review['time'] ) . ' · ' . $review['user'] ); ?></span>
			<?php endif; ?>
		</div>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wooin-home-form" data-wooin-form>
			<input type="hidden" name="action" value="wooin_home_save">
			<input type="hidden" name="wooin_tab" value="<?php echo esc_attr( $current ); ?>" data-wooin-tab-input>
			<?php wp_nonce_field( 'wooin_home_save' ); ?>

			<div class="wooin-editor">
				<nav class="wooin-tabs" aria-label="편집할 영역">
					<?php foreach ( $tabs as $key => $tab ) : ?>
						<a href="#<?php echo esc_attr( $key ); ?>" class="<?php echo $key === $current ? 'is-active' : ''; ?>" data-wooin-tab="<?php echo esc_attr( $key ); ?>"><span class="dashicons <?php echo esc_attr( $tab['icon'] ); ?>"></span><?php echo esc_html( $tab['label'] ); ?></a>
					<?php endforeach; ?>
					<p class="wooin-tip"><b>글자 꾸미기</b><br>줄바꿈: Enter<br>[대괄호] → 강조색<br>**별표 두 개** → 굵게<br><br><b>자동 숫자</b><br>{구독자} → 유튜브 구독자 수</p>
				</nav>

				<div class="wooin-panels">
					<?php foreach ( $tabs as $key => $tab ) : ?>
					<section class="wooin-panel" data-wooin-panel="<?php echo esc_attr( $key ); ?>" <?php echo $key === $current ? '' : 'hidden'; ?>>
						<h2><?php echo esc_html( $tab['label'] ); ?></h2>
						<p class="wooin-panel-desc"><?php echo esc_html( $tab['desc'] ); ?></p>
						<?php if ( 'sections' === $key ) : ?>
							<?php wooin_home_render_sections( $values['sections'] ); ?>
						<?php endif; ?>
						<?php foreach ( $tab['groups'] as $group => $fields ) : ?>
						<div class="wooin-card">
							<h3><?php echo esc_html( $group ); ?></h3>
							<?php foreach ( $fields as $f ) : ?>
								<?php wooin_admin_field( 'home[' . $f[0] . ']', $f[0], $f[1], $f[2], $values[ $f[0] ], $f[4], $f[3] ); ?>
							<?php endforeach; ?>
						</div>
						<?php endforeach; ?>
					</section>
					<?php endforeach; ?>
				</div>
			</div>

			<div class="wooin-savebar">
				<button type="submit" class="button button-large" name="wooin_do" value="draft">임시저장</button>
				<button type="submit" class="button button-large" name="wooin_do" value="preview" formtarget="_blank">미리보기 ↗</button>
				<?php if ( $can_pub ) : ?>
					<button type="submit" class="button button-primary button-large" name="wooin_do" value="publish" onclick="return confirm('방문자에게 바로 보입니다. 게시할까요?')">게시하기</button>
				<?php else : ?>
					<button type="submit" class="button button-primary button-large" name="wooin_do" value="review">검토 요청</button>
				<?php endif; ?>
				<span class="wooin-savebar-note" data-wooin-dirty hidden>저장하지 않은 변경이 있습니다</span>
			</div>
		</form>

		<?php $history = wooin_home_stored( WOOIN_HOME_HISTORY ); ?>
		<?php if ( $history && $can_pub ) : ?>
		<div class="wooin-card wooin-history">
			<h3>이전 게시 기록 <small>최근 10개</small></h3>
			<table class="widefat striped"><tbody>
				<?php foreach ( $history as $i => $h ) : ?>
				<tr>
					<td><?php echo esc_html( wp_date( 'Y-m-d H:i', $h['time'] ) ); ?></td>
					<td><?php echo esc_html( $h['user'] ); ?><?php echo 0 === $i ? ' <span class="wooin-badge">현재 게시본</span>' : ''; ?></td>
					<td style="text-align:right"><?php if ( $i > 0 ) : ?><a class="button button-small" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wooin_home_restore&what=history&i=' . $i ), 'wooin_home_restore' ) ); ?>" onclick="return confirm('이 버전을 편집 화면으로 불러올까요? 게시하기 전까지 방문자 화면은 그대로입니다.')">이 버전 불러오기</a><?php endif; ?></td>
				</tr>
				<?php endforeach; ?>
			</tbody></table>
		</div>
		<?php endif; ?>
	</div>
	<?php
}

function wooin_home_render_sections( array $sections ): void {
	$labels = wooin_home_sections();
	?>
	<div class="wooin-card">
		<ul class="wooin-sortable" data-wooin-sortable>
			<?php foreach ( $sections as $row ) : ?>
			<li>
				<span class="dashicons dashicons-menu wooin-handle" aria-hidden="true"></span>
				<input type="hidden" name="home[sections_order][]" value="<?php echo esc_attr( $row[0] ); ?>">
				<label class="wooin-switch"><input type="checkbox" name="home[sections_on][<?php echo esc_attr( $row[0] ); ?>]" value="1" <?php checked( $row[1] ); ?>><span></span></label>
				<span class="wooin-sortable-label"><?php echo esc_html( $labels[ $row[0] ] ); ?></span>
				<span class="wooin-sortable-move"><button type="button" class="button button-small" data-move="-1" aria-label="위로">↑</button><button type="button" class="button button-small" data-move="1" aria-label="아래로">↓</button></span>
			</li>
			<?php endforeach; ?>
		</ul>
		<p class="description">스위치를 끄면 그 섹션이 메인에서 숨겨집니다(내용은 지워지지 않습니다). 해결 사례·후기·영상 같은 목록 내용은 각 메뉴에서 관리합니다.</p>
	</div>
	<?php
}
