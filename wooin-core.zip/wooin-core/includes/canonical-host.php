<?php
/**
 * 대표 주소로 모으기 — 옛 임시 주소(○○○.mycafe24.com)나 www 주소로 들어온 방문자를
 * 워드프레스 「설정 › 일반」의 사이트 주소(대표 주소)로 같은 경로 그대로 301 이동한다.
 *
 * - 대표 주소를 바꾸기 전(사이트 주소가 아직 mycafe24 인 동안)에는 아무것도 하지 않는다.
 * - 관리자 화면 · 로그인 · REST · 크론 요청은 건드리지 않는다 (주소 변경 중 잠기지 않게).
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'template_redirect',
	static function () {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || 'GET' !== ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) {
			return;
		}
		$home = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$here = strtolower( (string) preg_replace( '/:\d+$/', '', (string) ( $_SERVER['HTTP_HOST'] ?? '' ) ) );
		if ( '' === $home || '' === $here || $home === $here || str_ends_with( $home, '.mycafe24.com' ) ) {
			return;
		}
		// 옛 임시 주소, 또는 대표 주소의 www 있음/없음 변형만 옮긴다
		$bare = preg_replace( '/^www\./', '', $home );
		if ( ! str_ends_with( $here, '.mycafe24.com' ) && preg_replace( '/^www\./', '', $here ) !== $bare ) {
			return;
		}
		wp_safe_redirect( home_url( (string) wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ) ), 301, 'wooin' );
		exit;
	},
	1
);

