<?php
/**
 * 영상 출력 블록 (서버 렌더링). 모양은 테마 CSS(.wooin-yt-*)가 담당한다.
 *
 * wooin/video-latest   최신(또는 고정) 영상 1개 크게 + 4개
 * wooin/video-picks    메인 섹션 — 관리자가 고른 영상(최대 5개) 좌우 캐러셀, 그 자리에서 재생
 * wooin/video-channel  /videos/ — 유튜브 채널 홈처럼: 채널 고르기(?channel=, 페이지 안에서 전환) → 채널 헤더 → 대표 영상 → 재생목록별 줄
 * wooin/video-grid     재생목록 페이지 — 현재 재생목록 영상 전체
 * wooin/video-player   영상 상세 — 플레이어 + 설명 + 같은 재생목록 영상
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'init',
	static function () {
		wp_register_script(
			'wooin-core-blocks',
			plugins_url( 'assets/blocks.js', WOOIN_CORE_FILE ),
			array( 'wp-blocks', 'wp-element', 'wp-server-side-render', 'wp-block-editor' ),
			WOOIN_CORE_VERSION,
			true
		);

		$blocks = array(
			'video-latest'  => array( '유튜브 · 최신 영상', 'wooin_render_video_latest' ),
			'video-picks'   => array( '유튜브 · 메인 노출 영상 (캐러셀)', 'wooin_render_video_picks' ),
			'video-channel' => array( '유튜브 · 채널 홈', 'wooin_render_video_channel' ),
			'video-grid'    => array( '유튜브 · 재생목록 영상', 'wooin_render_video_grid' ),
			'video-player'  => array( '유튜브 · 영상 플레이어', 'wooin_render_video_player' ),
		);
		foreach ( $blocks as $name => $block ) {
			register_block_type(
				'wooin/' . $name,
				array(
					'title'           => $block[0],
					'category'        => 'widgets',
					'editor_script'   => 'wooin-core-blocks',
					'render_callback' => $block[1],
					'supports'        => array( 'align' => array( 'wide', 'full' ), 'html' => false ),
					'attributes'      => array(
						'align'    => array( 'type' => 'string' ),
						'playlist' => array( 'type' => 'string', 'default' => '' ), // 재생목록 ID 또는 분류 슬러그 (video-grid)
						'limit'    => array( 'type' => 'number', 'default' => 0 ),
					),
				)
			);
		}
	}
);

/* ---------------------------------------------------------------- 공통 조각 */

function wooin_video_id( WP_Post $post ): string {
	return (string) get_post_meta( $post->ID, 'video_id', true );
}

function wooin_video_thumb( string $video_id, string $size = 'hqdefault' ): string {
	return 'https://i.ytimg.com/vi/' . rawurlencode( $video_id ) . '/' . $size . '.jpg';
}

function wooin_video_ago( WP_Post $post ): string {
	return human_time_diff( get_post_time( 'U', true, $post ), time() ) . ' 전';
}

function wooin_video_card( WP_Post $post ): string {
	$id = wooin_video_id( $post );
	return sprintf(
		'<li class="wooin-yt-card"><a href="%1$s"><span class="wooin-yt-thumb"><img src="%2$s" alt="" loading="lazy" decoding="async"></span><span class="wooin-yt-title">%3$s</span><span class="wooin-yt-meta">%4$s</span></a></li>',
		esc_url( get_permalink( $post ) ),
		esc_url( wooin_video_thumb( $id ) ),
		esc_html( get_the_title( $post ) ),
		esc_html( wooin_video_ago( $post ) )
	);
}

function wooin_video_cards( array $posts, string $class = 'wooin-yt-grid' ): string {
	if ( ! $posts ) {
		return '';
	}
	return '<ul class="' . esc_attr( $class ) . '">' . implode( '', array_map( 'wooin_video_card', $posts ) ) . '</ul>';
}

/** 썸네일을 누르면 그 자리에서 재생 (테마 video.js 가 iframe 으로 교체). */
function wooin_video_lite_player( WP_Post $post, string $size = 'maxresdefault' ): string {
	$id = wooin_video_id( $post );
	return sprintf(
		'<button type="button" class="wooin-yt-player" data-wooin-play="%1$s" aria-label="%2$s 재생"><img src="%3$s" alt="" onerror="this.onerror=null;this.src=\'%4$s\'"><span class="wooin-yt-play" aria-hidden="true"></span></button>',
		esc_attr( $id ),
		esc_attr( get_the_title( $post ) ),
		esc_url( wooin_video_thumb( $id, $size ) ),
		esc_url( wooin_video_thumb( $id ) )
	);
}

function wooin_video_empty(): string {
	// 관리 안내는 편집 권한이 있는 사람에게만 — 방문자에게는 빈 자리로 둔다
	if ( ! current_user_can( 'edit_posts' ) ) {
		return '';
	}
	return '<p class="wooin-placeholder">유튜브 동기화가 아직 실행되지 않았습니다. 관리자 › 유튜브 영상 › 유튜브 연동 설정에서 「지금 동기화」를 누르세요.</p>';
}

function wooin_video_wrap( array $attrs, string $html, string $class ): string {
	$wrapper = get_block_wrapper_attributes( array( 'class' => $class ) );
	return '<div ' . $wrapper . '>' . $html . '</div>';
}

/* ---------------------------------------------------------------- 블록 */

function wooin_render_video_latest( array $attrs ): string {
	$posts = wooin_yt_videos( array( 'limit' => 5, 'featured_first' => true ) );
	if ( ! $posts ) {
		return wooin_video_wrap( $attrs, wooin_video_empty(), 'wooin-yt-latest' );
	}

	$main = array_shift( $posts );
	$html = '<div class="wooin-yt-feature">' . wooin_video_lite_player( $main ) .
		'<div class="wooin-yt-feature-meta"><p class="wooin-yt-badge">NEW</p><h3><a href="' . esc_url( get_permalink( $main ) ) . '">' . esc_html( get_the_title( $main ) ) . '</a></h3>' .
		'<p class="wooin-yt-meta">' . esc_html( wooin_video_ago( $main ) ) . '</p></div></div>' .
		wooin_video_cards( $posts, 'wooin-yt-grid is-4' );

	return wooin_video_wrap( $attrs, $html, 'wooin-yt-latest' );
}

function wooin_render_video_picks( array $attrs ): string {
	$posts = wooin_yt_picks( 5 );
	if ( ! $posts ) {
		return wooin_video_wrap( $attrs, wooin_video_empty(), 'wooin-yt-picks' );
	}
	$html = '<div class="wooin-carousel is-videos" data-carousel="videos" role="region" aria-roledescription="carousel" aria-label="추천 영상"><ul class="wooin-carousel-track" tabindex="0">';
	foreach ( $posts as $i => $post ) {
		$html .= sprintf(
			'<li class="wooin-carousel-slide" aria-roledescription="slide" aria-label="%1$s"><div class="wooin-yt-pick">%2$s<a class="wooin-yt-pick-title" href="%3$s">%4$s</a><span class="wooin-yt-meta">%5$s</span></div></li>',
			esc_attr( ( $i + 1 ) . ' / ' . count( $posts ) ),
			wooin_video_lite_player( $post, 'hqdefault' ),
			esc_url( get_permalink( $post ) ),
			esc_html( get_the_title( $post ) ),
			esc_html( get_the_date( 'Y.m.d', $post ) )
		);
	}
	$html .= '</ul><div class="wooin-carousel-dots" aria-hidden="true"></div></div>';
	return wooin_video_wrap( $attrs, $html, 'wooin-yt-picks' );
}

function wooin_render_video_channel( array $attrs ): string {
	$s        = wooin_yt_settings();
	$channels = wooin_yt_all_channels( $s );
	$extras   = array_column( $s['channels'], null, 0 );

	// 채널 전환은 유튜브로 나가지 않고 이 페이지 안에서: /videos/?channel=채널ID · ?channel=all(전체)
	// 주소에 채널이 없으면 설정의 「영상 페이지 첫 화면」 (기본: 추가 채널 첫째 — 법인 위주 채널을 먼저)
	$active = isset( $_GET['channel'] ) ? sanitize_text_field( wp_unslash( $_GET['channel'] ) ) : $s['videos_home']; // phpcs:ignore WordPress.Security.NonceVerification
	if ( 'lead' === $active ) {
		$active = $s['channels'] ? $s['channels'][0][0] : '';
	}
	$active = isset( $channels[ $active ] ) ? $active : '';
	$is_extra = $active && isset( $extras[ $active ] );

	if ( $is_extra ) {
		$name    = $channels[ $active ];
		$url     = $extras[ $active ][2] ? $extras[ $active ][2] : 'https://www.youtube.com/channel/' . $active;
		$subs    = wooin_yt_channel_subs( $active );
		$desc    = '';
	} else {
		$name    = $s['channel_name'] ? $s['channel_name'] : '유튜브 채널';
		$url     = $s['channel_url'];
		$subs    = $active ? wooin_yt_channel_subs( $active ) : wooin_yt_subs_total();
		$desc    = $s['description'];
	}
	$sub   = $url ? add_query_arg( 'sub_confirmation', '1', $url ) : '';
	$first = mb_substr( $name, 0, 1 );
	$base  = get_post_type_archive_link( 'wooin_video' );

	$html = '';
	if ( count( $channels ) > 1 ) {
		$html .= '<nav class="wooin-yt-switch" aria-label="채널 고르기">';
		// 추가 채널(법인 위주)을 먼저, 전체는 맨 뒤
		foreach ( array_merge( array_keys( $extras ), array( $s['channel_id'] ) ) as $cid ) {
			if ( isset( $channels[ $cid ] ) ) {
				$html .= '<a href="' . esc_url( add_query_arg( 'channel', $cid, $base ) ) . '"' . ( $cid === $active ? ' aria-current="page"' : '' ) . '>' . esc_html( $channels[ $cid ] ) . '</a>';
			}
		}
		$html .= '<a href="' . esc_url( add_query_arg( 'channel', 'all', $base ) ) . '"' . ( '' === $active ? ' aria-current="page"' : '' ) . '>전체 영상</a>';
		$html .= '</nav>';
	}

	$html .= '<header class="wooin-yt-channel-head">';
	$html .= '<div class="wooin-yt-banner" aria-hidden="true"></div>';
	$html .= '<div class="wooin-yt-channel-info"><span class="wooin-yt-avatar" aria-hidden="true">' . esc_html( $first ) . '</span><div>';
	$html .= '<h1 class="wooin-yt-channel-name">' . esc_html( $name ) . '</h1>';
	if ( $subs ) {
		$html .= '<p class="wooin-yt-meta">구독자 ' . esc_html( wooin_yt_subs_label( $subs ) ) . '명' . ( '' === $active && 'main' !== $s['subs_mode'] && count( array_filter( array_map( 'wooin_yt_channel_subs', array_keys( $channels ) ) ) ) > 1 ? ' · ' . count( array_filter( array_map( 'wooin_yt_channel_subs', array_keys( $channels ) ) ) ) . '개 채널 합계' : '' ) . '</p>';
	}
	if ( $desc ) {
		$html .= '<p class="wooin-yt-channel-desc">' . esc_html( $desc ) . '</p>';
	}
	if ( $sub ) {
		// 구독은 유튜브에서만 할 수 있으므로 새 탭으로 (홈페이지는 그대로 열려 있음)
		$html .= '<a class="wooin-yt-subscribe" href="' . esc_url( $sub ) . '" target="_blank" rel="noopener">구독하기<span class="screen-reader-text"> (유튜브, 새 창)</span></a>';
	}
	$html .= '</div></div>';

	if ( $is_extra || $active ) {
		$html .= '</header>';
		return wooin_video_wrap( $attrs, $html . wooin_yt_channel_only( $active, $is_extra ), 'wooin-yt-channel' );
	}
	$html .= '<nav class="wooin-yt-tabs" aria-label="채널 메뉴"><a href="#yt-home" aria-current="true">홈</a><a href="#yt-videos">동영상</a><a href="#yt-shorts">Shorts</a><a href="#yt-playlists">재생목록</a></nav>';
	$html .= '</header>';

	$latest = wooin_yt_videos( array( 'limit' => 13, 'featured_first' => true ) );
	if ( ! $latest ) {
		return wooin_video_wrap( $attrs, $html . wooin_video_empty(), 'wooin-yt-channel' );
	}

	// 홈: 대표 영상
	$main  = array_shift( $latest );
	$html .= '<section id="yt-home" class="wooin-yt-feature is-wide">' . wooin_video_lite_player( $main ) .
		'<div class="wooin-yt-feature-meta"><h2><a href="' . esc_url( get_permalink( $main ) ) . '">' . esc_html( get_the_title( $main ) ) . '</a></h2>' .
		'<p class="wooin-yt-meta">' . esc_html( wooin_video_ago( $main ) ) . '</p>' .
		'<p class="wooin-yt-desc">' . esc_html( wp_trim_words( $main->post_content, 60, '…' ) ) . '</p></div></section>';

	// 재생목록별 줄
	$html .= '<div id="yt-playlists">';
	foreach ( wooin_yt_playlists() as $term ) {
		$items = wooin_yt_videos( array( 'limit' => 10, 'playlist' => $term->term_id ) );
		if ( ! $items ) {
			continue;
		}
		$html .= '<section class="wooin-yt-shelf"><div class="wooin-yt-shelf-head"><h2>' . esc_html( $term->name ) . '</h2><a href="' . esc_url( get_term_link( $term ) ) . '">모두 보기</a></div>' .
			wooin_video_cards( $items, 'wooin-yt-row' ) . '</section>';
	}
	$html .= '</div>';

	// Shorts
	$shorts = wooin_yt_videos( array( 'limit' => 10, 'shorts' => true ) );
	if ( $shorts ) {
		$html .= '<section id="yt-shorts" class="wooin-yt-shelf"><div class="wooin-yt-shelf-head"><h2>Shorts</h2></div>' . wooin_video_cards( $shorts, 'wooin-yt-row is-shorts' ) . '</section>';
	}

	// 동영상 (최신순)
	$html .= '<section id="yt-videos" class="wooin-yt-shelf"><div class="wooin-yt-shelf-head"><h2>최신 동영상</h2></div>' . wooin_video_cards( $latest, 'wooin-yt-grid is-4' ) . '</section>';

	return wooin_video_wrap( $attrs, $html, 'wooin-yt-channel' );
}

/** 채널 하나만: 추가 채널은 그 채널 줄(재생목록 분류), 메인 채널은 추가 채널 영상을 뺀 전체. */
function wooin_yt_channel_only( string $channel_id, bool $is_extra ): string {
	$query = array(
		'post_type'      => 'wooin_video',
		'post_status'    => 'publish',
		'posts_per_page' => 60,
		'orderby'        => 'date',
		'order'          => 'DESC',
		'meta_query'     => array( array( 'key' => 'is_short', 'value' => '1', 'compare' => '!=' ) ),
	);
	$extra_terms = array();
	foreach ( wooin_yt_settings()['channels'] as $ch ) {
		$t = get_term_by( 'slug', sanitize_title( $ch[0] ), 'wooin_playlist' );
		if ( $t ) {
			$extra_terms[ $ch[0] ] = $t->term_id;
		}
	}
	if ( $is_extra ) {
		$query['tax_query'] = array( array( 'taxonomy' => 'wooin_playlist', 'terms' => $extra_terms[ $channel_id ] ?? -1 ) );
	} elseif ( $extra_terms ) {
		$query['tax_query'] = array( array( 'taxonomy' => 'wooin_playlist', 'terms' => array_values( $extra_terms ), 'operator' => 'NOT IN' ) );
	}
	$posts  = get_posts( $query );
	$query['meta_query'][0]['compare'] = '=';
	$query['posts_per_page']           = 20;
	$shorts = get_posts( $query );
	$tail   = $shorts ? '<section class="wooin-yt-shelf"><div class="wooin-yt-shelf-head"><h2>Shorts</h2></div>' . wooin_video_cards( $shorts, 'wooin-yt-row is-shorts' ) . '</section>' : '';
	if ( ! $posts ) {
		return $shorts ? $tail : wooin_video_empty();
	}
	$main = array_shift( $posts );
	$html = '<section class="wooin-yt-feature is-wide">' . wooin_video_lite_player( $main ) .
		'<div class="wooin-yt-feature-meta"><h2><a href="' . esc_url( get_permalink( $main ) ) . '">' . esc_html( get_the_title( $main ) ) . '</a></h2>' .
		'<p class="wooin-yt-meta">' . esc_html( wooin_video_ago( $main ) ) . '</p>' .
		'<p class="wooin-yt-desc">' . esc_html( wp_trim_words( $main->post_content, 60, '…' ) ) . '</p></div></section>';
	if ( $posts ) {
		$html .= '<section class="wooin-yt-shelf"><div class="wooin-yt-shelf-head"><h2>최신 동영상</h2></div>' . wooin_video_cards( $posts, 'wooin-yt-grid is-4' ) . '</section>';
	}
	return $html . $tail;
}

function wooin_render_video_grid( array $attrs ): string {
	$term = get_queried_object();
	$args = array( 'limit' => ! empty( $attrs['limit'] ) ? (int) $attrs['limit'] : 60 );
	if ( ! empty( $attrs['playlist'] ) ) {
		// 지정한 재생목록 (업무분야 상세의 「관련 영상」 등)
		$picked = get_term_by( 'slug', sanitize_title( $attrs['playlist'] ), 'wooin_playlist' );
		$args['playlist'] = $picked ? $picked->term_id : -1;
	} elseif ( $term instanceof WP_Term && 'wooin_playlist' === $term->taxonomy ) {
		$args['playlist'] = $term->term_id;
	}
	$posts = wooin_yt_videos( $args );
	if ( ! $posts && ! empty( $attrs['playlist'] ) ) {
		// 지정한 재생목록이 아직 동기화되지 않았으면 최신 영상으로 대신 채운다
		unset( $args['playlist'] );
		$posts = wooin_yt_videos( $args );
	}
	return wooin_video_wrap( $attrs, $posts ? wooin_video_cards( $posts, 'wooin-yt-grid is-4' ) : wooin_video_empty(), 'wooin-yt-list' );
}

function wooin_render_video_player( array $attrs ): string {
	$post = get_post();
	if ( ! $post || 'wooin_video' !== $post->post_type ) {
		return '';
	}

	$id    = wooin_video_id( $post );
	$html  = '<div class="wooin-yt-embed"><iframe src="' . esc_url( 'https://www.youtube-nocookie.com/embed/' . rawurlencode( $id ) . '?rel=0' ) . '" title="' . esc_attr( get_the_title( $post ) ) . '" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen loading="lazy"></iframe></div>';
	$html .= '<h1 class="wooin-yt-watch-title">' . esc_html( get_the_title( $post ) ) . '</h1>';
	$html .= '<p class="wooin-yt-meta">' . esc_html( get_the_date( 'Y.m.d', $post ) ) . ' · <a href="' . esc_url( 'https://www.youtube.com/watch?v=' . rawurlencode( $id ) ) . '" target="_blank" rel="noopener">유튜브에서 보기</a></p>';
	if ( $post->post_content ) {
		$html .= '<div class="wooin-yt-desc-box">' . wpautop( esc_html( $post->post_content ) ) . '</div>';
	}

	$terms   = wp_get_post_terms( $post->ID, 'wooin_playlist', array( 'fields' => 'ids' ) );
	$related = wooin_yt_videos( array( 'limit' => 9, 'playlist' => $terms ? $terms[0] : 0 ) );
	$related = array_filter( $related, static fn( $p ) => $p->ID !== $post->ID );
	if ( $related ) {
		$html .= '<section class="wooin-yt-shelf"><div class="wooin-yt-shelf-head"><h2>관련 영상</h2></div>' . wooin_video_cards( array_slice( $related, 0, 8 ), 'wooin-yt-grid is-4' ) . '</section>';
	}

	return wooin_video_wrap( $attrs, $html, 'wooin-yt-watch' );
}
