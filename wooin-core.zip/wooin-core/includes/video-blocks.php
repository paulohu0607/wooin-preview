<?php
/**
 * 영상 출력 블록 (서버 렌더링). 모양은 테마 CSS(.wooin-yt-*)가 담당한다.
 *
 * wooin/video-latest   메인 섹션 — 최신(또는 고정) 영상 1개 크게 + 4개
 * wooin/video-channel  /videos/ — 유튜브 채널 홈처럼: 채널 헤더 → 대표 영상 → 재생목록별 줄
 * wooin/video-grid     재생목록 페이지 — 현재 재생목록 영상 전체
 * wooin/video-player   영상 상세 — 플레이어 + 설명 + 같은 재생목록 영상
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'init',
	static function () {
		wp_register_script(
			'wooin-core-blocks',
			plugins_url( 'assets/blocks.js', WOOIN_CORE_FILE ),
			array( 'wp-blocks', 'wp-element', 'wp-server-side-render', 'wp-block-editor' ),
			WOOIN_CORE_VERSION,
			true
		);

		$blocks = array(
			'video-latest'  => array( '유튜브 · 최신 영상', 'wooin_render_video_latest' ),
			'video-channel' => array( '유튜브 · 채널 홈', 'wooin_render_video_channel' ),
			'video-grid'    => array( '유튜브 · 재생목록 영상', 'wooin_render_video_grid' ),
			'video-player'  => array( '유튜브 · 영상 플레이어', 'wooin_render_video_player' ),
		);
		foreach ( $blocks as $name => $block ) {
			register_block_type(
				'wooin/' . $name,
				array(
					'title'           => $block[0],
					'category'        => 'widgets',
					'editor_script'   => 'wooin-core-blocks',
					'render_callback' => $block[1],
					'supports'        => array( 'align' => array( 'wide', 'full' ), 'html' => false ),
					'attributes'      => array(
						'align'    => array( 'type' => 'string' ),
						'playlist' => array( 'type' => 'string', 'default' => '' ), // 재생목록 ID 또는 분류 슬러그 (video-grid)
						'limit'    => array( 'type' => 'number', 'default' => 0 ),
					),
				)
			);
		}
	}
);

/* ---------------------------------------------------------------- 공통 조각 */

function wooin_video_id( WP_Post $post ): string {
	return (string) get_post_meta( $post->ID, 'video_id', true );
}

function wooin_video_thumb( string $video_id, string $size = 'hqdefault' ): string {
	return 'https://i.ytimg.com/vi/' . rawurlencode( $video_id ) . '/' . $size . '.jpg';
}

function wooin_video_ago( WP_Post $post ): string {
	return human_time_diff( get_post_time( 'U', true, $post ), time() ) . ' 전';
}

function wooin_video_card( WP_Post $post ): string {
	$id = wooin_video_id( $post );
	return sprintf(
		'<li class="wooin-yt-card"><a href="%1$s"><span class="wooin-yt-thumb"><img src="%2$s" alt="" loading="lazy" decoding="async"></span><span class="wooin-yt-title">%3$s</span><span class="wooin-yt-meta">%4$s</span></a></li>',
		esc_url( get_permalink( $post ) ),
		esc_url( wooin_video_thumb( $id ) ),
		esc_html( get_the_title( $post ) ),
		esc_html( wooin_video_ago( $post ) )
	);
}

function wooin_video_cards( array $posts, string $class = 'wooin-yt-grid' ): string {
	if ( ! $posts ) {
		return '';
	}
	return '<ul class="' . esc_attr( $class ) . '">' . implode( '', array_map( 'wooin_video_card', $posts ) ) . '</ul>';
}

/** 썸네일을 누르면 그 자리에서 재생 (테마 video.js 가 iframe 으로 교체). */
function wooin_video_lite_player( WP_Post $post, string $size = 'maxresdefault' ): string {
	$id = wooin_video_id( $post );
	return sprintf(
		'<button type="button" class="wooin-yt-player" data-wooin-play="%1$s" aria-label="%2$s 재생"><img src="%3$s" alt="" onerror="this.onerror=null;this.src=\'%4$s\'"><span class="wooin-yt-play" aria-hidden="true"></span></button>',
		esc_attr( $id ),
		esc_attr( get_the_title( $post ) ),
		esc_url( wooin_video_thumb( $id, $size ) ),
		esc_url( wooin_video_thumb( $id ) )
	);
}

function wooin_video_empty(): string {
	return '<p class="wooin-placeholder">유튜브 동기화가 아직 실행되지 않았습니다. 관리자 › 유튜브 영상 › 유튜브 연동 설정에서 「지금 동기화」를 누르세요.</p>';
}

function wooin_video_wrap( array $attrs, string $html, string $class ): string {
	$wrapper = get_block_wrapper_attributes( array( 'class' => $class ) );
	return '<div ' . $wrapper . '>' . $html . '</div>';
}

/* ---------------------------------------------------------------- 블록 */

function wooin_render_video_latest( array $attrs ): string {
	$posts = wooin_yt_videos( array( 'limit' => 5, 'featured_first' => true ) );
	if ( ! $posts ) {
		return wooin_video_wrap( $attrs, wooin_video_empty(), 'wooin-yt-latest' );
	}

	$main = array_shift( $posts );
	$html = '<div class="wooin-yt-feature">' . wooin_video_lite_player( $main ) .
		'<div class="wooin-yt-feature-meta"><p class="wooin-yt-badge">NEW</p><h3><a href="' . esc_url( get_permalink( $main ) ) . '">' . esc_html( get_the_title( $main ) ) . '</a></h3>' .
		'<p class="wooin-yt-meta">' . esc_html( wooin_video_ago( $main ) ) . '</p></div></div>' .
		wooin_video_cards( $posts, 'wooin-yt-grid is-4' );

	return wooin_video_wrap( $attrs, $html, 'wooin-yt-latest' );
}

function wooin_render_video_channel( array $attrs ): string {
	$s     = wooin_yt_settings();
	$sub   = $s['channel_url'] ? add_query_arg( 'sub_confirmation', '1', $s['channel_url'] ) : '';
	$name  = $s['channel_name'] ? $s['channel_name'] : '유튜브 채널';
	$first = mb_substr( $name, 0, 1 );

	$html  = '<header class="wooin-yt-channel-head">';
	$html .= '<div class="wooin-yt-banner" aria-hidden="true"></div>';
	$html .= '<div class="wooin-yt-channel-info"><span class="wooin-yt-avatar" aria-hidden="true">' . esc_html( $first ) . '</span><div>';
	$html .= '<h1 class="wooin-yt-channel-name">' . esc_html( $name ) . '</h1>';
	$html .= '<p class="wooin-yt-meta">' . esc_html( $s['subscribers'] ) . '</p>';
	if ( $s['description'] ) {
		$html .= '<p class="wooin-yt-channel-desc">' . esc_html( $s['description'] ) . '</p>';
	}
	if ( $sub ) {
		$html .= '<a class="wooin-yt-subscribe" href="' . esc_url( $sub ) . '" target="_blank" rel="noopener">구독하기</a>';
	}
	$html .= '</div></div>';
	$html .= '<nav class="wooin-yt-tabs" aria-label="채널 메뉴"><a href="#yt-home" aria-current="true">홈</a><a href="#yt-videos">동영상</a><a href="#yt-shorts">Shorts</a><a href="#yt-playlists">재생목록</a></nav>';
	$html .= '</header>';

	$latest = wooin_yt_videos( array( 'limit' => 13, 'featured_first' => true ) );
	if ( ! $latest ) {
		return wooin_video_wrap( $attrs, $html . wooin_video_empty(), 'wooin-yt-channel' );
	}

	// 홈: 대표 영상
	$main  = array_shift( $latest );
	$html .= '<section id="yt-home" class="wooin-yt-feature is-wide">' . wooin_video_lite_player( $main ) .
		'<div class="wooin-yt-feature-meta"><h2><a href="' . esc_url( get_permalink( $main ) ) . '">' . esc_html( get_the_title( $main ) ) . '</a></h2>' .
		'<p class="wooin-yt-meta">' . esc_html( wooin_video_ago( $main ) ) . '</p>' .
		'<p class="wooin-yt-desc">' . esc_html( wp_trim_words( $main->post_content, 60, '…' ) ) . '</p></div></section>';

	// 재생목록별 줄
	$html .= '<div id="yt-playlists">';
	foreach ( wooin_yt_playlists() as $term ) {
		$items = wooin_yt_videos( array( 'limit' => 10, 'playlist' => $term->term_id ) );
		if ( ! $items ) {
			continue;
		}
		$html .= '<section class="wooin-yt-shelf"><div class="wooin-yt-shelf-head"><h2>' . esc_html( $term->name ) . '</h2><a href="' . esc_url( get_term_link( $term ) ) . '">모두 보기</a></div>' .
			wooin_video_cards( $items, 'wooin-yt-row' ) . '</section>';
	}
	$html .= '</div>';

	// Shorts
	$shorts = wooin_yt_videos( array( 'limit' => 10, 'shorts' => true ) );
	if ( $shorts ) {
		$html .= '<section id="yt-shorts" class="wooin-yt-shelf"><div class="wooin-yt-shelf-head"><h2>Shorts</h2></div>' . wooin_video_cards( $shorts, 'wooin-yt-row is-shorts' ) . '</section>';
	}

	// 동영상 (최신순)
	$html .= '<section id="yt-videos" class="wooin-yt-shelf"><div class="wooin-yt-shelf-head"><h2>최신 동영상</h2></div>' . wooin_video_cards( $latest, 'wooin-yt-grid is-4' ) . '</section>';

	return wooin_video_wrap( $attrs, $html, 'wooin-yt-channel' );
}

function wooin_render_video_grid( array $attrs ): string {
	$term = get_queried_object();
	$args = array( 'limit' => ! empty( $attrs['limit'] ) ? (int) $attrs['limit'] : 60 );
	if ( ! empty( $attrs['playlist'] ) ) {
		// 지정한 재생목록 (업무분야 상세의 「관련 영상」 등)
		$picked = get_term_by( 'slug', sanitize_title( $attrs['playlist'] ), 'wooin_playlist' );
		$args['playlist'] = $picked ? $picked->term_id : -1;
	} elseif ( $term instanceof WP_Term && 'wooin_playlist' === $term->taxonomy ) {
		$args['playlist'] = $term->term_id;
	}
	$posts = wooin_yt_videos( $args );
	if ( ! $posts && ! empty( $attrs['playlist'] ) ) {
		// 지정한 재생목록이 아직 동기화되지 않았으면 최신 영상으로 대신 채운다
		unset( $args['playlist'] );
		$posts = wooin_yt_videos( $args );
	}
	return wooin_video_wrap( $attrs, $posts ? wooin_video_cards( $posts, 'wooin-yt-grid is-4' ) : wooin_video_empty(), 'wooin-yt-list' );
}

function wooin_render_video_player( array $attrs ): string {
	$post = get_post();
	if ( ! $post || 'wooin_video' !== $post->post_type ) {
		return '';
	}

	$id    = wooin_video_id( $post );
	$html  = '<div class="wooin-yt-embed"><iframe src="' . esc_url( 'https://www.youtube-nocookie.com/embed/' . rawurlencode( $id ) . '?rel=0' ) . '" title="' . esc_attr( get_the_title( $post ) ) . '" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen loading="lazy"></iframe></div>';
	$html .= '<h1 class="wooin-yt-watch-title">' . esc_html( get_the_title( $post ) ) . '</h1>';
	$html .= '<p class="wooin-yt-meta">' . esc_html( get_the_date( 'Y.m.d', $post ) ) . ' · <a href="' . esc_url( 'https://www.youtube.com/watch?v=' . rawurlencode( $id ) ) . '" target="_blank" rel="noopener">유튜브에서 보기</a></p>';
	if ( $post->post_content ) {
		$html .= '<div class="wooin-yt-desc-box">' . wpautop( esc_html( $post->post_content ) ) . '</div>';
	}

	$terms   = wp_get_post_terms( $post->ID, 'wooin_playlist', array( 'fields' => 'ids' ) );
	$related = wooin_yt_videos( array( 'limit' => 9, 'playlist' => $terms ? $terms[0] : 0 ) );
	$related = array_filter( $related, static fn( $p ) => $p->ID !== $post->ID );
	if ( $related ) {
		$html .= '<section class="wooin-yt-shelf"><div class="wooin-yt-shelf-head"><h2>관련 영상</h2></div>' . wooin_video_cards( array_slice( $related, 0, 8 ), 'wooin-yt-grid is-4' ) . '</section>';
	}

	return wooin_video_wrap( $attrs, $html, 'wooin-yt-watch' );
}
