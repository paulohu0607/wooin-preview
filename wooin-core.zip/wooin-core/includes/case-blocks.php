<?php
/**
 * 해결 사례 표 블록 (서버 렌더링) — wooin/case-table
 *
 * 속성
 *   track : both(개인/법인 탭) | personal | corporate
 *   area  : 분야 분류 슬러그로 좁히기 (예: personal-rehabilitation) — 업무분야 상세에서 사용
 *   limit : 표당 최대 건수
 *
 * 데이터는 wooin_case 글과 메타(case_track, client_profile, industry, debt_before, debt_result, reduction_rate, repay_period, result_stage).
 * 등록된 사례가 없으면 표 구조만 「등록 예정」으로 보여준다(가상 사례를 만들지 않음). 모양은 테마 CSS(.wooin-case-table).
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'init',
	static function () {
		register_block_type(
			'wooin/case-table',
			array(
				'title'           => '해결 사례 표',
				'category'        => 'widgets',
				'editor_script'   => 'wooin-core-blocks',
				'render_callback' => 'wooin_render_case_table',
				'supports'        => array( 'html' => false, 'align' => array( 'wide', 'full' ) ),
				'attributes'      => array(
					'track' => array( 'type' => 'string', 'default' => 'both' ),
					'area'  => array( 'type' => 'string', 'default' => '' ),
					'limit' => array( 'type' => 'number', 'default' => 6 ),
				),
			)
		);
	}
);

/**
 * @return WP_Post[]
 */
function wooin_cases( string $track, string $area = '', int $limit = 6 ): array {
	$args = array(
		'post_type'      => 'wooin_case',
		'post_status'    => 'publish',
		'posts_per_page' => $limit,
		'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
		'no_found_rows'  => true,
		'meta_query'     => array( array( 'key' => 'case_track', 'value' => $track ) ),
	);
	if ( $area ) {
		$args['tax_query'] = array( array( 'taxonomy' => 'wooin_practice_area', 'field' => 'slug', 'terms' => $area ) );
	}
	return get_posts( $args );
}

function wooin_case_area_name( WP_Post $post ): string {
	$terms = get_the_terms( $post, 'wooin_practice_area' );
	return ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
}

function wooin_case_rows( array $posts, string $track ): string {
	$html = '';
	foreach ( $posts as $post ) {
		$m    = static fn( $k ) => (string) get_post_meta( $post->ID, $k, true );
		$who  = 'corporate' === $track ? $m( 'industry' ) : $m( 'client_profile' );
		$note = array_filter( array( $m( 'reduction_rate' ) ? '탕감률 ' . $m( 'reduction_rate' ) : '', $m( 'repay_period' ) ? '변제 ' . $m( 'repay_period' ) : '', $m( 'result_stage' ) ) );
		$html .= sprintf(
			'<tr><td><span class="wooin-chip%1$s">%2$s</span></td><td>%3$s</td><td>%4$s</td><td><b>%5$s</b></td><td class="is-muted">%6$s</td><td><a class="wooin-case-link" href="%7$s" aria-label="%8$s 자세히 보기">자세히 →</a></td></tr>',
			'corporate' === $track ? ' is-dark' : '',
			esc_html( wooin_case_area_name( $post ) ),
			esc_html( $who ),
			esc_html( $m( 'debt_before' ) ),
			esc_html( $m( 'debt_result' ) ),
			esc_html( implode( ' · ', $note ) ),
			esc_url( get_permalink( $post ) ),
			esc_attr( get_the_title( $post ) )
		);
	}
	return $html;
}

function wooin_case_placeholder_rows( string $track ): string {
	$rows = 'corporate' === $track
		? array( array( '법인회생', '제조업' ), array( '법인회생', '건설업' ), array( '법인파산', '유통업' ) )
		: array( array( '개인회생', '' ), array( '개인파산', '' ) );
	$html = '';
	foreach ( $rows as $r ) {
		$html .= sprintf(
			'<tr class="is-placeholder"><td><span class="wooin-chip%s">%s</span></td><td>%s</td><td>약 ○○억 원</td><td><b>—</b></td><td class="is-muted">실제 사례 등록 예정</td><td></td></tr>',
			'corporate' === $track ? ' is-dark' : '',
			esc_html( $r[0] ),
			esc_html( $r[1] ? $r[1] : '—' )
		);
	}
	return $html;
}

function wooin_case_table_html( string $track, string $area, int $limit ): string {
	$posts = wooin_cases( $track, $area, $limit );
	$head  = 'corporate' === $track ? '업종' : '연령 · 사유';
	$body  = $posts ? wooin_case_rows( $posts, $track ) : wooin_case_placeholder_rows( $track );
	return '<div class="wooin-case-table" tabindex="0"><table><thead><tr><th scope="col">구분</th><th scope="col">' . esc_html( $head ) . '</th><th scope="col">채무 규모</th><th scope="col">결과</th><th scope="col">탕감률 · 비고</th><th scope="col"><span class="screen-reader-text">상세</span></th></tr></thead><tbody>' . $body . '</tbody></table></div>';
}

function wooin_render_case_table( array $attrs ): string {
	$track = in_array( $attrs['track'] ?? 'both', array( 'personal', 'corporate' ), true ) ? $attrs['track'] : 'both';
	$area  = sanitize_title( $attrs['area'] ?? '' );
	$limit = max( 1, min( 50, (int) ( $attrs['limit'] ?? 6 ) ) );

	if ( 'both' !== $track ) {
		$html = wooin_case_table_html( $track, $area, $limit );
	} else {
		$uid  = wp_unique_id( 'cases-' );
		$html = '<div class="wooin-tabs" data-wooin-tabs><div class="wooin-tab-list" role="tablist" aria-label="사례 구분">' .
			'<button type="button" role="tab" aria-selected="true" aria-controls="' . $uid . '-corporate" id="' . $uid . '-tab-corporate" data-track="corporate">법인회생 · 파산</button>' .
			'<button type="button" role="tab" aria-selected="false" aria-controls="' . $uid . '-personal" id="' . $uid . '-tab-personal" data-track="personal" tabindex="-1">개인회생 · 파산</button></div>' .
			'<div role="tabpanel" id="' . $uid . '-corporate" aria-labelledby="' . $uid . '-tab-corporate">' . wooin_case_table_html( 'corporate', $area, $limit ) . '</div>' .
			'<div role="tabpanel" id="' . $uid . '-personal" aria-labelledby="' . $uid . '-tab-personal" hidden>' . wooin_case_table_html( 'personal', $area, $limit ) . '</div></div>';
	}

	return '<div ' . get_block_wrapper_attributes( array( 'class' => 'wooin-cases' ) ) . '>' . $html . '</div>';
}
