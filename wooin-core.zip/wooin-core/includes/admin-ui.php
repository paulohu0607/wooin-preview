<?php
/**
 * 관리자 화면 — 「우인 홈페이지」 메뉴 · 운영 홈 · 메뉴 정리 · 추천 플러그인 · 로그인 화면.
 *
 * 목표: 개발자가 아닌 운영자가 WordPress 를 몰라도 「무엇을 하려는지」에서 바로 시작하게 한다.
 * 권한은 각 화면·처리에서 capability 로 검사한다 (메뉴 숨김에 의존하지 않음).
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

/* ---------------------------------------------------------------- 메뉴 */

add_action(
	'admin_menu',
	static function () {
		add_menu_page( '우인 홈페이지', '우인 홈페이지', 'read', 'wooin', 'wooin_admin_render_home', 'dashicons-admin-home', 2 );
		add_submenu_page( 'wooin', '운영 홈', '운영 홈', 'read', 'wooin', 'wooin_admin_render_home' );
		add_submenu_page( 'wooin', '메인 화면 편집', '메인 화면 편집', 'wooin_edit_home', 'wooin-home', 'wooin_home_render_page' );
		add_submenu_page( 'wooin', '공통정보 (전화·주소)', '공통정보 (전화·주소)', 'wooin_manage_site_info', 'wooin-site-info', 'wooin_core_render_site_info_page' );
		add_submenu_page( 'wooin', '추천 플러그인', '추천 플러그인', 'install_plugins', 'wooin-plugins', 'wooin_admin_render_plugins' );

		// 기본 「글」은 칼럼으로 쓴다
		global $menu, $submenu;
		foreach ( (array) $menu as $i => $item ) {
			if ( 'edit.php' === ( $item[2] ?? '' ) ) {
				$menu[ $i ][0] = '전문가 칼럼'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
			}
		}
		if ( isset( $submenu['edit.php'][5] ) ) {
			$submenu['edit.php'][5][0]  = '전체 칼럼'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
			$submenu['edit.php'][10][0] = '칼럼 쓰기'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		}

		// 쓰지 않는 메뉴: 댓글 (사이트에 댓글 기능 없음)
		remove_menu_page( 'edit-comments.php' );
	},
	9
);

// 관리자 메뉴 순서: 우인 홈페이지 → 콘텐츠(자주 쓰는 순) → 미디어 → 나머지
add_filter( 'custom_menu_order', '__return_true' );
add_filter(
	'menu_order',
	static function ( array $order ): array {
		$first = array(
			'wooin',
			'wooin-consult',
			'separator1',
			'edit.php?post_type=wooin_case',
			'edit.php?post_type=wooin_review',
			'edit.php?post_type=wooin_news',
			'edit.php',
			'edit.php?post_type=wooin_video',
			'edit.php?post_type=wooin_faq',
			'edit.php?post_type=wooin_service',
			'edit.php?post_type=wooin_person',
			'upload.php',
			'edit.php?post_type=page',
			'separator2',
		);
		$rest = array_values( array_diff( $order, $first ) );
		return array_merge( array_values( array_intersect( $first, $order ) ), $rest );
	}
);

// WordPress 기본 대시보드 대신 운영 홈으로 (기본 화면은 ?wp=1 로 볼 수 있음)
add_action(
	'load-index.php',
	static function () {
		if ( empty( $_GET['wp'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			wp_safe_redirect( admin_url( 'admin.php?page=wooin' ) );
			exit;
		}
	}
);
add_filter(
	'login_redirect',
	static function ( $to, $requested, $user ) {
		if ( $user instanceof WP_User && ( ! $requested || admin_url() === $requested || str_ends_with( (string) $requested, '/wp-admin/' ) ) ) {
			return admin_url( 'admin.php?page=wooin' );
		}
		return $to;
	},
	10,
	3
);

// 상단 바 정리
add_action(
	'admin_bar_menu',
	static function ( WP_Admin_Bar $bar ) {
		$bar->remove_node( 'wp-logo' );
		$bar->remove_node( 'comments' );
		if ( current_user_can( 'wooin_edit_home' ) ) {
			$bar->add_node(
				array(
					'id'    => 'wooin-home-edit',
					'title' => '✎ 메인 화면 편집',
					'href'  => admin_url( 'admin.php?page=wooin-home' ),
				)
			);
		}
	},
	99
);

add_filter( 'admin_footer_text', static fn() => '법률사무소 우인 홈페이지 관리자 · 막히는 부분은 제작팀에 문의하세요.' );

/* ---------------------------------------------------------------- 공통 화면 요소 */

add_action(
	'admin_enqueue_scripts',
	static function () {
		wp_enqueue_style( 'wooin-admin', plugins_url( 'assets/admin.css', WOOIN_CORE_FILE ), array(), WOOIN_CORE_VERSION );
		$screen = get_current_screen();
		if ( ! $screen || ( ! str_contains( $screen->id, 'wooin' ) && 'wooin_person' !== $screen->post_type ) ) {
			return;
		}
		if ( 'wooin_person' === $screen->post_type ) {
			wp_enqueue_media();
		}
		wp_enqueue_script( 'wooin-admin', plugins_url( 'assets/admin.js', WOOIN_CORE_FILE ), array( 'jquery', 'jquery-ui-sortable' ), WOOIN_CORE_VERSION, true );
	}
);

function wooin_admin_header( string $title, string $desc = '' ): void {
	printf( '<div class="wooin-head"><h1>%s</h1>%s</div>', esc_html( $title ), $desc ? '<p>' . esc_html( $desc ) . '</p>' : '' );
}

/**
 * 입력 칸 하나.
 *
 * @param string $name  form name.
 * @param string $id    고유 키.
 * @param string $label 이름.
 * @param string $type  text · lines · textarea · list · url · image · video.
 * @param mixed  $value 현재 값.
 * @param string $help  도움말.
 * @param mixed  $def   기본값 (되돌리기 버튼용).
 */
function wooin_admin_field( string $name, string $id, string $label, string $type, $value, string $help = '', $def = '' ): void {
	$fid = 'wooin-f-' . $id;
	echo '<div class="wooin-field is-' . esc_attr( $type ) . '">';
	printf( '<label for="%s">%s</label>', esc_attr( $fid ), esc_html( $label ) );

	if ( 'image' === $type || 'video' === $type ) {
		$id_val = absint( $value );
		$src    = $id_val ? ( 'image' === $type ? wp_get_attachment_image_url( $id_val, 'medium' ) : wp_get_attachment_url( $id_val ) ) : '';
		printf(
			'<div class="wooin-media" data-wooin-media="%1$s"><input type="hidden" id="%2$s" name="%3$s" value="%4$s"><div class="wooin-media-preview">%5$s</div><button type="button" class="button" data-media-pick>%6$s</button> <button type="button" class="button-link wooin-danger" data-media-clear %7$s>비우기 (기본값 사용)</button></div>',
			esc_attr( $type ),
			esc_attr( $fid ),
			esc_attr( $name ),
			esc_attr( (string) ( $id_val ? $id_val : '' ) ),
			$src ? ( 'image' === $type ? '<img src="' . esc_url( $src ) . '" alt="">' : '<video src="' . esc_url( $src ) . '" muted></video>' ) : '<span>' . ( 'image' === $type ? '기본 사진 사용 중' : '영상 없음' ) . '</span>',
			'image' === $type ? '사진 고르기 / 올리기' : '영상 고르기 / 올리기',
			$id_val ? '' : 'hidden'
		);
	} elseif ( 'text' === $type || 'url' === $type ) {
		printf(
			'<input type="text" class="large-text" id="%1$s" name="%2$s" value="%3$s" placeholder="%4$s" data-default="%5$s">',
			esc_attr( $fid ),
			esc_attr( $name ),
			esc_attr( (string) $value ),
			'url' === $type ? '/contact/ 또는 https://…' : '',
			esc_attr( (string) $def )
		);
	} else {
		$rows = max( 2, min( 8, substr_count( (string) $value, "\n" ) + ( 'textarea' === $type ? 3 : 2 ) ) );
		printf(
			'<textarea class="large-text" id="%1$s" name="%2$s" rows="%3$d" data-default="%5$s">%4$s</textarea>',
			esc_attr( $fid ),
			esc_attr( $name ),
			(int) $rows,
			esc_textarea( (string) $value ),
			esc_attr( (string) $def )
		);
	}

	if ( $help || ( '' !== (string) $def && ! in_array( $type, array( 'image', 'video' ), true ) ) ) {
		echo '<p class="description">' . esc_html( $help );
		if ( '' !== (string) $def && ! in_array( $type, array( 'image', 'video' ), true ) ) {
			echo ' <button type="button" class="button-link" data-reset>처음 문구로</button>';
		}
		echo '</p>';
	}
	echo '</div>';
}

/* ---------------------------------------------------------------- 운영 홈 */

function wooin_admin_count( string $type, string $status ): int {
	$counts = wp_count_posts( $type );
	return isset( $counts->$status ) ? (int) $counts->$status : 0;
}

function wooin_admin_render_home(): void {
	$user  = wp_get_current_user();
	$types = array(
		'wooin_case'    => array( '해결 사례', 'dashicons-media-document' ),
		'wooin_review'  => array( '의뢰인 후기', 'dashicons-format-quote' ),
		'wooin_news'    => array( '우인 소식', 'dashicons-megaphone' ),
		'post'          => array( '전문가 칼럼', 'dashicons-edit-page' ),
		'wooin_video'   => array( '유튜브 영상', 'dashicons-video-alt3' ),
		'wooin_faq'     => array( '자주 묻는 질문', 'dashicons-editor-help' ),
		'wooin_service' => array( '업무분야', 'dashicons-portfolio' ),
		'wooin_person'  => array( '구성원', 'dashicons-businessperson' ),
	);

	// 빠른 작업 (권한 있는 것만)
	$quick = array();
	foreach ( array( 'wooin_case', 'wooin_review', 'wooin_news', 'post', 'wooin_faq' ) as $type ) {
		$obj = get_post_type_object( $type );
		if ( $obj && current_user_can( $obj->cap->create_posts ) ) {
			$quick[] = array( $types[ $type ][0] . ' 등록', $types[ $type ][1], admin_url( 'post-new.php' . ( 'post' === $type ? '' : '?post_type=' . $type ) ) );
		}
	}
	if ( current_user_can( 'wooin_edit_home' ) ) {
		$quick[] = array( '메인 화면 편집', 'dashicons-admin-appearance', admin_url( 'admin.php?page=wooin-home' ) );
	}
	if ( current_user_can( 'wooin_manage_site_info' ) ) {
		$quick[] = array( '전화·주소 수정', 'dashicons-phone', admin_url( 'admin.php?page=wooin-site-info' ) );
		$quick[] = array( '유튜브 연동', 'dashicons-youtube', admin_url( 'edit.php?post_type=wooin_video&page=wooin-youtube' ) );
	}
	if ( current_user_can( 'upload_files' ) ) {
		$quick[] = array( '사진·파일 올리기', 'dashicons-format-gallery', admin_url( 'media-new.php' ) );
	}

	// 상담 등 다른 우인 플러그인이 버튼을 더한다
	$quick = apply_filters( 'wooin_admin_quick', $quick );

	// 확인할 일
	$todo = array();
	foreach ( $types as $type => $t ) {
		$obj = get_post_type_object( $type );
		if ( ! $obj ) {
			continue;
		}
		$pending = wooin_admin_count( $type, 'pending' );
		if ( $pending && current_user_can( $obj->cap->publish_posts ) ) {
			$todo[] = array( $t[0] . ' 검토 대기 ' . $pending . '건', admin_url( 'edit.php?post_status=pending&post_type=' . $type ), 'warn' );
		}
		$drafts = wooin_admin_count( $type, 'draft' );
		if ( $drafts && current_user_can( $obj->cap->edit_posts ) ) {
			$todo[] = array( $t[0] . ' 작성 중(초안) ' . $drafts . '건', admin_url( 'edit.php?post_status=draft&post_type=' . $type ), '' );
		}
	}
	$review = get_option( WOOIN_HOME_REVIEW );
	if ( is_array( $review ) && current_user_can( 'wooin_publish_home' ) ) {
		$todo[] = array( '메인 화면 검토 요청 (' . $review['user'] . ')', admin_url( 'admin.php?page=wooin-home' ), 'warn' );
	} elseif ( current_user_can( 'wooin_edit_home' ) && wooin_home_has_changes() ) {
		$todo[] = array( '메인 화면에 게시 안 된 변경이 있습니다', admin_url( 'admin.php?page=wooin-home' ), '' );
	}
	if ( current_user_can( 'manage_options' ) ) {
		$last = get_option( 'wooin_youtube_last_sync' );
		if ( is_array( $last ) && ! empty( $last['errors'] ) ) {
			$todo[] = array( '유튜브 동기화 오류 — 설정 확인', admin_url( 'edit.php?post_type=wooin_video&page=wooin-youtube' ), 'warn' );
		}
		$missing = array_filter( wooin_admin_plugins(), static fn( $p ) => 'must' === $p['level'] && ! wooin_admin_plugin_file( $p['slug'] ) );
		if ( $missing ) {
			$todo[] = array( '필수 추천 플러그인 ' . count( $missing ) . '개 미설치', admin_url( 'admin.php?page=wooin-plugins' ), 'warn' );
		}
	}

	$todo = apply_filters( 'wooin_admin_todo', $todo );

	// 최근 수정
	$recent = get_posts(
		array(
			'post_type'      => array_keys( $types ),
			'post_status'    => array( 'publish', 'draft', 'pending', 'future' ),
			'posts_per_page' => 8,
			'orderby'        => 'modified',
		)
	);
	$status_label = array( 'publish' => '게시됨', 'draft' => '초안', 'pending' => '검토 대기', 'future' => '예약' );
	?>
	<div class="wrap wooin-admin">
		<?php wooin_admin_header( '안녕하세요, ' . $user->display_name . '님', '오늘 할 일을 골라 시작하세요. 모든 수정은 이 관리자 화면에서 할 수 있습니다.' ); ?>

		<div class="wooin-quick">
			<?php foreach ( $quick as $q ) : ?>
				<a class="wooin-quick-item" href="<?php echo esc_url( $q[2] ); ?>"><span class="dashicons <?php echo esc_attr( $q[1] ); ?>"></span><?php echo esc_html( $q[0] ); ?></a>
			<?php endforeach; ?>
			<a class="wooin-quick-item is-ghost" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener"><span class="dashicons dashicons-external"></span>홈페이지 보기</a>
		</div>

		<div class="wooin-grid">
			<div class="wooin-card">
				<h3>확인할 일</h3>
				<?php if ( $todo ) : ?>
					<ul class="wooin-todo">
						<?php foreach ( $todo as $t ) : ?><li class="<?php echo $t[2] ? 'is-' . esc_attr( $t[2] ) : ''; ?>"><a href="<?php echo esc_url( $t[1] ); ?>"><?php echo esc_html( $t[0] ); ?> →</a></li><?php endforeach; ?>
					</ul>
				<?php else : ?>
					<p class="wooin-empty">처리할 일이 없습니다 👍</p>
				<?php endif; ?>
			</div>

			<div class="wooin-card">
				<h3>게시된 콘텐츠</h3>
				<table class="wooin-counts"><tbody>
				<?php foreach ( $types as $type => $t ) : ?>
					<?php $obj = get_post_type_object( $type ); ?>
					<?php if ( $obj && current_user_can( $obj->cap->edit_posts ) ) : ?>
					<tr><th><span class="dashicons <?php echo esc_attr( $t[1] ); ?>"></span> <a href="<?php echo esc_url( admin_url( 'edit.php' . ( 'post' === $type ? '' : '?post_type=' . $type ) ) ); ?>"><?php echo esc_html( $t[0] ); ?></a></th><td><?php echo (int) wooin_admin_count( $type, 'publish' ); ?>건</td></tr>
					<?php endif; ?>
				<?php endforeach; ?>
				</tbody></table>
			</div>

			<div class="wooin-card wooin-span2">
				<h3>최근 수정한 글</h3>
				<?php if ( $recent ) : ?>
				<table class="widefat striped"><tbody>
					<?php foreach ( $recent as $p ) : ?>
						<?php if ( ! current_user_can( 'edit_post', $p->ID ) ) { continue; } ?>
					<tr>
						<td><a href="<?php echo esc_url( (string) get_edit_post_link( $p->ID ) ); ?>"><strong><?php echo esc_html( get_the_title( $p ) ? get_the_title( $p ) : '(제목 없음)' ); ?></strong></a></td>
						<td><?php echo esc_html( $types[ $p->post_type ][0] ?? '' ); ?></td>
						<td><span class="wooin-badge is-<?php echo esc_attr( $p->post_status ); ?>"><?php echo esc_html( $status_label[ $p->post_status ] ?? $p->post_status ); ?></span></td>
						<td><?php echo esc_html( get_the_modified_date( 'Y-m-d H:i', $p ) ); ?></td>
					</tr>
					<?php endforeach; ?>
				</tbody></table>
				<?php else : ?>
					<p class="wooin-empty">아직 글이 없습니다.</p>
				<?php endif; ?>
			</div>

			<div class="wooin-card wooin-span2 wooin-help">
				<h3>처음이라면</h3>
				<ol>
					<li><b>글 올리기</b> — 위 「해결 사례 등록」 같은 버튼을 누르고 제목·내용을 채웁니다. 작성자는 「검토 요청」, 검수자는 「공개」를 누르면 홈페이지에 올라갑니다.</li>
					<li><b>메인 문구·사진 바꾸기</b> — 「메인 화면 편집」에서 고치고 「임시저장 → 미리보기 → 게시하기」 순서로 진행합니다. 실수해도 「이전 게시 기록」에서 되돌릴 수 있습니다.</li>
					<li><b>사진 교체</b> — 글의 사진은 글 편집 화면에서, 메인 사진은 「메인 화면 편집」에서, 구성원 사진은 「구성원」에서 바꿉니다.</li>
					<li><b>전화·주소·운영시간</b> — 「공통정보」 한 곳만 고치면 사이트 전체에 반영됩니다.</li>
				</ol>
			</div>
		</div>
	</div>
	<?php
}

/* ---------------------------------------------------------------- 추천 플러그인 */

/**
 * level: must 필수 · good 권장 · later 오픈 직전.
 */
function wooin_admin_plugins(): array {
	return array(
		array( 'slug' => 'updraftplus', 'name' => 'UpdraftPlus', 'level' => 'must', 'why' => '자동 백업. 글·사진·설정을 매일 백업하고 문제가 생기면 버튼 하나로 되돌립니다. 설치 후 「설정 › UpdraftPlus 백업」에서 일정(매일)과 보관 위치(구글 드라이브 등)를 정하세요.' ),
		array( 'slug' => 'limit-login-attempts-reloaded', 'name' => 'Limit Login Attempts Reloaded', 'level' => 'must', 'why' => '로그인 공격 차단. 비밀번호를 여러 번 틀리면 잠시 막습니다. 설치만 하면 기본값으로 동작합니다.' ),
		array( 'slug' => 'two-factor', 'name' => 'Two Factor', 'level' => 'must', 'why' => '관리자 2단계 인증 (WordPress 공식). 「사용자 › 프로필」에서 휴대폰 인증 앱을 연결합니다.' ),
		array( 'slug' => 'wp-mail-smtp', 'name' => 'WP Mail SMTP', 'level' => 'must', 'why' => '메일 발송 안정화. 상담 접수 알림 메일이 스팸함에 빠지거나 사라지지 않게 합니다. 상담 기능 연결 전에 메일 계정을 연결하세요.' ),
		array( 'slug' => 'enable-media-replace', 'name' => 'Enable Media Replace', 'level' => 'good', 'why' => '사진 교체. 미디어에서 사진을 같은 주소로 바꿔 끼웁니다 — 글을 하나하나 고칠 필요가 없습니다.' ),
		array( 'slug' => 'duplicate-post', 'name' => 'Yoast Duplicate Post', 'level' => 'good', 'why' => '글 복제. 비슷한 해결 사례·후기를 복사해서 빠르게 씁니다.' ),
		array( 'slug' => 'autodescription', 'name' => 'The SEO Framework', 'level' => 'good', 'why' => '검색 노출(SEO). 글마다 검색 결과 제목·설명·공유 이미지를 정합니다. 광고 없이 가볍습니다. 네이버 서치어드바이저 사이트 인증 코드도 여기서 넣습니다.' ),
		array( 'slug' => 'redirection', 'name' => 'Redirection', 'level' => 'later', 'why' => '주소 연결. 오픈 뒤 페이지 주소를 바꾸거나 페이지를 없앴을 때, 예전 주소로 들어온 방문자·검색 유입을 새 페이지로 보냅니다. 필요해질 때 설치하세요.' ),
		array( 'slug' => 'wp-super-cache', 'name' => 'WP Super Cache', 'level' => 'later', 'why' => '속도 개선. 방문자 화면을 저장해 두었다가 빠르게 보여줍니다. 메인 게시 때 자동으로 비워집니다. 오픈 직전에 켜세요(제작 중에는 수정이 늦게 보일 수 있음).' ),
	);
}

/** 설치된 플러그인 파일 경로 (없으면 ''). */
function wooin_admin_plugin_file( string $slug ): string {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	foreach ( array_keys( get_plugins() ) as $file ) {
		if ( str_starts_with( $file, $slug . '/' ) ) {
			return $file;
		}
	}
	return '';
}

function wooin_admin_render_plugins(): void {
	if ( ! current_user_can( 'install_plugins' ) ) {
		return;
	}
	$levels = array( 'must' => array( '필수', 'is-warn' ), 'good' => array( '권장', 'is-info' ), 'later' => array( '오픈 때', '' ) );
	?>
	<div class="wrap wooin-admin">
		<?php wooin_admin_header( '추천 플러그인', '우인 홈페이지에 필요한 플러그인만 골랐습니다. 「설치」 → 「켜기」 순서로 누르세요. 모두 WordPress 공식 저장소의 무료 플러그인입니다.' ); ?>
		<div class="wooin-plugins">
		<?php foreach ( wooin_admin_plugins() as $p ) : ?>
			<?php
			$file   = wooin_admin_plugin_file( $p['slug'] );
			$active = $file && is_plugin_active( $file );
			?>
			<div class="wooin-card wooin-plugin">
				<h3><?php echo esc_html( $p['name'] ); ?> <span class="wooin-badge <?php echo esc_attr( $levels[ $p['level'] ][1] ); ?>"><?php echo esc_html( $levels[ $p['level'] ][0] ); ?></span></h3>
				<p><?php echo esc_html( $p['why'] ); ?></p>
				<p>
				<?php if ( $active ) : ?>
					<span class="wooin-ok">✔ 사용 중</span>
				<?php elseif ( $file ) : ?>
					<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'plugins.php?action=activate&plugin=' . rawurlencode( $file ) ), 'activate-plugin_' . $file ) ); ?>">켜기</a>
				<?php else : ?>
					<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'update.php?action=install-plugin&plugin=' . $p['slug'] ), 'install-plugin_' . $p['slug'] ) ); ?>">설치</a>
				<?php endif; ?>
					<a class="button-link" href="<?php echo esc_url( 'https://ko.wordpress.org/plugins/' . $p['slug'] . '/' ); ?>" target="_blank" rel="noopener">자세히 ↗</a>
				</p>
			</div>
		<?php endforeach; ?>
		</div>
		<p class="description">설치 화면이 끝나면 「플러그인 활성화」를 누르거나, 이 화면으로 돌아와 「켜기」를 누르세요. 페이지 빌더·대형 테마 플러그인은 사이트 구조와 충돌할 수 있어 넣지 않았습니다.</p>
	</div>
	<?php
}

/* ---------------------------------------------------------------- 로그인 화면 */

add_action(
	'login_enqueue_scripts',
	static function () {
		$logo = get_theme_file_uri( 'assets/images/brand/rehab-lab-logo.png' );
		?>
		<style>
			body.login { background: #f4f4f2; }
			#login h1 a { background: url(<?php echo esc_url( $logo ); ?>) center / contain no-repeat; width: 220px; height: 70px; }
			.login form { border: 0; border-radius: 14px; box-shadow: 0 10px 40px rgba(0,0,0,.08); }
			.wp-core-ui .button-primary { background: #d7261e; border-color: #d7261e; }
			.wp-core-ui .button-primary:hover { background: #b51f18; border-color: #b51f18; }
		</style>
		<?php
	}
);
add_filter( 'login_headerurl', static fn() => home_url( '/' ) );
add_filter( 'login_headertext', static fn() => '법률사무소 우인' );
