<?php
/**
 * 자주 묻는 질문 — wooin_faq 글 + wooin/faq-list 블록 (/faq/)
 *
 * 질문 = 글 제목, 답변 = 본문, 분야 = wooin_practice_area, 단계 묶음 = faq_group 메타(예: 「개시신청」), 순서 = 순서(menu_order).
 * 법인회생 질문은 클라이언트 노션 「[필독] 회생요청사항 및 회사 안내서류」의 FAQ 를 그대로 옮겼다 (2026-10-26).
 * 화면: 법인 / 개인 탭(법인 먼저) → 단계 바로가기 → 단계별 펼침 목록.
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'init',
	static function () {
		register_post_meta(
			'wooin_faq',
			'faq_group',
			array(
				'type'              => 'string',
				'description'       => '단계 묶음 (예: 개시신청, 보전처분)',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => static fn( $allowed, $key, $post_id ) => current_user_can( 'edit_post', $post_id ),
			)
		);
		register_block_type(
			'wooin/faq-list',
			array(
				'title'           => '자주 묻는 질문 목록',
				'category'        => 'widgets',
				'editor_script'   => 'wooin-core-blocks',
				'render_callback' => 'wooin_render_faq_list',
				'supports'        => array( 'html' => false ),
			)
		);
	}
);

// 편집 화면: 단계 묶음 입력
add_action(
	'add_meta_boxes_wooin_faq',
	static function () {
		add_meta_box(
			'wooin-faq-group',
			'단계 묶음',
			static function ( WP_Post $post ) {
				wp_nonce_field( 'wooin_faq_meta', 'wooin_faq_nonce' );
				printf(
					'<input type="text" class="widefat" name="wooin_faq_group" value="%s" placeholder="예: 개시신청"><p class="description">같은 이름끼리 한 묶음으로 보입니다. 순서는 「순서」 값을 따릅니다.</p>',
					esc_attr( (string) get_post_meta( $post->ID, 'faq_group', true ) )
				);
			},
			'wooin_faq',
			'side'
		);
	}
);
add_action(
	'save_post_wooin_faq',
	static function ( $post_id ) {
		if ( ! isset( $_POST['wooin_faq_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wooin_faq_nonce'] ) ), 'wooin_faq_meta' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, 'faq_group', sanitize_text_field( wp_unslash( $_POST['wooin_faq_group'] ?? '' ) ) );
	}
);

function wooin_render_faq_list(): string {
	$posts = get_posts(
		array(
			'post_type'      => 'wooin_faq',
			'post_status'    => 'publish',
			'posts_per_page' => 300,
			'orderby'        => array( 'menu_order' => 'ASC', 'ID' => 'ASC' ),
		)
	);
	if ( ! $posts ) {
		return '<p class="wooin-placeholder">등록된 질문이 없습니다.</p>';
	}

	// 구분 → 단계 → 질문
	$tracks = array(
		'corporate' => array( '법인회생 · 파산', array() ),
		'personal'  => array( '개인회생 · 파산', array() ),
	);
	foreach ( $posts as $post ) {
		$slugs = wp_get_object_terms( $post->ID, 'wooin_practice_area', array( 'fields' => 'slugs' ) );
		$track = ( ! is_wp_error( $slugs ) && $slugs && str_starts_with( $slugs[0], 'personal' ) ) ? 'personal' : 'corporate';
		$group = (string) get_post_meta( $post->ID, 'faq_group', true );
		$group = '' !== $group ? $group : '기타';
		$tracks[ $track ][1][ $group ][] = $post;
	}
	$tracks = array_filter( $tracks, static fn( $t ) => $t[1] );

	$uid  = wp_unique_id( 'faq-' );
	$html = '<div class="wooin-tabs is-center" data-wooin-tabs><div class="wooin-tab-list" role="tablist" aria-label="질문 구분">';
	$first = true;
	foreach ( $tracks as $key => $t ) {
		$count = array_sum( array_map( 'count', $t[1] ) );
		$html .= '<button type="button" role="tab" id="' . esc_attr( "$uid-tab-$key" ) . '" aria-controls="' . esc_attr( "$uid-$key" ) . '" aria-selected="' . ( $first ? 'true' : 'false' ) . '" data-track="' . esc_attr( $key ) . '"' . ( $first ? '' : ' tabindex="-1"' ) . '>' . esc_html( $t[0] ) . ' <small>' . (int) $count . '</small></button>';
		$first = false;
	}
	$html .= '</div>';

	$first = true;
	foreach ( $tracks as $key => $t ) {
		$html .= '<div role="tabpanel" id="' . esc_attr( "$uid-$key" ) . '" aria-labelledby="' . esc_attr( "$uid-tab-$key" ) . '"' . ( $first ? '' : ' hidden' ) . '>';
		if ( count( $t[1] ) > 1 ) {
			$html .= '<nav class="wooin-faq-jump" aria-label="단계 바로가기">';
			$n     = 0;
			foreach ( $t[1] as $group => $items ) {
				$html .= '<a href="#' . esc_attr( "$uid-$key-" . ++$n ) . '"><b>' . $n . '</b>' . esc_html( $group ) . '</a>';
			}
			$html .= '</nav>';
		}
		$n = 0;
		foreach ( $t[1] as $group => $items ) {
			$html .= '<section class="wooin-faq-group" id="' . esc_attr( "$uid-$key-" . ++$n ) . '"><h3><span>' . sprintf( '%02d', $n ) . '</span>' . esc_html( $group ) . '</h3><div class="wooin-accordion">';
			foreach ( $items as $post ) {
				$html .= '<details><summary>' . esc_html( get_the_title( $post ) ) . '</summary><div class="wooin-faq-a">' . wp_kses_post( has_blocks( $post->post_content ) ? do_blocks( $post->post_content ) : wpautop( $post->post_content ) ) . '</div></details>';
			}
			$html .= '</div></section>';
		}
		$html .= '</div>';
		$first = false;
	}
	$html .= '</div>';

	return '<div ' . get_block_wrapper_attributes( array( 'class' => 'wooin-faq-list' ) ) . '>' . $html . '</div>';
}
