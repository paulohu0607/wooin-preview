<?php
/**
 * 메인 화면 편집 항목 — 관리자 「우인 홈페이지 › 메인 화면 편집」의 입력 칸과 기본값.
 *
 * 기본값은 현재 메인 시안 문구 그대로다. 관리자가 아무것도 고치지 않으면 화면은 지금과 같다.
 * 글자 꾸밈 규칙 (관리자 안내와 같음): 줄바꿈 = Enter, [대괄호] = 강조색, **별표 두 개** = 굵게.
 * {구독자}·{구독자숫자} 는 유튜브 구독자 수로 바뀐다 (videos.php wooin_yt_fill).
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * 메인 섹션 (순서·표시 설정용). 키 = 테마 패턴 wooin/home-{키}.
 */
function wooin_home_sections(): array {
	return array(
		'hero'     => '첫 화면 (히어로)',
		'tracks'   => '법인 / 개인 갈림길',
		'about'    => '우인 소개 · 숫자',
		'why'      => '우인의 원칙',
		'cases'    => '해결 사례',
		'lawyer'   => '구성원',
		'videos'   => '유튜브 영상',
		'process'  => '진행 절차',
		'services' => '업무분야',
		'reviews'  => '의뢰인 후기',
		'insights' => '소식 · 칼럼',
		'contact'  => '상담 안내',
	);
}

/**
 * 탭 → 입력 칸. 칸: [키, 이름, 형식, 기본값, 도움말]
 * 형식: text 한 줄 · lines 여러 줄(꾸밈 가능) · textarea 문단 · list 한 줄에 하나 · url 링크 · image 사진 · video 영상
 */
function wooin_home_tabs(): array {
	$tabs = array(
		'hero'  => array(
			'label'  => '첫 화면',
			'icon'   => 'dashicons-format-image',
			'desc'   => '사이트에 들어오면 가장 먼저 보이는 화면입니다.',
			'groups' => array(
				'문구' => array(
					array( 'hero_eyebrow', '맨 위 작은 글씨', 'text', '법인회생 · 법인파산 · 개인회생 · 개인파산 | 법률사무소 우인', '' ),
					array( 'hero_title', '큰 제목', 'lines', "[우]리의 새 출발,\n[인]가결정까지 함께합니다.", '두 줄 이내를 권장합니다. [대괄호] 안 글자는 강조색으로 표시됩니다.' ),
					array( 'hero_lead', '설명 문구', 'lines', "멈춰 선 회사도, 채무에 묶인 대표님과 전문직도.\n9년간 오직 도산만 연구한 [이서영 변호사]가 처음부터 끝까지 함께합니다.", '[대괄호] 안 글자에는 밑줄 강조가 들어갑니다.' ),
				),
				'버튼' => array(
					array( 'hero_btn1_label', '첫 번째 버튼 글자', 'text', '법인 상담 신청', '' ),
					array( 'hero_btn1_url', '첫 번째 버튼 연결 주소', 'url', '/contact/corporate/', '사이트 안 주소는 /contact/ 처럼 / 로 시작해 적어도 됩니다.' ),
					array( 'hero_btn2_label', '두 번째 버튼 글자', 'text', '개인 상담 신청', '비워 두면 두 번째 버튼을 숨깁니다.' ),
					array( 'hero_btn2_url', '두 번째 버튼 연결 주소', 'url', '/contact/personal/', '' ),
				),
				'아래 배지 3개' => array(
					array( 'hero_badge1_strong', '배지 1 · 굵은 글씨', 'text', '대한변호사협회', '' ),
					array( 'hero_badge1_text', '배지 1 · 설명', 'text', '이사', '' ),
					array( 'hero_badge2_strong', '배지 2 · 굵은 글씨', 'text', '4,000건+', '' ),
					array( 'hero_badge2_text', '배지 2 · 설명', 'text', '회생·파산 성공사례', '' ),
					array( 'hero_badge3_strong', '배지 3 · 굵은 글씨', 'text', '{구독자}', '{구독자} 는 유튜브 구독자 수로 자동으로 바뀝니다 (「유튜브 연동 설정」).' ),
					array( 'hero_badge3_text', '배지 3 · 설명', 'text', '유튜브 구독자', '배지의 굵은 글씨를 비우면 그 배지를 숨깁니다.' ),
				),
				'배경' => array(
					array( 'hero_image', '배경 사진', 'image', 0, '가로로 긴 사진(1920px 이상)을 권장합니다. 비워 두면 기본 사진이 나옵니다. 글씨가 잘 보이도록 왼쪽이 자동으로 어둡게 처리됩니다.' ),
					array( 'hero_video', '배경 영상 (선택)', 'video', 0, 'MP4 파일, 소리 없이 반복 재생됩니다. 20MB 이하를 권장합니다. 영상이 있어도 배경 사진은 영상이 뜨기 전·휴대폰 절전 모드에서 보입니다.' ),
				),
			),
		),
		'tracks' => array(
			'label'  => '법인 / 개인 갈림길',
			'icon'   => 'dashicons-randomize',
			'desc'   => '첫 화면 바로 아래, 방문자가 법인과 개인 중 자기 상황을 고르는 두 칸입니다.',
			'groups' => array(),
		),
		'about' => array(
			'label'  => '우인 소개 · 숫자',
			'icon'   => 'dashicons-building',
			'desc'   => '「About Wooin」 소개 글, 사진, 숫자 4개입니다.',
			'groups' => array(
				'소개' => array(
					array( 'about_lead', '강조 문장', 'lines', "회사와 대표님이 부채의 무게를 내려놓고 다시 시작하게 하는 일,\n**우인이 가장 잘하는 일**입니다.", '' ),
					array( 'about_body1', '본문 1', 'textarea', '회생과 파산은 신청서 한 장으로 끝나지 않습니다. 보정 명령, 채권자 이의, 변제계획과 회생계획안까지 한 단계라도 놓치면 새 출발이 늦어집니다.', '' ),
					array( 'about_body2', '본문 2', 'textarea', '법률사무소 우인은 10여 년간 도산 분야만 연구해 온 이서영 변호사를 중심으로, 개인 의뢰인은 일상에, 대표님은 사업에 집중하는 동안 절차의 모든 순간을 관리합니다.', '비워 두면 숨깁니다.' ),
					array( 'about_photo', '오른쪽 사진', 'image', 0, '세로로 조금 긴 사진이 잘 어울립니다. 비워 두면 기본 사진이 나옵니다.' ),
				),
			),
		),
		'why' => array(
			'label'  => '우인의 원칙',
			'icon'   => 'dashicons-awards',
			'desc'   => '카드 6개로 보여주는 「우인의 원칙」입니다. 제목을 비운 카드는 숨깁니다.',
			'groups' => array(
				'제목' => array(
					array( 'why_eyebrow', '작은 글씨', 'text', 'Wooin · System', '' ),
					array( 'why_title', '제목', 'lines', "[4,000건]의 경험이 만든\n**우인의 6가지 원칙**", '' ),
				),
			),
		),
		'sections' => array(
			'label'  => '섹션 순서 · 표시',
			'icon'   => 'dashicons-sort',
			'desc'   => '메인에 보일 섹션을 고르고 순서를 바꿉니다. 끌어서 옮기거나 ↑↓ 버튼을 누르세요.',
			'groups' => array(),
		),
	);

	// 숫자 4개
	$stats = array(
		array( '9', '년', '오직 도산 분야만 연구' ),
		array( '4,000', '건+', '회생·파산 성공사례' ),
		array( '2', '주', '서류 수령 후 법원 접수' ),
		array( '{구독자숫자}', '만', '유튜브 구독자' ),
	);
	foreach ( $stats as $i => $s ) {
		$n = $i + 1;
		$tabs['about']['groups'][ '숫자 ' . $n ] = array(
			array( "stat{$n}_num", '숫자', 'text', $s[0], 1 === $n ? '숫자만 적으면 화면에서 0부터 올라가는 효과가 납니다. 숫자를 비우면 그 칸을 숨깁니다.' : '' ),
			array( "stat{$n}_unit", '단위', 'text', $s[1], '' ),
			array( "stat{$n}_label", '설명', 'text', $s[2], '' ),
		);
	}

	// 원칙 6개
	$why = array(
		array( '도산만 연구했습니다', '9년간 오직 도산 분야만 연구한 변호사가 사건의 전 과정을 검토하고 관리합니다.' ),
		array( '적게 맡아, 깊이 봅니다', '매월 수임하는 사건 수를 제한해 한 분, 한 회사에 집중합니다.' ),
		array( '독촉은 우인이 받습니다', '채권자의 추심·독촉 연락은 우인이 대응합니다. 의뢰인은 일상과 사업에만 집중하세요.' ),
		array( '담당자가 바뀌지 않습니다', '1:1 전담 직원이 처음부터 끝까지 함께하며, 언제든 진행 상황을 확인할 수 있습니다.' ),
		array( '2주 안에 접수합니다', '서류를 받은 날부터 2주 안에 법원 접수를 약속합니다. 회생은 시간이 곧 기회입니다.' ),
		array( '계약을 서두르지 않습니다', '무조건 계약을 유도하는 사무장이 없습니다. 가능성은 변호사가 판단합니다.' ),
	);
	foreach ( $why as $i => $w ) {
		$n = $i + 1;
		$tabs['why']['groups'][ '원칙 ' . $n ] = array(
			array( "why{$n}_title", '제목', 'text', $w[0], '' ),
			array( "why{$n}_text", '설명', 'textarea', $w[1], '' ),
		);
	}

	// 갈림길 2칸
	$tracks = array(
		'corp' => array( '법인 칸', 'For Companies', '법인회생 · 법인파산', "멈춘 회사의\n**재기**", '압류·체납·만기 거절 앞에서. 회사를 살리거나, 책임 있게 정리하는 길을 설계합니다.', "회생 가능성 진단\n보전처분·금지명령\n인가 후 정상화까지", '/services/corporate-rehabilitation/', '법인 상담 신청', '/contact/corporate/' ),
		'pers' => array( '개인 칸', 'For Individuals', '개인회생 · 개인파산', "채무를 정리하고\n**다시 본업으로**", '개인사업자·전문직·직장인. 감당하기 어려운 채무를 법이 정한 절차로 줄이거나 정리합니다.', "월 변제금 · 탕감률 진단\n추심·독촉 중단\n면책까지 관리", '/services/personal-rehabilitation/', '개인 상담 신청', '/contact/personal/' ),
	);
	foreach ( $tracks as $k => $t ) {
		$tabs['tracks']['groups'][ $t[0] ] = array(
			array( "track_{$k}_en", '영문 작은 글씨', 'text', $t[1], '' ),
			array( "track_{$k}_label", '분야 표시', 'text', $t[2], '' ),
			array( "track_{$k}_title", '제목', 'lines', $t[3], '' ),
			array( "track_{$k}_desc", '설명', 'textarea', $t[4], '' ),
			array( "track_{$k}_points", '체크 항목', 'list', $t[5], '한 줄에 하나씩 적습니다.' ),
			array( "track_{$k}_cta_label", '상담 버튼 글자', 'text', $t[7], '' ),
			array( "track_{$k}_cta_url", '상담 버튼 연결 주소', 'url', $t[8], '' ),
			array( "track_{$k}_more_url", '「자세히 보기」 연결 주소', 'url', $t[6], '' ),
		);
	}

	// ---- 나머지 섹션 제목·문구
	$tabs['sectext'] = array(
		'label'  => '섹션 제목 · 문구',
		'icon'   => 'dashicons-editor-textcolor',
		'desc'   => '해결 사례 · 영상 · 업무분야 · 후기 · 상담 안내 섹션의 제목과 설명입니다. 목록 내용(사례·영상·후기)은 각 메뉴에서 관리합니다.',
		'groups' => array(
			'해결 사례' => array(
				array( 'cases_eyebrow', '작은 글씨', 'text', 'Solved Cases', '' ),
				array( 'cases_title', '제목', 'lines', '말이 아닌 **결과**로 증명합니다', '' ),
				array( 'cases_desc', '설명', 'textarea', '얼마의 부채가, 어떻게 정리되었는지. 우인이 함께한 결과를 그대로 공개합니다.', '' ),
			),
			'유튜브 영상' => array(
				array( 'videos_label', '채널 이름 표시', 'text', '이서영변호사의 회생파산연구소', '' ),
				array( 'videos_title', '제목', 'lines', "구독자 [{구독자} 명]이 찾아보는\n**회생·파산 전문 채널**", '{구독자} 는 구독자 수로 자동으로 바뀝니다.' ),
				array( 'videos_desc', '설명', 'textarea', '법인 도산부터 개인회생까지, 어렵고 낯선 절차를 이서영 변호사가 영상으로 쉽게 설명합니다.', '메인에 띄울 영상은 「유튜브 영상」에서 영상마다 「메인 캐러셀에 노출」을 체크합니다.' ),
			),
			'업무분야' => array(
				array( 'services_eyebrow', '작은 글씨', 'text', 'Practice Areas', '' ),
				array( 'services_title', '제목', 'lines', '개인부터 법인까지, [도산 한 분야]에만 집중합니다', '' ),
			),
			'의뢰인 후기' => array(
				array( 'reviews_eyebrow', '작은 글씨', 'text', 'Client Reviews', '' ),
				array( 'reviews_title', '제목', 'lines', "같은 길을 먼저 지나온\n**의뢰인들의 이야기**", '' ),
				array( 'reviews_note', '아래 안내 문구', 'text', '※ 의뢰인의 게시 동의를 받은 실제 후기입니다. 개인정보 보호를 위해 이름 일부를 가렸습니다.', '비워 두면 숨깁니다.' ),
			),
			'상담 안내 (맨 아래)' => array(
				array( 'contact_eyebrow', '작은 글씨', 'text', 'Contact Us', '' ),
				array( 'contact_title', '제목', 'lines', "압류와 독촉이 시작되기 전,\n[지금이 가장 빠른 때]입니다.", '' ),
				array( 'contact_sub', '설명', 'text', '이런 신호가 하나라도 보인다면, 혼자 버티지 마세요.', '' ),
				array( 'contact_corp_head', '왼쪽 목록 제목', 'text', '법인', '' ),
				array( 'contact_corp_list', '왼쪽 목록', 'list', "계좌 압류·가압류 통지를 받았다\n급여·세금·4대보험이 밀리기 시작했다\n대출 만기 연장이 거절됐다", '한 줄에 하나씩.' ),
				array( 'contact_pers_head', '오른쪽 목록 제목', 'text', '대표 · 개인사업자', '' ),
				array( 'contact_pers_list', '오른쪽 목록', 'list', "카드·대출 돌려막기가 한계에 왔다\n급여·통장 압류 통지를 받았다\n독촉 전화가 하루에도 몇 번씩 온다", '' ),
				array( 'contact_label', '전화번호 위 작은 글씨', 'text', '법인 · 개인 회생파산 상담 · 비밀 보장', '전화번호·운영시간은 「공통정보」에서 바꿉니다.' ),
			),
		),
	);
	$svc = array(
		array( '법인회생', '다시 일어설 회사를 위한 선택', '계속기업가치를 입증하고 회생계획안부터 인가결정까지, 회사가 살아남을 길을 설계합니다.' ),
		array( '법인파산', '책임 있게 정리하고, 다음을 준비합니다', '회생이 어려운 경우, 법인과 대표님 개인의 부담을 최소화하는 정리 방안을 찾습니다.' ),
		array( '개인회생', '갚을 수 있는 만큼만, 다시 시작', '소득이 있다면 채무의 상당 부분을 줄이고, 3~5년 변제 후 나머지를 면책받을 수 있습니다.' ),
		array( '개인파산', '더는 갚을 수 없을 때의 선택', '소득과 재산으로 채무를 감당할 수 없다면, 파산·면책으로 정리합니다.' ),
	);
	foreach ( $svc as $i => $v ) {
		$n = $i + 1;
		$tabs['sectext']['groups']['업무분야'][] = array( "svc{$n}_tagline", $v[0] . ' · 한 줄', 'text', $v[1], '' );
		$tabs['sectext']['groups']['업무분야'][] = array( "svc{$n}_desc", $v[0] . ' · 설명', 'textarea', $v[2], '' );
	}

	// ---- 진행 절차
	$tabs['process'] = array(
		'label'  => '진행 절차',
		'icon'   => 'dashicons-editor-ol',
		'desc'   => '「Wooin Process」 섹션입니다. 단계 이름을 비우면 그 단계를 숨깁니다.',
		'groups' => array(
			'왼쪽 설명' => array(
				array( 'process_lead', '강조 문장', 'lines', "상담부터 마무리까지,\n**6단계를 함께 걷습니다.**", '' ),
				array( 'process_desc', '설명', 'textarea', '회생은 신청서를 내는 것으로 끝나지 않습니다. 오히려 신청 이후가 더 중요합니다. 우인은 절차의 처음과 끝을 같은 팀이 책임집니다.', '' ),
			),
		),
	);
	$flows = array(
		'corp' => array( '법인회생 단계', array(
			array( '상담 · 진단', '재무 상황과 채무 구조를 확인하고, 회생과 파산 중 회사에 맞는 길을 함께 판단합니다.' ),
			array( '신청서 작성 · 접수', '필요 서류를 받은 날부터 2주 안에 회생법원에 신청서를 접수합니다.' ),
			array( '보전처분 · 포괄적 금지명령', '강제집행과 가압류, 채권자의 추심을 멈추고 회사의 숨 쉴 틈을 확보합니다.' ),
			array( '개시결정', '법원이 회생절차 개시를 결정하면, 조사위원의 조사에 함께 대응합니다.' ),
			array( '회생계획안 · 관계인집회', '변제 계획을 설계하고, 채권자를 설득해 동의를 이끌어냅니다.' ),
			array( '인가결정 · 정상화', '인가 이후에도 계획이 차질 없이 수행되도록 끝까지 관리합니다.' ),
		) ),
		'pers' => array( '개인회생 단계', array(
			array( '상담 · 자격 진단', '소득과 재산, 채무를 확인해 개인회생과 개인파산 중 맞는 절차와 예상 변제금을 안내합니다.' ),
			array( '서류 준비 · 신청', '필요 서류를 받은 날부터 2주 안에 법원에 신청서를 접수합니다.' ),
			array( '금지·중지명령', '급여 압류와 채권자의 추심·독촉을 멈추도록 신청합니다.' ),
			array( '개시결정', '보정 명령에 빠르게 대응해 개시결정을 이끌어냅니다.' ),
			array( '변제계획 인가', '채권자 집회를 거쳐 변제계획 인가를 받습니다.' ),
			array( '변제 수행 · 면책', '변제 기간 동안 함께 관리하고, 면책결정으로 마무리합니다.' ),
		) ),
	);
	foreach ( $flows as $k => $flow ) {
		$rows = array();
		foreach ( $flow[1] as $i => $st ) {
			$n      = $i + 1;
			$rows[] = array( "process_{$k}{$n}_title", $n . '단계 이름', 'text', $st[0], '' );
			$rows[] = array( "process_{$k}{$n}_text", $n . '단계 설명', 'textarea', $st[1], '' );
		}
		$tabs['process']['groups'][ $flow[0] ] = $rows;
	}

	// ---- 서브페이지 상단 배경
	$tabs['subbg'] = array(
		'label'  => '서브페이지 배경',
		'icon'   => 'dashicons-format-gallery',
		'desc'   => '각 메뉴 페이지 맨 위 띠의 배경 사진입니다. 비워 두면 기본 사진이 나옵니다. 글씨가 잘 보이도록 자동으로 어둡게 처리됩니다.',
		'groups' => array(
			'메뉴별 배경 사진' => array(
				array( 'subbg_about', '법률사무소 우인 (인사말 · 구성원 · 오시는 길 등)', 'image', 0, '' ),
				array( 'subbg_services', '업무분야', 'image', 0, '' ),
				array( 'subbg_cases', '해결사례', 'image', 0, '' ),
				array( 'subbg_reviews', '의뢰인 후기', 'image', 0, '' ),
				array( 'subbg_info', '법률정보 (칼럼 · FAQ · 영상)', 'image', 0, '' ),
				array( 'subbg_contact', '상담안내', 'image', 0, '' ),
			),
		),
	);

	// 탭 순서
	$order = array( 'hero', 'tracks', 'about', 'why', 'sectext', 'process', 'subbg', 'sections' );
	return array_merge( array_flip( $order ), $tabs );
}

/** 모든 입력 칸을 키 → [이름, 형식, 기본값] 으로. */
function wooin_home_fields(): array {
	static $fields = null;
	if ( null === $fields ) {
		$fields = array();
		foreach ( wooin_home_tabs() as $tab ) {
			foreach ( $tab['groups'] as $group ) {
				foreach ( $group as $f ) {
					$fields[ $f[0] ] = array( $f[1], $f[2], $f[3] );
				}
			}
		}
		$fields['sections'] = array( '섹션 순서 · 표시', 'sections', array_map( static fn( $k ) => array( $k, true ), array_keys( wooin_home_sections() ) ) );
	}
	return $fields;
}
