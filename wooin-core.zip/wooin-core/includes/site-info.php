<?php
/**
 * 공통정보 — 명칭·전화·주소·운영시간·이메일의 단일 원본.
 *
 * 테마는 블록 바인딩 소스 `wooin/site-info` 로 값을 읽는다 (헤더·푸터·상담·오시는 길).
 * 값이 비어 있으면 null 을 돌려 템플릿의 기본 문구('미확정')가 그대로 보인다.
 *
 * 현재는 저장 즉시 반영된다. 초안/게시 분리가 필요한 필드는 설계 확정 후 스냅샷 방식으로 바꾼다.
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

const WOOIN_SITE_INFO_OPTION = 'wooin_site_info';

function wooin_core_site_info_fields(): array {
	return array(
		'brand_name'    => array( '사무소 명칭', '법률사무소 우인' ),
		'phone_display' => array( '상담 전화 (화면 표시)', '' ),
		'address'       => array( '주소', '' ),
		'hours'         => array( '상담 운영시간', '' ),
		'email'         => array( '대표 이메일', '' ),
		'youtube_url'   => array( '유튜브 채널 주소', '' ),
		'kakao_url'     => array( '카카오톡 채널 주소', '' ),
		'cafe_url'      => array( '네이버 카페 주소', '' ),
	);
}

/**
 * 공통정보 한 항목. phone_tel·phone_href 는 phone_display 에서 숫자만 뽑아 만든다.
 */
function wooin_core_site_info( string $key ): string {
	$saved  = get_option( WOOIN_SITE_INFO_OPTION, array() );
	$saved  = is_array( $saved ) ? $saved : array();
	$fields = wooin_core_site_info_fields();

	if ( 'phone_tel' === $key || 'phone_href' === $key ) {
		$tel = preg_replace( '/[^0-9+]/', '', $saved['phone_display'] ?? '' );
		return ( 'phone_href' === $key && $tel ) ? 'tel:' . $tel : $tel;
	}
	if ( ! isset( $fields[ $key ] ) ) {
		return '';
	}

	$value = $saved[ $key ] ?? '';
	return '' !== $value ? $value : $fields[ $key ][1];
}

add_action(
	'init',
	static function () {
		register_setting(
			'wooin_site_info',
			WOOIN_SITE_INFO_OPTION,
			array(
				'type'              => 'object',
				'default'           => array(),
				'show_in_rest'      => false,
				'sanitize_callback' => 'wooin_core_sanitize_site_info',
			)
		);

		if ( function_exists( 'register_block_bindings_source' ) ) {
			register_block_bindings_source(
				'wooin/site-info',
				array(
					'label'              => '우인 공통정보',
					'get_value_callback' => static function ( array $args ) {
						$value = wooin_core_site_info( (string) ( $args['key'] ?? '' ) );
						return '' !== $value ? esc_html( $value ) : null;
					},
				)
			);
		}
	}
);

function wooin_core_sanitize_site_info( $input ): array {
	$input = is_array( $input ) ? $input : array();
	$clean = array();
	foreach ( array_keys( wooin_core_site_info_fields() ) as $key ) {
		$raw           = isset( $input[ $key ] ) ? wp_unslash( $input[ $key ] ) : '';
		if ( 'email' === $key ) {
			$clean[ $key ] = sanitize_email( $raw );
		} elseif ( str_ends_with( $key, '_url' ) ) {
			$clean[ $key ] = esc_url_raw( $raw );
		} else {
			$clean[ $key ] = sanitize_text_field( $raw );
		}
	}
	return $clean;
}

// 옵션 페이지는 manage_options 기준으로 저장 권한을 검사하므로 운영 책임자 권한으로 바꾼다.
add_filter(
	'option_page_capability_wooin_site_info',
	static function () {
		return 'wooin_manage_site_info';
	}
);

// 메뉴는 「우인 홈페이지 › 공통정보」 (admin-ui.php)

function wooin_core_render_site_info_page(): void {
	if ( ! current_user_can( 'wooin_manage_site_info' ) ) {
		return;
	}
	$saved = get_option( WOOIN_SITE_INFO_OPTION, array() );
	$saved = is_array( $saved ) ? $saved : array();
	?>
	<div class="wrap wooin-admin">
		<?php wooin_admin_header( '공통정보', '여기서 수정한 값은 헤더·푸터·상담·오시는 길에 함께 반영됩니다. 확정되지 않은 값은 비워 두세요.' ); ?>
		<?php settings_errors(); ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'wooin_site_info' ); ?>
			<div class="wooin-card"><table class="form-table" role="presentation">
				<?php foreach ( wooin_core_site_info_fields() as $key => $field ) : ?>
					<tr>
						<th scope="row"><label for="wooin-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field[0] ); ?></label></th>
						<td>
							<input
								type="<?php echo 'email' === $key ? 'email' : ( 'phone_display' === $key ? 'tel' : 'text' ); ?>"
								class="regular-text"
								id="wooin-<?php echo esc_attr( $key ); ?>"
								name="<?php echo esc_attr( WOOIN_SITE_INFO_OPTION . '[' . $key . ']' ); ?>"
								value="<?php echo esc_attr( $saved[ $key ] ?? '' ); ?>"
								placeholder="<?php echo esc_attr( $field[1] ? $field[1] : '확정 후 입력' ); ?>"
							>
						</td>
					</tr>
				<?php endforeach; ?>
			</table></div>
			<?php submit_button( '저장 (바로 반영)' ); ?>
		</form>
	</div>
	<?php
}
