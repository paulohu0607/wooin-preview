<?php
/**
 * 게시판 공통 — 우인 소식(wooin_news) · 해결 사례 · 의뢰인 후기 · 전문가 칼럼(post)
 *
 * 1) 공지 상단 고정: 글 편집 화면 오른쪽 「게시판 설정」에서 「공지 — 목록 맨 위에 고정」 체크 (meta pinned).
 * 2) 법인 우선 정렬: 법인 분야 글 → 개인 분야 글 → 분야 없음 순, 같은 구분 안에서는 최신순 (2026-10-26 클라이언트 요청).
 *    정렬값은 저장할 때 숨은 필드 _wooin_track_rank(0 법인 · 1 개인 · 2 없음)로 계산해 둔다.
 * 3) 목록 블록 wooin/news-board · wooin/case-board 와 상세 블록 wooin/board-detail.
 *    후기 목록(wooin/review-board)도 같은 목록 함수를 쓴다.
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

const WOOIN_BOARD_PER_PAGE = 10;

/** 공지 고정 · 법인 우선 정렬을 쓰는 글 유형. */
function wooin_board_types(): array {
	return array( 'wooin_news', 'wooin_case', 'wooin_review', 'post' );
}

/** 우인 소식 글 유형 (활성화 때 고유주소 갱신을 위해 따로 부를 수 있게 함수로 둔다). */
function wooin_core_register_news(): void {
	register_post_type(
		'wooin_news',
		array(
			'labels'          => array(
				'name'          => '우인 소식',
				'singular_name' => '소식',
				'add_new'       => '새 소식',
				'add_new_item'  => '소식 등록',
				'edit_item'     => '소식 수정',
				'all_items'     => '전체 소식',
				'search_items'  => '소식 검색',
				'not_found'     => '등록된 소식이 없습니다.',
			),
			'public'          => true,
			'show_in_rest'    => true,
			'menu_icon'       => 'dashicons-megaphone',
			'menu_position'   => 20,
			'has_archive'     => 'news',
			'rewrite'         => array( 'slug' => 'news', 'with_front' => false ),
			'supports'        => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions' ),
			'taxonomies'      => array( 'wooin_practice_area' ),
			'capability_type' => array( 'wooin_news_item', 'wooin_news_items' ),
			'map_meta_cap'    => true,
		)
	);
	register_taxonomy_for_object_type( 'wooin_practice_area', 'wooin_news' );
}

add_action(
	'init',
	static function () {
		wooin_core_register_news();

		foreach ( wooin_board_types() as $type ) {
			register_post_meta(
				$type,
				'pinned',
				array(
					'type'          => 'boolean',
					'description'   => '공지 — 목록 맨 위에 고정',
					'single'        => true,
					'default'       => false,
					'show_in_rest'  => true,
					'auth_callback' => static fn( $allowed, $key, $post_id ) => current_user_can( 'edit_post', $post_id ),
				)
			);
		}

		$blocks = array(
			'news-board'   => array( '우인 소식 목록', static fn() => wooin_board_list( wooin_board_config( 'wooin_news' ) ) ),
			'case-board'   => array( '해결 사례 목록 (게시판)', static fn() => wooin_board_list( wooin_board_config( 'wooin_case' ) ) ),
			'board-detail' => array( '게시판 글 상세', 'wooin_render_board_detail' ),
		);
		foreach ( $blocks as $name => $b ) {
			register_block_type(
				'wooin/' . $name,
				array(
					'title'           => $b[0],
					'category'        => 'widgets',
					'editor_script'   => 'wooin-core-blocks',
					'render_callback' => $b[1],
					'supports'        => array( 'html' => false ),
				)
			);
		}
	}
);

/* ---------------------------------------------------------------- 법인 우선 정렬값 */

/** 0 법인 · 1 개인 · 2 구분 없음. */
function wooin_track_rank( int $post_id ): int {
	if ( 'wooin_case' === get_post_type( $post_id ) ) {
		return 'corporate' === get_post_meta( $post_id, 'case_track', true ) ? 0 : 1;
	}
	$slugs = wp_get_object_terms( $post_id, 'wooin_practice_area', array( 'fields' => 'slugs' ) );
	if ( is_wp_error( $slugs ) || ! $slugs ) {
		return 2;
	}
	foreach ( $slugs as $slug ) {
		if ( str_starts_with( $slug, 'corporate' ) ) {
			return 0;
		}
	}
	return 1;
}

function wooin_update_track_rank( int $post_id ): void {
	if ( in_array( get_post_type( $post_id ), wooin_board_types(), true ) && ! wp_is_post_revision( $post_id ) ) {
		update_post_meta( $post_id, '_wooin_track_rank', wooin_track_rank( $post_id ) );
	}
}
add_action( 'save_post', static fn( $post_id ) => wooin_update_track_rank( (int) $post_id ), 20 );
add_action( 'set_object_terms', static fn( $object_id ) => wooin_update_track_rank( (int) $object_id ), 20 );
add_action(
	'updated_post_meta',
	static function ( $meta_id, $object_id, $key ) {
		if ( 'case_track' === $key ) {
			wooin_update_track_rank( (int) $object_id );
		}
	},
	20,
	3
);
add_action(
	'added_post_meta',
	static function ( $meta_id, $object_id, $key ) {
		if ( 'case_track' === $key ) {
			wooin_update_track_rank( (int) $object_id );
		}
	},
	20,
	3
);

/** WP_Query 인자에 「법인 우선 → 최신순」 정렬을 더한다 (정렬값 없는 글도 빠지지 않게 OR). */
function wooin_board_order_args( array $args ): array {
	$args['meta_query'] = array_merge(
		$args['meta_query'] ?? array(),
		array(
			'wooin_rank' => array(
				'relation'   => 'OR',
				'rank_value' => array( 'key' => '_wooin_track_rank', 'compare' => 'EXISTS' ),
				array( 'key' => '_wooin_track_rank', 'compare' => 'NOT EXISTS' ),
			),
		)
	);
	$args['orderby']    = array( 'rank_value' => 'ASC', 'date' => 'DESC', 'ID' => 'DESC' );
	return $args;
}

// 칼럼(기본 글) 목록과 메인 칼럼 쿼리 블록도 법인 우선
add_action(
	'pre_get_posts',
	static function ( WP_Query $q ) {
		if ( ! is_admin() && $q->is_main_query() && ( $q->is_home() || $q->is_post_type_archive( array( 'wooin_news', 'wooin_case', 'wooin_review' ) ) ) ) {
			foreach ( wooin_board_order_args( array() ) as $k => $v ) {
				$q->set( $k, $v );
			}
		}
	}
);
add_filter(
	'query_loop_block_query_vars',
	static function ( array $vars ) {
		$type = $vars['post_type'] ?? 'post';
		if ( in_array( $type, wooin_board_types(), true ) && 'menu_order' !== ( $vars['orderby'] ?? '' ) ) {
			$vars = wooin_board_order_args( $vars );
		}
		return $vars;
	}
);

/* ---------------------------------------------------------------- 편집 화면: 게시판 설정 */

add_action(
	'add_meta_boxes',
	static function () {
		add_meta_box(
			'wooin-board',
			'게시판 설정',
			static function ( WP_Post $post ) {
				wp_nonce_field( 'wooin_board_meta', 'wooin_board_nonce' );
				printf(
					'<label><input type="checkbox" name="wooin_pinned" value="1"%s> 공지 — 목록 맨 위에 고정</label><p class="description">고정한 글은 목록 첫 쪽 맨 위에 「공지」로 표시됩니다.</p>',
					checked( (bool) get_post_meta( $post->ID, 'pinned', true ), true, false )
				);
			},
			wooin_board_types(),
			'side',
			'high'
		);
	}
);

add_action(
	'save_post',
	static function ( $post_id ) {
		if ( ! isset( $_POST['wooin_board_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wooin_board_nonce'] ) ), 'wooin_board_meta' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, 'pinned', ! empty( $_POST['wooin_pinned'] ) );
	}
);

/* ---------------------------------------------------------------- 목록 */

/**
 * 게시판별 설정.
 *   filter  : area(분야 분류) | track(사례 구분 case_track) | none
 *   columns : 제목 뒤에 붙는 칸 [머리글, 글 → 값]
 */
function wooin_board_config( string $type ): array {
	$area_chip = static function ( WP_Post $p ): string {
		$terms = get_the_terms( $p, 'wooin_practice_area' );
		$name  = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
		return $name ? '<span class="wooin-chip' . ( str_starts_with( $name, '법인' ) ? ' is-dark' : '' ) . '">' . esc_html( $name ) . '</span>' : '';
	};
	$configs = array(
		'wooin_news'   => array(
			'type'        => 'wooin_news',
			'label'       => '우인 소식',
			'filter'      => 'none',
			'chip'        => static fn( WP_Post $p ) => $area_chip( $p ) ? $area_chip( $p ) : '<span class="wooin-chip is-line">소식</span>',
			'chip_head'   => '구분',
			'columns'     => array(),
			'excerpt'     => true,
			'empty'       => '등록된 소식이 없습니다.',
			'placeholder' => '제목·내용 검색',
		),
		'wooin_case'   => array(
			'type'        => 'wooin_case',
			'label'       => '해결 사례',
			'filter'      => 'track',
			'chip'        => static function ( WP_Post $p ) use ( $area_chip ): string {
				$chip = $area_chip( $p );
				return $chip ? $chip : ( 'corporate' === get_post_meta( $p->ID, 'case_track', true ) ? '<span class="wooin-chip is-dark">법인</span>' : '<span class="wooin-chip">개인</span>' );
			},
			'chip_head'   => '분야',
			'columns'     => array(
				array( '채무 규모', static fn( WP_Post $p ) => esc_html( (string) get_post_meta( $p->ID, 'debt_before', true ) ) ),
				array( '결과', static fn( WP_Post $p ) => '<b>' . esc_html( (string) ( get_post_meta( $p->ID, 'debt_result', true ) ?: get_post_meta( $p->ID, 'result_stage', true ) ) ) . '</b>' ),
			),
			'excerpt'     => false,
			'empty'       => '등록된 사례가 없습니다. 의뢰인 동의와 익명화 검수를 마친 사례부터 게재됩니다.',
			'placeholder' => '사례 검색 (예: 제조업, 도박)',
		),
		'wooin_review' => array(
			'type'        => 'wooin_review',
			'label'       => '의뢰인 후기',
			'filter'      => 'area',
			'chip'        => $area_chip,
			'chip_head'   => '분야',
			'columns'     => array(
				array( '작성자', static fn( WP_Post $p ) => esc_html( (string) get_post_meta( $p->ID, 'reviewer', true ) ) ),
			),
			'excerpt'     => true,
			'empty'       => '등록된 후기가 없습니다.',
			'cafe'        => true,
			'placeholder' => '제목·내용 검색',
		),
	);
	return $configs[ $type ];
}

/** 게시판 목록 — 분야/구분 탭 · 검색(?q=) · 쪽 번호(?pg=) · 공지 상단 고정 · 법인 우선. */
function wooin_board_list( array $cfg ): string {
	// phpcs:disable WordPress.Security.NonceVerification -- 공개 목록 필터(읽기 전용)
	$area  = isset( $_GET['area'] ) ? sanitize_title( wp_unslash( $_GET['area'] ) ) : '';
	$track = isset( $_GET['type'] ) && in_array( $_GET['type'], array( 'corporate', 'personal' ), true ) ? sanitize_key( $_GET['type'] ) : '';
	$q     = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
	$page  = isset( $_GET['pg'] ) ? max( 1, (int) $_GET['pg'] ) : 1;
	// phpcs:enable

	$base   = get_post_type_archive_link( $cfg['type'] );
	$filter = array();
	if ( 'area' === $cfg['filter'] && $area ) {
		$filter['tax_query'] = array( array( 'taxonomy' => 'wooin_practice_area', 'field' => 'slug', 'terms' => $area ) );
	}
	if ( 'track' === $cfg['filter'] && $track ) {
		$filter['meta_query'] = array( array( 'key' => 'case_track', 'value' => $track ) );
	}
	if ( '' !== $q ) {
		$filter['s'] = $q;
	}

	// 공지(고정) — 첫 쪽에만 보이고(건수에는 늘 포함), 검색 중에는 숨김
	$pinned = array();
	if ( '' === $q ) {
		$pinned = get_posts(
			wooin_board_order_args(
				array(
					'post_type'      => $cfg['type'],
					'post_status'    => 'publish',
					'posts_per_page' => 10,
					'meta_query'     => array( array( 'key' => 'pinned', 'value' => '1' ) ),
				)
			)
		);
	}

	$args = wooin_board_order_args(
		array_merge(
			$filter,
			array(
				'post_type'      => $cfg['type'],
				'post_status'    => 'publish',
				'posts_per_page' => WOOIN_BOARD_PER_PAGE,
				'paged'          => $page,
			)
		)
	);
	// 고정 글은 일반 목록에서 뺀다 (모든 쪽에서 같은 기준)
	$args['meta_query'][] = array(
		'relation' => 'OR',
		array( 'key' => 'pinned', 'compare' => 'NOT EXISTS' ),
		array( 'key' => 'pinned', 'value' => '1', 'compare' => '!=' ),
	);
	$query = new WP_Query( $args );

	// 탭
	$tabs = array();
	if ( 'area' === $cfg['filter'] ) {
		$tabs = array( '' => '전체' );
		foreach ( get_terms( array( 'taxonomy' => 'wooin_practice_area', 'hide_empty' => false, 'orderby' => 'term_id' ) ) as $t ) {
			$tabs[ $t->slug ] = $t->name;
		}
		$current = $area;
		$param   = 'area';
	} elseif ( 'track' === $cfg['filter'] ) {
		$tabs    = array( '' => '전체', 'corporate' => '법인회생 · 파산', 'personal' => '개인회생 · 파산' );
		$current = $track;
		$param   = 'type';
	}

	$html = '';
	if ( ! empty( $cfg['cafe'] ) && function_exists( 'wooin_core_site_info' ) && wooin_core_site_info( 'cafe_url' ) ) {
		$html .= '<a class="wooin-cafe-link is-banner" href="' . esc_url( wooin_core_site_info( 'cafe_url' ) ) . '" target="_blank" rel="noopener"><span class="wooin-cafe-icon" aria-hidden="true"></span><span><b>네이버 카페 바로가기</b><small>더 많은 의뢰인 후기와 진행 소식을 카페에서 확인하세요</small></span><span class="wooin-arrow" aria-hidden="true"></span></a>';
	}
	$html .= '<div class="wooin-board-tools">';
	if ( $tabs ) {
		$html .= '<nav class="wooin-board-tabs" aria-label="구분">';
		foreach ( $tabs as $slug => $name ) {
			$url   = $slug ? add_query_arg( $param, $slug, $base ) : $base;
			$html .= '<a href="' . esc_url( $url ) . '"' . ( $slug === $current ? ' aria-current="page"' : '' ) . '>' . esc_html( $name ) . '</a>';
		}
		$html .= '</nav>';
	}
	$uid   = wp_unique_id( 'board-q-' );
	$html .= '<form class="wooin-board-search" role="search" action="' . esc_url( $base ) . '" method="get">';
	if ( $tabs && $current ) {
		$html .= '<input type="hidden" name="' . esc_attr( $param ) . '" value="' . esc_attr( $current ) . '">';
	}
	$html .= '<label class="screen-reader-text" for="' . esc_attr( $uid ) . '">' . esc_html( $cfg['label'] ) . ' 검색</label><input id="' . esc_attr( $uid ) . '" type="search" name="q" value="' . esc_attr( $q ) . '" placeholder="' . esc_attr( $cfg['placeholder'] ) . '"><button type="submit">검색</button></form></div>';

	$total  = (int) $query->found_posts + count( $pinned );
	$pinned = 1 === $page ? $pinned : array();
	$html  .= '<p class="wooin-board-count">총 <b>' . $total . '</b>건' . ( '' !== $q ? ' · 「' . esc_html( $q ) . '」 검색 결과' : '' ) . '</p>';

	if ( ! $pinned && ! $query->have_posts() ) {
		return '<div ' . get_block_wrapper_attributes( array( 'class' => 'wooin-board-wrap' ) ) . '>' . $html . '<p class="wooin-board-empty">' . esc_html( $cfg['empty'] ) . '</p></div>';
	}

	$cols  = count( $cfg['columns'] );
	$head  = '<span role="columnheader">번호</span><span role="columnheader">' . esc_html( $cfg['chip_head'] ) . '</span><span role="columnheader">제목</span>';
	foreach ( $cfg['columns'] as $c ) {
		$head .= '<span role="columnheader">' . esc_html( $c[0] ) . '</span>';
	}
	$head .= '<span role="columnheader">등록일</span>';

	$row = static function ( WP_Post $post, string $no, bool $is_pin ) use ( $cfg ): string {
		$cells = '';
		foreach ( $cfg['columns'] as $c ) {
			$cells .= '<span role="cell" class="is-extra">' . $c[1]( $post ) . '</span>';
		}
		$sub = $cfg['excerpt'] ? '<small>' . esc_html( wp_trim_words( wp_strip_all_tags( $post->post_excerpt ? $post->post_excerpt : $post->post_content ), 28, '…' ) ) . '</small>' : '';
		return sprintf(
			'<a class="wooin-board-row%1$s" role="row" href="%2$s"><span role="cell" class="is-no">%3$s</span><span role="cell" class="is-area">%4$s</span><span role="cell" class="is-title"><strong>%5$s</strong>%6$s</span>%7$s<span role="cell" class="is-date">%8$s</span></a>',
			$is_pin ? ' is-pinned' : '',
			esc_url( get_permalink( $post ) ),
			$no,
			$cfg['chip']( $post ),
			esc_html( get_the_title( $post ) ),
			$sub,
			$cells,
			esc_html( get_the_date( 'Y.m.d', $post ) )
		);
	};

	$html .= '<div class="wooin-board has-' . $cols . '-extra" role="table" aria-label="' . esc_attr( $cfg['label'] ) . ' 목록"><div class="wooin-board-head" role="row">' . $head . '</div>';
	foreach ( $pinned as $post ) {
		$html .= $row( $post, '<span class="wooin-chip is-notice">공지</span>', true );
	}
	$no = $query->found_posts - ( $page - 1 ) * WOOIN_BOARD_PER_PAGE;
	foreach ( $query->posts as $post ) {
		$html .= $row( $post, (string) $no--, false );
	}
	$html .= '</div>';

	if ( $query->max_num_pages > 1 ) {
		$html .= '<nav class="wooin-board-pages" aria-label="쪽 번호">';
		for ( $i = 1; $i <= $query->max_num_pages; $i++ ) {
			$url   = add_query_arg( array_filter( array( 'area' => $area, 'type' => $track, 'q' => $q, 'pg' => $i > 1 ? $i : null ) ), $base );
			$html .= '<a href="' . esc_url( $url ) . '"' . ( $i === $page ? ' aria-current="page"' : '' ) . '>' . $i . '</a>';
		}
		$html .= '</nav>';
	}

	return '<div ' . get_block_wrapper_attributes( array( 'class' => 'wooin-board-wrap' ) ) . '>' . $html . '</div>';
}

/* ---------------------------------------------------------------- 상세 (소식) */

function wooin_render_board_detail(): string {
	$post = get_post();
	if ( ! $post ) {
		return '';
	}
	$terms = get_the_terms( $post, 'wooin_practice_area' );
	$area  = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
	$label = get_post_type_object( $post->post_type )->labels->singular_name;

	$html  = '<article class="wooin-review-article">';
	$html .= '<header class="wooin-review-head"><p class="wooin-review-tags">';
	$html .= get_post_meta( $post->ID, 'pinned', true ) ? '<span class="wooin-chip is-notice">공지</span>' : '';
	$html .= $area ? '<span class="wooin-chip' . ( str_starts_with( $area, '법인' ) ? ' is-dark' : '' ) . '">' . esc_html( $area ) . '</span>' : '';
	$html .= '</p><h2>' . esc_html( get_the_title( $post ) ) . '</h2>';
	$html .= '<p class="wooin-review-info"><span>등록일 ' . esc_html( get_the_date( 'Y.m.d', $post ) ) . '</span></p></header>';
	$html .= '<div class="wooin-review-body">' . apply_filters( 'the_content', $post->post_content ) . '</div></article>'; // phpcs:ignore WordPress.Security.EscapeOutput -- 본문 필터 결과

	$prev  = get_adjacent_post( false, '', true );
	$next  = get_adjacent_post( false, '', false );
	$html .= '<nav class="wooin-review-nav" aria-label="다른 글">';
	$html .= '<div><small>이전 ' . esc_html( $label ) . '</small>' . ( $prev ? '<a href="' . esc_url( get_permalink( $prev ) ) . '">' . esc_html( get_the_title( $prev ) ) . '</a>' : '<span>이전 글이 없습니다</span>' ) . '</div>';
	$html .= '<div><small>다음 ' . esc_html( $label ) . '</small>' . ( $next ? '<a href="' . esc_url( get_permalink( $next ) ) . '">' . esc_html( get_the_title( $next ) ) . '</a>' : '<span>다음 글이 없습니다</span>' ) . '</div>';
	$html .= '</nav><p class="wooin-review-list-link"><a class="wooin-pill-link" href="' . esc_url( get_post_type_archive_link( $post->post_type ) ) . '">목록으로</a></p>';

	return '<div ' . get_block_wrapper_attributes( array( 'class' => 'wooin-review-detail' ) ) . '>' . $html . '</div>';
}
