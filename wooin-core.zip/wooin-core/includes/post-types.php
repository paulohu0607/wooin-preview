<?php
/**
 * 콘텐츠 유형. URL 은 초기기획 v0.1 3절 URL 초안 기준.
 *
 * 상담(접수)은 공개 콘텐츠와 분리해 별도 저장소로 구현할 예정이므로 여기서 글 유형으로 만들지 않는다.
 * 메인 설정(wooin_home)은 초안/게시 분리 설계 확정 후 추가한다.
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'wooin_core_register_post_types' );

function wooin_core_register_post_types(): void {
	$types = wooin_core_content_types();

	$defs = array(
		'wooin_service' => array(
			'name'     => '업무분야',
			'singular' => '업무분야',
			'slug'     => 'services',
			'icon'     => 'dashicons-portfolio',
			'public'   => true,
			'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes', 'revisions' ),
		),
		'wooin_person'  => array(
			'name'     => '구성원',
			'singular' => '구성원',
			'slug'     => 'people',
			'icon'     => 'dashicons-businessperson',
			'public'   => true,
			'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes', 'revisions' ),
		),
		'wooin_case'    => array(
			'name'     => '해결 사례',
			'singular' => '해결 사례',
			'slug'     => 'cases',
			'icon'     => 'dashicons-media-document',
			'public'   => true,
			'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'revisions' ),
		),
		// FAQ 는 단독 상세 URL 없이 메인·분야 상세·/faq/ 페이지에서 재사용한다.
		'wooin_faq'     => array(
			'name'     => 'FAQ',
			'singular' => 'FAQ',
			'slug'     => false,
			'icon'     => 'dashicons-editor-help',
			'public'   => false,
			'supports' => array( 'title', 'editor', 'page-attributes', 'revisions' ),
		),
	);

	foreach ( $defs as $post_type => $def ) {
		register_post_type(
			$post_type,
			array(
				'labels'              => array(
					'name'          => $def['name'],
					'singular_name' => $def['singular'],
					'add_new'       => '새로 추가',
					'add_new_item'  => $def['singular'] . ' 추가',
					'edit_item'     => $def['singular'] . ' 수정',
					'all_items'     => '전체 ' . $def['name'],
					'search_items'  => $def['name'] . ' 검색',
					'not_found'     => '등록된 항목이 없습니다.',
				),
				'public'              => $def['public'],
				// 쿼리 블록은 조회 불가 유형을 'post' 로 바꿔 버리므로 FAQ 도 조회 가능으로 둔다(단독 URL 은 rewrite false).
				'publicly_queryable'  => true,
				'exclude_from_search' => ! $def['public'],
				'show_ui'             => true,
				'show_in_rest'        => true,
				'menu_icon'           => $def['icon'],
				'menu_position'       => 21,
				'has_archive'         => $def['slug'] ? $def['slug'] : false,
				'rewrite'             => $def['slug'] ? array( 'slug' => $def['slug'], 'with_front' => false ) : false,
				'hierarchical'        => false,
				'supports'            => $def['supports'],
				'capability_type'     => $types[ $post_type ],
				'map_meta_cap'        => true,
			)
		);
	}
}
