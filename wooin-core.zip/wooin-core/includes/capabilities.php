<?php
/**
 * 역할·권한 (관리자설계 v0.2 9절 제안 기준, 확정 전).
 *
 * 메뉴 숨김이 아니라 capability 로 막는다. REST 요청도 같은 capability 로 검증된다.
 * 상담 권한 (저장·화면은 wooin-consult 플러그인):
 *   wooin_view_inquiries_personal / _corporate  구분별 열람 (담당자마다 한쪽만 줄 수 있음)
 *   wooin_manage_inquiries   상태 변경 · 담당자 배정 · 메모
 *   wooin_delete_inquiries   삭제
 *   wooin_inquiry_settings   알림 받을 이메일 · 보유기간 등 설정
 * 상담 권한은 콘텐츠 게시 권한과 별개다 (검수자도 상담은 못 본다).
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * 사이트 기능 플러그인이 관리하는 콘텐츠 유형과 capability 접두어.
 *
 * @return array<string, array{0:string,1:string}> post_type => [단수, 복수]
 */
function wooin_core_content_types(): array {
	return array(
		'wooin_service' => array( 'wooin_service', 'wooin_services' ),
		'wooin_person'  => array( 'wooin_person', 'wooin_people' ),
		'wooin_case'    => array( 'wooin_case', 'wooin_cases' ),
		'wooin_faq'     => array( 'wooin_faq', 'wooin_faqs' ),
		'wooin_video'   => array( 'wooin_video', 'wooin_videos' ),
		'wooin_review'  => array( 'wooin_review', 'wooin_reviews' ),
		'wooin_news'    => array( 'wooin_news_item', 'wooin_news_items' ),
	);
}

/**
 * 콘텐츠 유형별 primitive capability 목록.
 *
 * @param bool $can_publish 게시·타인 글 수정·공개 글 수정/삭제 포함 여부.
 */
function wooin_core_content_caps( bool $can_publish ): array {
	$caps = array();
	foreach ( wooin_core_content_types() as $names ) {
		$plural = $names[1];
		$caps[] = "edit_{$plural}";
		$caps[] = "delete_{$plural}";
		if ( $can_publish ) {
			$caps[] = "publish_{$plural}";
			$caps[] = "edit_others_{$plural}";
			$caps[] = "edit_published_{$plural}";
			$caps[] = "edit_private_{$plural}";
			$caps[] = "read_private_{$plural}";
			$caps[] = "delete_others_{$plural}";
			$caps[] = "delete_published_{$plural}";
			$caps[] = "delete_private_{$plural}";
		}
	}

	// 칼럼은 기본 글(post) 사용. 소식은 wooin_news.
	$caps[] = 'edit_posts';
	$caps[] = 'delete_posts';
	$caps[] = 'wooin_assign_terms';
	if ( $can_publish ) {
		$caps = array_merge(
			$caps,
			array(
				'publish_posts',
				'edit_others_posts',
				'edit_published_posts',
				'delete_others_posts',
				'delete_published_posts',
				'read_private_posts',
				'wooin_manage_terms',
			)
		);
	}

	return $caps;
}

/**
 * 역할 정의. 키는 WordPress 역할 slug.
 */
function wooin_core_roles(): array {
	// 메인 화면: 작성자는 임시저장·검토 요청까지, 검수자부터 게시·복원
	$writer   = array_merge( array( 'read', 'upload_files', 'wooin_edit_home' ), wooin_core_content_caps( false ) );
	$reviewer = array_merge( array( 'read', 'upload_files', 'wooin_edit_home', 'wooin_publish_home' ), wooin_core_content_caps( true ) );
	$operator = array_merge(
		$reviewer,
		array(
			'wooin_manage_site_info',
			'wooin_view_inquiries_personal',
			'wooin_view_inquiries_corporate',
			'wooin_manage_inquiries',
			'wooin_delete_inquiries',
			'wooin_inquiry_settings',
			'edit_theme_options',
		)
	);

	return array(
		'wooin_writer'     => array( '콘텐츠 작성자', $writer ),
		'wooin_reviewer'   => array( '콘텐츠 검수자', $reviewer ),
		'wooin_consultant' => array( '상담 담당자 (개인·법인)', array( 'read', 'wooin_view_inquiries_personal', 'wooin_view_inquiries_corporate', 'wooin_manage_inquiries' ) ),
		'wooin_consultant_personal'  => array( '상담 담당자 (개인만)', array( 'read', 'wooin_view_inquiries_personal', 'wooin_manage_inquiries' ) ),
		'wooin_consultant_corporate' => array( '상담 담당자 (법인만)', array( 'read', 'wooin_view_inquiries_corporate', 'wooin_manage_inquiries' ) ),
		'wooin_operator'   => array( '운영 책임자', $operator ),
	);
}

/**
 * 역할을 생성하거나 정의대로 다시 맞추고, administrator 에게 전체 권한을 준다.
 */
function wooin_core_sync_roles(): void {
	$all_caps = array();

	foreach ( wooin_core_roles() as $slug => $role ) {
		remove_role( $slug );
		add_role( $slug, $role[0], array_fill_keys( $role[1], true ) );
		$all_caps = array_merge( $all_caps, $role[1] );
	}

	$admin = get_role( 'administrator' );
	if ( $admin ) {
		foreach ( array_unique( $all_caps ) as $cap ) {
			$admin->add_cap( $cap );
		}
	}

	update_option( 'wooin_core_roles_version', WOOIN_CORE_VERSION, false );
}
