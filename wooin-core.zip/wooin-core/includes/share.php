<?php
/**
 * 링크 공유 미리보기 (카카오톡 · 문자 · 페이스북 등) — 오픈그래프 이미지와 설명.
 *
 * - 기본 공유 이미지: assets/share.jpg (1200×630, 회생파산연구소 로고 + 법률사무소 우인 + 업무분야).
 *   글에 대표 이미지가 있으면 그 글은 대표 이미지가 먼저 쓰인다.
 * - 설명: 공통정보 「공유 설명」 (비우면 기본 문구).
 * - The SEO Framework 가 켜져 있으면 그 플러그인의 빈자리만 채운다
 *   (그 플러그인 설정에 직접 넣은 공유 이미지·설명이 있으면 그것이 먼저). 꺼져 있으면 여기서 직접 출력한다.
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

const WOOIN_SHARE_DESCRIPTION = '법인회생 · 법인파산 · 개인회생 · 개인파산 — 9년간 도산 분야만 연구한 이서영 변호사가 처음부터 끝까지 함께합니다.';

function wooin_share_image_url(): string {
	return plugins_url( 'assets/share.jpg', WOOIN_CORE_FILE );
}

function wooin_share_description(): string {
	$saved = function_exists( 'wooin_core_site_info' ) ? trim( wooin_core_site_info( 'share_description' ) ) : '';
	return '' !== $saved ? $saved : WOOIN_SHARE_DESCRIPTION;
}

function wooin_share_has_tsf(): bool {
	return defined( 'THE_SEO_FRAMEWORK_VERSION' ) || function_exists( 'tsf' );
}

// The SEO Framework: 공유 이미지 — 그 플러그인 설정의 이미지 다음, 테마 헤더·로고보다 앞에
add_filter(
	'the_seo_framework_image_generation_params',
	static function ( $params, $args = null, $context = 'social' ) {
		if ( 'social' !== $context || ! is_array( $params ) ) {
			return $params;
		}
		$ours     = array(
			'wooin' => static function () {
				yield array( 'url' => wooin_share_image_url(), 'id' => 0 );
			},
		);
		$fallback = (array) ( $params['fallback'] ?? array() );
		$pos      = array_search( 'settings', array_keys( $fallback ), true );
		$params['fallback'] = false === $pos
			? $ours + $fallback
			: array_slice( $fallback, 0, $pos + 1, true ) + $ours + array_slice( $fallback, $pos + 1, null, true );
		return $params;
	},
	10,
	3
);

// The SEO Framework: 자동으로 만든 설명이 비면(메인처럼 본문이 없는 페이지) 기본 설명
add_filter(
	'the_seo_framework_generated_description',
	static fn( $desc ) => '' === trim( (string) $desc ) ? wooin_share_description() : $desc,
	10,
	1
);

// SEO 플러그인이 없을 때: 직접 출력
add_action(
	'wp_head',
	static function () {
		if ( wooin_share_has_tsf() || is_admin() ) {
			return;
		}
		$name  = function_exists( 'wooin_core_site_info' ) ? wooin_core_site_info( 'brand_name' ) : get_bloginfo( 'name' );
		$title = is_front_page() ? $name : wp_get_document_title();
		$desc  = wooin_share_description();
		$image = wooin_share_image_url();
		$url   = home_url( add_query_arg( array() ) );
		if ( is_singular() ) {
			$url   = (string) get_permalink();
			$thumb = get_the_post_thumbnail_url( null, 'large' );
			$image = $thumb ? $thumb : $image;
			$ex    = has_excerpt() ? wp_strip_all_tags( get_the_excerpt() ) : '';
			$desc  = '' !== $ex ? $ex : $desc;
		}
		$tags = array(
			array( 'name', 'description', $desc ),
			array( 'property', 'og:type', is_singular( 'post' ) ? 'article' : 'website' ),
			array( 'property', 'og:locale', 'ko_KR' ),
			array( 'property', 'og:site_name', $name ),
			array( 'property', 'og:title', $title ),
			array( 'property', 'og:description', $desc ),
			array( 'property', 'og:url', $url ),
			array( 'property', 'og:image', $image ),
			array( 'name', 'twitter:card', 'summary_large_image' ),
		);
		foreach ( $tags as $t ) {
			printf( '<meta %s="%s" content="%s">' . "\n", esc_attr( $t[0] ), esc_attr( $t[1] ), esc_attr( $t[2] ) );
		}
	},
	1
);
