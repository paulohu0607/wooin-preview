<?php
/**
 * 우인 초기 설정 — 관리자 「도구 › 우인 초기 설정」
 *
 * 새 서버(카페24 등)에 테마·플러그인을 올린 뒤 버튼 한 번으로 사이트 뼈대와 확정 원고를 넣는다.
 * - 이미 있는 것은 건드리지 않는다(슬러그·종류 기준). 아무것도 지우지 않는다. 여러 번 눌러도 중복되지 않는다.
 * - 넣는 것: 기본 설정(이름·시간대·고유주소) · 공통정보 · 유튜브 연동 설정(키 제외) · 페이지 · 첫 화면/칼럼 지정 ·
 *   분야/소식 구분 · 업무분야 4 · 구성원 3 · FAQ · 해결 사례 · 의뢰인 후기 · (선택) 유튜브 영상 불러오기.
 * - 넣지 않는 것: [샘플] 소식 같은 확인용 글, API 키 · 비밀번호.
 * 원고: data/setup-content.php, data/faq-corporate.json (개발 시드 dev/seed.php 도 같은 함수를 쓴다).
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

function wooin_setup_data(): array {
	static $data = null;
	if ( null === $data ) {
		$data = require WOOIN_CORE_DIR . 'data/setup-content.php';
	}
	return $data;
}

/** 종류·슬러그로 이미 있는 글 ID (휴지통 포함 — 지운 것을 되살리지 않는다). */
function wooin_setup_find( string $type, string $slug, int $parent = -1 ): int {
	$args = array(
		'post_type'      => $type,
		'name'           => $slug,
		'post_status'    => 'any',
		'posts_per_page' => 1,
		'fields'         => 'ids',
		'no_found_rows'  => true,
	);
	if ( $parent >= 0 ) {
		$args['post_parent'] = $parent;
	}
	$ids = get_posts( $args );
	if ( ! $ids ) {
		$args['post_status'] = 'trash';
		$ids                 = get_posts( $args );
	}
	return $ids ? (int) $ids[0] : 0;
}

function wooin_setup_has_any( string $type ): bool {
	return (bool) get_posts( array( 'post_type' => $type, 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true ) );
}

/**
 * 초기 설정 실행.
 *
 * @param array $opts hide_search(bool) 검색엔진 노출 차단 · sync_videos(bool) 유튜브 영상 불러오기.
 * @return string[] 처리 기록 (화면 표시용).
 */
function wooin_core_setup( array $opts = array() ): array {
	$opts  = wp_parse_args( $opts, array( 'hide_search' => true, 'sync_videos' => true ) );
	$data  = wooin_setup_data();
	$log   = array();
	$made  = static function ( string $what ) use ( &$log ): void {
		$log[] = '✔ ' . $what;
	};
	$skip  = static function ( string $what ) use ( &$log ): void {
		$log[] = '· ' . $what . ' — 이미 있어 그대로 둠';
	};
	$block = static fn( string $slug ): string => '<!-- wp:pattern {"slug":"wooin/' . $slug . '"} /-->';

	// ---- 기본 설정
	foreach ( $data['options'] as $key => $value ) {
		update_option( $key, $value );
	}
	if ( '/%postname%/' !== get_option( 'permalink_structure' ) ) {
		update_option( 'permalink_structure', '/%postname%/' );
	}
	update_option( 'blog_public', $opts['hide_search'] ? 0 : 1 );
	$made( '사이트 이름 · 시간대 · 고유주소(/글이름/) · 검색엔진 ' . ( $opts['hide_search'] ? '노출 차단' : '노출 허용' ) );

	// 공통정보 · 유튜브 설정: 비어 있는 항목만 채운다 (관리자가 고친 값 유지, API 키는 건드리지 않음)
	foreach ( array( 'wooin_site_info' => 'site_info', 'wooin_youtube' => 'youtube' ) as $option => $key ) {
		$saved = get_option( $option, array() );
		$saved = is_array( $saved ) ? $saved : array();
		foreach ( $data[ $key ] as $k => $v ) {
			if ( empty( $saved[ $k ] ) ) {
				$saved[ $k ] = $v;
			}
		}
		update_option( $option, $saved );
	}
	$made( '공통정보(전화 · 주소 · 운영시간) · 유튜브 연동 설정' );

	// ---- 분류
	$areas = array();
	foreach ( array(
		'corporate-rehabilitation' => '법인회생',
		'corporate-bankruptcy'     => '법인파산',
		'personal-rehabilitation'  => '개인회생',
		'personal-bankruptcy'      => '개인파산',
	) as $slug => $name ) {
		$t              = term_exists( $slug, 'wooin_practice_area' );
		$t              = $t ? $t : wp_insert_term( $name, 'wooin_practice_area', array( 'slug' => $slug ) );
		$areas[ $slug ] = is_array( $t ) ? (int) $t['term_id'] : 0;
	}
	wooin_news_default_terms();
	$made( '분야(법인회생 · 법인파산 · 개인회생 · 개인파산) · 소식 구분(우인 소식 · 도산 소식)' );

	// ---- 페이지
	$page = static function ( string $slug, string $title, string $content, int $parent = 0 ) use ( $made, $skip ): int {
		$id = wooin_setup_find( 'page', $slug, $parent );
		if ( $id ) {
			$skip( '페이지 「' . $title . '」' );
			return $id;
		}
		$id = (int) wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => $title,
				'post_name'    => $slug,
				'post_parent'  => $parent,
				'post_content' => $content,
			)
		);
		update_post_meta( $id, '_wp_page_template', 'page-sub' );
		$made( '페이지 「' . $title . '」' );
		return $id;
	};
	$soon = $block( 'coming-soon' );
	$page( 'about', '인사말', $block( 'page-greeting' ) );
	$page( 'why', '왜 우인인가', $block( 'home-why' ) . $block( 'home-about' ) );
	$page( 'location', '오시는 길', $block( 'page-location' ) );
	$page( 'procedure', '회생·파산 절차', $block( 'home-process' ) );
	$page( 'support', '지원 사업 안내', $soon );
	$page( 'major-cases', '주요 도산 사건', $soon );
	$page( 'faq', '자주 묻는 질문', $block( 'page-faq' ) );
	$page( 'notices', '회생·파산 기업 공고', $soon );
	$page( 'consultation-guide', '상담 절차 안내', $block( 'page-guide' ) );
	$page( 'privacy', '개인정보처리방침', $soon );
	$page( 'disclaimer', '면책공고', $soon );
	$page( 'email-policy', '이메일무단수집거부', $soon );
	$form    = '<!-- wp:group {"className":"wooin-sub-section","layout":{"type":"constrained","contentSize":"860px"}} --><div class="wp-block-group wooin-sub-section">' . $block( 'consult-form' ) . '</div><!-- /wp:group -->';
	$contact = $page( 'contact', '상담 신청', $form );
	$page( 'corporate', '법인회생·파산 상담 신청', $form, $contact );
	$page( 'personal', '개인회생·파산 상담 신청', $form, $contact );

	// 첫 화면 = 고정 페이지(모양은 front-page 템플릿), 칼럼 = 글 목록
	$front  = $page( 'home', '홈', '' );
	$column = $page( 'column', '전문가 칼럼', '' );
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $front );
	update_option( 'page_for_posts', $column );
	$made( '첫 화면 · 칼럼 목록 지정' );

	// ---- 업무분야
	if ( function_exists( 'wooin_services_data' ) ) {
		$order = 0;
		$new   = 0;
		foreach ( wooin_services_data() as $slug => $d ) {
			++$order;
			if ( wooin_setup_find( 'wooin_service', $slug ) ) {
				continue;
			}
			++$new;
			$id = wp_insert_post(
				array(
					'post_type'    => 'wooin_service',
					'post_status'  => 'publish',
					'post_title'   => $areas[ $slug ] ? get_term( $areas[ $slug ] )->name : $slug,
					'post_name'    => $slug,
					'post_excerpt' => $data['taglines'][ $slug ] ?? '',
					'menu_order'   => $order,
					'post_content' => $block( 'service-' . $slug ),
				)
			);
			wp_set_object_terms( $id, $areas[ $slug ], 'wooin_practice_area' );
		}
		$new ? $made( '업무분야 ' . $new . '건' ) : $skip( '업무분야' );
	} else {
		$log[] = '! 우인 테마가 켜져 있지 않아 업무분야 · FAQ 초안을 건너뜀 — 테마를 켠 뒤 다시 누르세요';
	}

	// ---- 구성원
	$new = 0;
	foreach ( $data['people'] as $i => $p ) {
		if ( wooin_setup_find( 'wooin_person', $p[0] ) ) {
			continue;
		}
		++$new;
		wp_insert_post(
			array(
				'post_type'    => 'wooin_person',
				'post_status'  => 'publish',
				'post_title'   => $p[1],
				'post_name'    => $p[0],
				'post_excerpt' => $p[2],
				'menu_order'   => $i,
			)
		);
	}
	$new ? $made( '구성원 ' . $new . '명 (이서영 변호사 · 서동기 회계사 · 박만용 세무사)' ) : $skip( '구성원' );
	if ( function_exists( 'wooin_people_migrate' ) && wooin_people_migrate() ) {
		update_option( 'wooin_people_migrated', time(), false );
		$made( '구성원 프로필 · 사진을 관리자 편집 칸으로 옮김' );
	}

	// ---- FAQ (한 건도 없을 때만)
	if ( wooin_setup_has_any( 'wooin_faq' ) ) {
		$skip( '자주 묻는 질문' );
	} else {
		$n   = 0;
		$add = static function ( string $q, string $a, string $area, string $group ) use ( &$n, $areas ): void {
			$id = wp_insert_post(
				array(
					'post_type'    => 'wooin_faq',
					'post_status'  => 'publish',
					'post_title'   => $q,
					'post_content' => '<!-- wp:paragraph --><p>' . esc_html( $a ) . '</p><!-- /wp:paragraph -->',
					'menu_order'   => ++$n,
				)
			);
			wp_set_object_terms( $id, $areas[ $area ], 'wooin_practice_area' );
			update_post_meta( $id, 'faq_group', $group );
		};
		$json = json_decode( (string) file_get_contents( WOOIN_CORE_DIR . 'data/faq-corporate.json' ), true );
		foreach ( $json['groups'] as $g ) {
			foreach ( $g['items'] as $item ) {
				$add( $item['q'], $item['a'], $json['area'], $g['stage'] );
			}
		}
		if ( function_exists( 'wooin_services_data' ) ) {
			foreach ( array( 'corporate-bankruptcy' => '법인파산', 'personal-rehabilitation' => '개인회생', 'personal-bankruptcy' => '개인파산' ) as $slug => $label ) {
				foreach ( wooin_services_data()[ $slug ]['faq'] as $item ) {
					$add( $item[0], $item[1], $slug, $label );
				}
			}
		}
		$made( '자주 묻는 질문 ' . $n . '건 (법인회생 노션 원문 + 분야별 초안)' );
	}

	// ---- 해결 사례 (한 건도 없을 때만)
	if ( wooin_setup_has_any( 'wooin_case' ) ) {
		$skip( '해결 사례' );
	} else {
		foreach ( $data['cases'] as $i => $c ) {
			$id = wp_insert_post(
				array(
					'post_type'    => 'wooin_case',
					'post_status'  => 'publish',
					'post_title'   => $c[0],
					'menu_order'   => $i + 1,
					'post_excerpt' => $c[2] . ' · 채무 ' . $c[3] . ' → ' . $c[4],
					'post_content' => $data['case_body'],
				)
			);
			wp_set_object_terms( $id, $areas[ $c[1] ], 'wooin_practice_area' );
			foreach ( array( 'case_track' => 'personal', 'client_profile' => $c[2], 'debt_before' => $c[3], 'debt_result' => $c[4], 'reduction_rate' => $c[5], 'repay_period' => $c[6], 'result_stage' => $c[7] ) as $k => $v ) {
				update_post_meta( $id, $k, $v );
			}
		}
		$made( '해결 사례 ' . count( $data['cases'] ) . '건 (wooin.net 공개 성공사례)' );
	}

	// ---- 의뢰인 후기 (한 건도 없을 때만) — 등록 시각을 1분씩 띄워 이전/다음 글이 순서대로 이어지게
	if ( wooin_setup_has_any( 'wooin_review' ) ) {
		$skip( '의뢰인 후기' );
	} else {
		$count = count( $data['reviews'] );
		foreach ( $data['reviews'] as $i => $r ) {
			$id = wp_insert_post(
				array(
					'post_type'    => 'wooin_review',
					'post_status'  => 'publish',
					'post_date'    => wp_date( 'Y-m-d H:i:s', time() - ( $count - $i ) * 60 ),
					'post_title'   => $r[2],
					'post_excerpt' => $r[5],
					'post_content' => implode( '', array_map( static fn( $p ) => '<!-- wp:paragraph --><p>' . esc_html( $p ) . '</p><!-- /wp:paragraph -->', explode( "\n\n", $r[6] ) ) ),
				)
			);
			wp_set_object_terms( $id, $areas['personal-rehabilitation'], 'wooin_practice_area' );
			update_post_meta( $id, 'reviewer', $r[1] );
			update_post_meta( $id, 'review_stage', $r[3] );
			update_post_meta( $id, 'source_url', 'https://cafe.naver.com/18997754/' . $r[0] );
			update_post_meta( $id, 'featured', $r[4] );
			update_post_meta( $id, 'consent_ok', true );
		}
		$made( '의뢰인 후기 ' . $count . '건 (게시 동의 받은 카페 후기 원문)' );
	}

	flush_rewrite_rules();

	// ---- 유튜브 영상
	if ( $opts['sync_videos'] && function_exists( 'wooin_yt_sync' ) ) {
		$r     = wooin_yt_sync();
		$log[] = ( $r['errors'] ? '! ' : '✔ ' ) . '유튜브 영상 불러오기 — 신규 ' . (int) $r['created'] . ' · 갱신 ' . (int) $r['updated'] . ( $r['errors'] ? ' · 오류 ' . count( $r['errors'] ) . '건(1시간마다 자동 재시도)' : '' );
	}
	wooin_setup_video_picks();

	update_option( 'wooin_setup_done', time(), false );
	return $log;
}

/** 메인 영상 캐러셀 기본값 — 아직 아무 영상도 고르지 않았을 때만. */
function wooin_setup_video_picks(): void {
	if ( ! function_exists( 'wooin_yt_find' ) || get_posts( array( 'post_type' => 'wooin_video', 'meta_key' => 'home_pick', 'meta_value' => '1', 'posts_per_page' => 1, 'fields' => 'ids' ) ) ) {
		return;
	}
	foreach ( wooin_setup_data()['video_picks'] as $i => $vid ) {
		$post_id = wooin_yt_find( $vid );
		if ( $post_id ) {
			update_post_meta( $post_id, 'home_pick', true );
			update_post_meta( $post_id, 'home_order', $i + 1 );
		}
	}
}

/* ---------------------------------------------------------------- 관리자 화면 */

add_action(
	'admin_menu',
	static function () {
		add_management_page( '우인 초기 설정', '우인 초기 설정', 'manage_options', 'wooin-setup', 'wooin_render_setup_page' );
	}
);

add_action(
	'admin_post_wooin_setup',
	static function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '권한이 없습니다.', 403 );
		}
		check_admin_referer( 'wooin_setup' );
		set_time_limit( 300 );
		$log = wooin_core_setup(
			array(
				'hide_search' => ! empty( $_POST['hide_search'] ),
				'sync_videos' => ! empty( $_POST['sync_videos'] ),
			)
		);
		set_transient( 'wooin_setup_log_' . get_current_user_id(), $log, 600 );
		wp_safe_redirect( admin_url( 'tools.php?page=wooin-setup&done=1' ) );
		exit;
	}
);

function wooin_render_setup_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$theme  = wp_get_theme();
	$checks = array(
		array( 'PHP 8.1 이상', version_compare( PHP_VERSION, '8.1', '>=' ), 'PHP ' . PHP_VERSION ),
		array( '우인 테마 사용 중', 'wooin' === get_stylesheet(), $theme->get( 'Name' ) ),
		array( 'WordPress 6.6 이상', version_compare( get_bloginfo( 'version' ), '6.6', '>=' ), 'WordPress ' . get_bloginfo( 'version' ) ),
	);
	$done = get_option( 'wooin_setup_done' );
	$log  = isset( $_GET['done'] ) ? get_transient( 'wooin_setup_log_' . get_current_user_id() ) : false; // phpcs:ignore WordPress.Security.NonceVerification
	?>
	<div class="wrap">
		<h1>우인 초기 설정</h1>
		<p>사이트 뼈대(페이지 · 메뉴 연결 · 첫 화면)와 확정 원고(구성원 · FAQ · 사례 · 후기 · 공통정보)를 한 번에 넣습니다.<br>
		<strong>이미 있는 글은 건드리지 않고, 아무것도 지우지 않습니다.</strong> 여러 번 눌러도 중복되지 않습니다.</p>

		<?php if ( $log ) : ?>
			<div class="notice notice-success"><p><strong>완료했습니다.</strong></p><ul style="margin-left:1em"><?php foreach ( $log as $line ) : ?><li><?php echo esc_html( $line ); ?></li><?php endforeach; ?></ul><p><a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener">사이트 보기</a></p></div>
		<?php elseif ( $done ) : ?>
			<div class="notice notice-info"><p>마지막 실행: <?php echo esc_html( wp_date( 'Y-m-d H:i', (int) $done ) ); ?></p></div>
		<?php endif; ?>

		<h2>확인</h2>
		<table class="widefat striped" style="max-width:560px"><tbody>
			<?php foreach ( $checks as $c ) : ?>
			<tr><td><?php echo esc_html( $c[0] ); ?></td><td><?php echo $c[1] ? '✅' : '❌'; ?> <?php echo esc_html( $c[2] ); ?></td></tr>
			<?php endforeach; ?>
		</tbody></table>
		<?php if ( 'wooin' !== get_stylesheet() ) : ?>
			<p style="color:#b32d2e"><strong>먼저 「외모 › 테마」에서 우인 테마를 활성화하세요.</strong></p>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:1.5em">
			<input type="hidden" name="action" value="wooin_setup">
			<?php wp_nonce_field( 'wooin_setup' ); ?>
			<p><label><input type="checkbox" name="hide_search" value="1" checked> 검색엔진 노출 차단 (오픈 전까지 켜 두세요 — 오픈 때 「설정 › 읽기」에서 해제)</label></p>
			<p><label><input type="checkbox" name="sync_videos" value="1" checked> 유튜브 영상 지금 불러오기 (30초~1분 걸릴 수 있음)</label></p>
			<?php submit_button( '초기 설정 실행', 'primary', 'submit', false, 'wooin' !== get_stylesheet() ? array( 'disabled' => 'disabled' ) : array() ); ?>
		</form>
	</div>
	<?php
}
