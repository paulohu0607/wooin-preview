<?php
/**
 * 유튜브 영상 — 채널 업로드와 재생목록을 1시간마다 읽어 wooin_video 글로 자동 등록한다.
 *
 * - 기본 경로: YouTube Data API v3 (공식·안정). API 키는 wp-config.php 의 WOOIN_YT_API_KEY 상수 또는
 *   관리자 「유튜브 연동 설정」에 입력한다. 저장소·문서에 키를 넣지 않는다.
 * - 키가 없으면 공개 RSS 피드(피드당 최신 15개)로 대신한다. RSS 는 유튜브 쪽 사정으로 404/500 이 자주 나므로 운영에는 API 를 쓴다.
 * - API 사용량: 동기화 1회에 재생목록 수 × 2~3 단위 (하루 기본 한도 10,000 단위).
 * - 영상 ID(video_id 메타) 기준으로 중복 없이 갱신한다.
 * - 관리자가 숨김(초안/휴지통)·메인 고정(featured)한 영상은 동기화가 상태를 되돌리지 않는다.
 * - 재생목록은 wooin_playlist 분류(슬러그 = 재생목록 ID)로 연결한다.
 * - 추가 채널(법인 위주 채널 등)은 채널 업로드 전체를 하나의 재생목록 줄처럼 묶어 /videos/ 맨 위에 보여준다.
 * - 메인 노출: 영상 편집 화면 「메인 노출 · 직접 등록」에서 체크한 영상(최대 5개, 순서 지정)만 메인 캐러셀에 나온다.
 *   API 없이도 유튜브 주소를 붙여 넣어 영상을 직접 등록할 수 있다.
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

const WOOIN_YT_OPTION = 'wooin_youtube';
const WOOIN_YT_CRON   = 'wooin_youtube_sync';

function wooin_yt_settings(): array {
	$saved = get_option( WOOIN_YT_OPTION, array() );
	return wp_parse_args(
		is_array( $saved ) ? $saved : array(),
		array(
			'channel_id'   => '',
			'channel_url'  => '',
			'channel_name' => '',
			'description'  => '',
			'subscribers'  => '',
			'playlists'    => array(), // 표시 순서대로의 재생목록 ID.
			'channels'     => array(), // 추가 채널 [ [id, 이름, 주소], … ]
			'api_key'      => '',
		)
	);
}

add_action( 'init', 'wooin_core_register_videos' );

function wooin_core_register_videos(): void {
	register_post_type(
		'wooin_video',
		array(
			'labels'          => array(
				'name'          => '이서영 변호사 TV',
				'menu_name'     => '유튜브 영상',
				'singular_name' => '영상',
				'all_items'     => '전체 영상',
				'edit_item'     => '영상 수정',
				'search_items'  => '영상 검색',
				'not_found'     => '동기화된 영상이 없습니다.',
			),
			'public'          => true,
			'show_in_rest'    => true,
			'menu_icon'       => 'dashicons-video-alt3',
			'menu_position'   => 22,
			'has_archive'     => 'videos',
			'rewrite'         => array( 'slug' => 'videos', 'with_front' => false ),
			'supports'        => array( 'title', 'editor', 'excerpt', 'custom-fields' ),
			'capability_type' => array( 'wooin_video', 'wooin_videos' ),
			'map_meta_cap'    => true,
		)
	);

	register_taxonomy(
		'wooin_playlist',
		array( 'wooin_video' ),
		array(
			'labels'            => array( 'name' => '재생목록', 'singular_name' => '재생목록' ),
			'public'            => true,
			'hierarchical'      => false,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rewrite'           => array( 'slug' => 'videos/playlist', 'with_front' => false ),
			'capabilities'      => array(
				'manage_terms' => 'wooin_manage_terms',
				'edit_terms'   => 'wooin_manage_terms',
				'delete_terms' => 'wooin_manage_terms',
				'assign_terms' => 'wooin_assign_terms',
			),
		)
	);

	foreach ( array( 'video_id' => 'string', 'is_short' => 'boolean', 'featured' => 'boolean', 'yt_published' => 'string', 'home_pick' => 'boolean', 'home_order' => 'integer' ) as $key => $type ) {
		register_post_meta(
			'wooin_video',
			$key,
			array(
				'type'          => $type,
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => static fn( $allowed, $meta_key, $post_id ) => current_user_can( 'edit_post', $post_id ),
			)
		);
	}
}

/* ---------------------------------------------------------------- 동기화 */

add_action(
	'init',
	static function () {
		if ( ! wp_next_scheduled( WOOIN_YT_CRON ) ) {
			wp_schedule_event( time() + 60, 'hourly', WOOIN_YT_CRON );
		}
	}
);
add_action( WOOIN_YT_CRON, 'wooin_yt_sync' );

/**
 * 채널 피드와 설정된 재생목록 피드를 읽어 영상을 갱신한다.
 *
 * @return array{created:int,updated:int,errors:string[]}
 */
function wooin_yt_sync(): array {
	$settings = wooin_yt_settings();
	$result   = array( 'created' => 0, 'updated' => 0, 'errors' => array() );

	if ( ! $settings['channel_id'] ) {
		$result['errors'][] = '채널 ID 가 설정되지 않았습니다.';
		wooin_yt_log( $result );
		return $result;
	}

	// 채널 전체 업로드 = 업로드 재생목록(UC… → UU…)
	$sources = array( array( 'channel', $settings['channel_id'], null ) );
	foreach ( $settings['playlists'] as $order => $playlist_id ) {
		$sources[] = array( 'playlist', $playlist_id, $order );
	}
	// 추가 채널: 채널 업로드 전체를 재생목록 줄 하나로 (맨 앞 순서)
	foreach ( $settings['channels'] as $i => $ch ) {
		$sources[] = array( 'extra', $ch[0], -100 + $i, $ch[1] );
	}
	$via           = wooin_yt_api_key() ? 'api' : 'rss';
	$result['via'] = $via;

	foreach ( $sources as $source ) {
		list( $type, $id, $order ) = $source;
		$fetch = 'extra' === $type ? 'channel' : $type;
		$feed  = 'api' === $via ? wooin_yt_fetch_api( $fetch, $id ) : wooin_yt_fetch_rss( $fetch, $id );
		if ( is_wp_error( $feed ) ) {
			$result['errors'][] = ( 'channel' === $type ? '채널 업로드' : ( 'extra' === $type ? '추가 채널 ' : '재생목록 ' ) . $id ) . ': ' . $feed->get_error_message();
			continue;
		}
		$playlist = null === $order ? null : array( $id, $order );

		$term_id = 0;
		if ( $playlist ) {
			$term_id = wooin_yt_playlist_term( $playlist[0], 'extra' === $type && ! empty( $source[3] ) ? $source[3] : $feed['title'], (int) $playlist[1] );
		}

		foreach ( $feed['entries'] as $entry ) {
			$created = wooin_yt_upsert( $entry, $term_id );
			$result[ $created ? 'created' : 'updated' ]++;
		}
	}

	wooin_yt_log( $result );
	return $result;
}

function wooin_yt_api_key(): string {
	if ( defined( 'WOOIN_YT_API_KEY' ) && WOOIN_YT_API_KEY ) {
		return (string) WOOIN_YT_API_KEY;
	}
	$saved = get_option( WOOIN_YT_OPTION, array() );
	return is_array( $saved ) && ! empty( $saved['api_key'] ) ? (string) $saved['api_key'] : '';
}

/**
 * RSS 피드 (키 없이, 최신 15개).
 *
 * @return array{title:string,entries:array}|WP_Error
 */
function wooin_yt_fetch_rss( string $type, string $id ) {
	$query = 'channel' === $type ? 'channel_id=' . rawurlencode( $id ) : 'playlist_id=' . rawurlencode( $id );
	return wooin_yt_fetch( 'https://www.youtube.com/feeds/videos.xml?' . $query );
}

/** Data API GET 한 번. */
function wooin_yt_api_get( string $endpoint, array $query ) {
	$query['key'] = wooin_yt_api_key();
	$response     = wp_remote_get( add_query_arg( $query, 'https://www.googleapis.com/youtube/v3/' . $endpoint ), array( 'timeout' => 15 ) );
	if ( is_wp_error( $response ) ) {
		return $response;
	}
	$body = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( 200 !== wp_remote_retrieve_response_code( $response ) || ! is_array( $body ) ) {
		$reason = is_array( $body ) && isset( $body['error']['message'] ) ? wp_strip_all_tags( $body['error']['message'] ) : 'HTTP ' . wp_remote_retrieve_response_code( $response );
		return new WP_Error( 'wooin_yt_api', $reason );
	}
	return $body;
}

/** ISO 8601 길이(PT1M5S) → 초. */
function wooin_yt_duration( string $iso ): int {
	if ( ! preg_match( '/^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/', $iso, $m ) ) {
		return 0;
	}
	return ( (int) ( $m[1] ?? 0 ) ) * 86400 + ( (int) ( $m[2] ?? 0 ) ) * 3600 + ( (int) ( $m[3] ?? 0 ) ) * 60 + (int) ( $m[4] ?? 0 );
}

/**
 * Data API — 업로드/재생목록 영상 (최대 $max 개, 최신순).
 *
 * @return array{title:string,entries:array}|WP_Error
 */
function wooin_yt_fetch_api( string $type, string $id, int $max = 50 ) {
	$playlist_id = 'channel' === $type ? 'UU' . substr( $id, 2 ) : $id;

	$title = '';
	if ( 'playlist' === $type ) {
		$meta = wooin_yt_api_get( 'playlists', array( 'part' => 'snippet', 'id' => $playlist_id ) );
		if ( is_wp_error( $meta ) ) {
			return $meta;
		}
		$title = $meta['items'][0]['snippet']['title'] ?? '';
	}

	$items = array();
	$page  = '';
	do {
		$q = array( 'part' => 'snippet,contentDetails', 'playlistId' => $playlist_id, 'maxResults' => min( 50, $max - count( $items ) ) );
		if ( $page ) {
			$q['pageToken'] = $page;
		}
		$res = wooin_yt_api_get( 'playlistItems', $q );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$items = array_merge( $items, $res['items'] ?? array() );
		$page  = $res['nextPageToken'] ?? '';
	} while ( $page && count( $items ) < $max );

	// 비공개·삭제 영상 제외 (게시일이 없다)
	$items = array_values( array_filter( $items, static fn( $it ) => ! empty( $it['contentDetails']['videoPublishedAt'] ) ) );
	if ( ! $items ) {
		return array( 'title' => $title, 'entries' => array() );
	}

	// 길이로 쇼츠 구분 (60초 이하 또는 #shorts 표기)
	$ids     = array_map( static fn( $it ) => $it['contentDetails']['videoId'], $items );
	$lengths = array();
	foreach ( array_chunk( $ids, 50 ) as $chunk ) {
		$v = wooin_yt_api_get( 'videos', array( 'part' => 'contentDetails', 'id' => implode( ',', $chunk ) ) );
		if ( ! is_wp_error( $v ) ) {
			foreach ( $v['items'] ?? array() as $row ) {
				$lengths[ $row['id'] ] = wooin_yt_duration( $row['contentDetails']['duration'] ?? '' );
			}
		}
	}

	$entries = array();
	foreach ( $items as $it ) {
		$vid       = $it['contentDetails']['videoId'];
		$name      = (string) ( $it['snippet']['title'] ?? '' );
		$desc      = (string) ( $it['snippet']['description'] ?? '' );
		$len       = $lengths[ $vid ] ?? 0;
		$entries[] = array(
			'video_id'    => $vid,
			'title'       => $name,
			'description' => $desc,
			'published'   => (string) $it['contentDetails']['videoPublishedAt'],
			'is_short'    => ( $len > 0 && $len <= 60 ) || false !== stripos( $name . ' ' . $desc, '#shorts' ),
		);
	}

	return array( 'title' => $title, 'entries' => $entries );
}

/**
 * @return array{title:string,entries:array}|WP_Error
 */
function wooin_yt_fetch( string $url ) {
	$response = wp_remote_get( $url, array( 'timeout' => 15 ) );
	if ( is_wp_error( $response ) ) {
		return $response;
	}
	if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
		return new WP_Error( 'wooin_yt_http', 'HTTP ' . wp_remote_retrieve_response_code( $response ) );
	}

	$previous = libxml_use_internal_errors( true );
	$xml      = simplexml_load_string( wp_remote_retrieve_body( $response ) );
	libxml_use_internal_errors( $previous );
	if ( ! $xml ) {
		return new WP_Error( 'wooin_yt_xml', '피드를 해석할 수 없습니다.' );
	}

	$entries = array();
	foreach ( $xml->entry as $entry ) {
		$yt    = $entry->children( 'http://www.youtube.com/xml/schemas/2015' );
		$media = $entry->children( 'http://search.yahoo.com/mrss/' )->group;
		$link  = (string) $entry->link->attributes()->href;

		$entries[] = array(
			'video_id'    => (string) $yt->videoId,
			'title'       => (string) $entry->title,
			'description' => $media ? (string) $media->description : '',
			'published'   => (string) $entry->published,
			'is_short'    => false !== strpos( $link, '/shorts/' ),
		);
	}

	return array( 'title' => (string) $xml->title, 'entries' => $entries );
}

function wooin_yt_find( string $video_id ): int {
	$ids = get_posts(
		array(
			'post_type'      => 'wooin_video',
			'post_status'    => 'any',
			'meta_key'       => 'video_id',
			'meta_value'     => $video_id,
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	);
	if ( ! $ids ) {
		$ids = get_posts(
			array(
				'post_type'      => 'wooin_video',
				'post_status'    => 'trash',
				'meta_key'       => 'video_id',
				'meta_value'     => $video_id,
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
	}
	return $ids ? (int) $ids[0] : 0;
}

/**
 * @return bool 새로 만들었으면 true.
 */
function wooin_yt_upsert( array $entry, int $term_id ): bool {
	if ( '' === $entry['video_id'] ) {
		return false;
	}

	$post_id = wooin_yt_find( $entry['video_id'] );
	$created = 0 === $post_id;
	$date    = get_date_from_gmt( gmdate( 'Y-m-d H:i:s', strtotime( $entry['published'] ) ) );

	$data = array(
		'post_type'    => 'wooin_video',
		'post_title'   => wp_strip_all_tags( $entry['title'] ),
		'post_content' => sanitize_textarea_field( $entry['description'] ),
		'post_date'    => $date,
	);

	if ( $created ) {
		$data['post_status'] = 'publish';
		$post_id             = wp_insert_post( wp_slash( $data ), true );
		if ( is_wp_error( $post_id ) ) {
			return false;
		}
		update_post_meta( $post_id, 'video_id', $entry['video_id'] );
	} else {
		// 상태(숨김/휴지통)는 관리자 결정을 유지하고 제목·설명만 갱신.
		$data['ID'] = $post_id;
		wp_update_post( wp_slash( $data ) );
	}

	update_post_meta( $post_id, 'is_short', $entry['is_short'] );
	update_post_meta( $post_id, 'yt_published', $entry['published'] );
	if ( $term_id ) {
		wp_set_object_terms( $post_id, $term_id, 'wooin_playlist', true );
	}

	return $created;
}

function wooin_yt_playlist_term( string $playlist_id, string $title, int $order ): int {
	$slug = sanitize_title( $playlist_id );
	$term = get_term_by( 'slug', $slug, 'wooin_playlist' );
	if ( ! $term ) {
		$made = wp_insert_term( $title ? $title : $playlist_id, 'wooin_playlist', array( 'slug' => $slug ) );
		if ( is_wp_error( $made ) ) {
			return 0;
		}
		$term_id = (int) $made['term_id'];
	} else {
		$term_id = (int) $term->term_id;
		if ( $title && $term->name !== $title ) {
			wp_update_term( $term_id, 'wooin_playlist', array( 'name' => $title ) );
		}
	}
	update_term_meta( $term_id, 'playlist_id', $playlist_id );
	update_term_meta( $term_id, 'order', $order );
	return $term_id;
}

function wooin_yt_log( array $result ): void {
	update_option(
		'wooin_youtube_last_sync',
		array(
			'time'    => time(),
			'created' => $result['created'],
			'updated' => $result['updated'],
			'errors'  => $result['errors'],
			'via'     => $result['via'] ?? '',
		),
		false
	);
}

/* ---------------------------------------------------------------- 조회 도우미 (블록에서 사용) */

/**
 * @return WP_Post[]
 */
function wooin_yt_videos( array $args = array() ): array {
	$args = wp_parse_args( $args, array( 'limit' => 5, 'playlist' => 0, 'shorts' => false, 'featured_first' => false ) );

	$query = array(
		'post_type'      => 'wooin_video',
		'post_status'    => 'publish',
		'posts_per_page' => $args['limit'],
		'orderby'        => 'date',
		'order'          => 'DESC',
		'no_found_rows'  => true,
		// 동기화된 영상은 is_short 가 항상 저장된다('1' 또는 '').
		'meta_query'     => array(
			array( 'key' => 'is_short', 'value' => '1', 'compare' => $args['shorts'] ? '=' : '!=' ),
		),
	);
	if ( $args['playlist'] ) {
		$query['tax_query'] = array( array( 'taxonomy' => 'wooin_playlist', 'terms' => (int) $args['playlist'] ) );
	}

	$posts = get_posts( $query );

	if ( $args['featured_first'] ) {
		$featured = get_posts(
			array(
				'post_type'      => 'wooin_video',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'meta_key'       => 'featured',
				'meta_value'     => '1',
			)
		);
		if ( $featured ) {
			$posts = array_merge( $featured, array_filter( $posts, static fn( $p ) => $p->ID !== $featured[0]->ID ) );
			$posts = array_slice( $posts, 0, $args['limit'] );
		}
	}

	return $posts;
}

/**
 * 메인 캐러셀 영상 — 「메인 노출」 체크한 영상(순서 → 최신순). 없으면 최신 일반 영상으로 채운다.
 *
 * @return WP_Post[]
 */
function wooin_yt_picks( int $limit = 5 ): array {
	$picks = get_posts(
		array(
			'post_type'      => 'wooin_video',
			'post_status'    => 'publish',
			'posts_per_page' => $limit,
			'meta_query'     => array(
				'pick'  => array( 'key' => 'home_pick', 'value' => '1' ),
				'order' => array(
					'relation'    => 'OR',
					'order_value' => array( 'key' => 'home_order', 'compare' => 'EXISTS', 'type' => 'NUMERIC' ),
					array( 'key' => 'home_order', 'compare' => 'NOT EXISTS' ),
				),
			),
			'orderby'        => array( 'order_value' => 'ASC', 'date' => 'DESC' ),
		)
	);
	return $picks ? $picks : wooin_yt_videos( array( 'limit' => $limit ) );
}

/** 유튜브 주소(또는 ID)에서 영상 ID. watch?v= · youtu.be/ · shorts/ · embed/ 지원. */
function wooin_yt_parse_id( string $input ): string {
	$input = trim( $input );
	if ( preg_match( '~(?:v=|youtu\.be/|/shorts/|/embed/|/live/)([A-Za-z0-9_-]{11})~', $input, $m ) ) {
		return $m[1];
	}
	return preg_match( '~^[A-Za-z0-9_-]{11}$~', $input ) ? $input : '';
}

/**
 * 설정 순서대로 정렬된 재생목록.
 *
 * @return WP_Term[]
 */
function wooin_yt_playlists(): array {
	$terms = get_terms( array( 'taxonomy' => 'wooin_playlist', 'hide_empty' => true ) );
	if ( is_wp_error( $terms ) ) {
		return array();
	}
	usort( $terms, static fn( $a, $b ) => (int) get_term_meta( $a->term_id, 'order', true ) <=> (int) get_term_meta( $b->term_id, 'order', true ) );
	return $terms;
}

/* ---------------------------------------------------------------- 관리자 설정 화면 */

add_action(
	'admin_menu',
	static function () {
		add_submenu_page(
			'edit.php?post_type=wooin_video',
			'유튜브 연동 설정',
			'유튜브 연동 설정',
			'wooin_manage_site_info',
			'wooin-youtube',
			'wooin_yt_render_settings'
		);
	}
);

add_action(
	'admin_post_wooin_youtube_save',
	static function () {
		if ( ! current_user_can( 'wooin_manage_site_info' ) ) {
			wp_die( '권한이 없습니다.', 403 );
		}
		check_admin_referer( 'wooin_youtube_save' );

		$playlists = preg_split( '/\s+/', (string) wp_unslash( $_POST['playlists'] ?? '' ) );
		$playlists = array_values( array_filter( array_map( static fn( $id ) => preg_replace( '/[^A-Za-z0-9_-]/', '', $id ), $playlists ) ) );

		// 추가 채널: 한 줄에 「채널ID 채널 이름 | 채널 주소」
		$channels = array();
		foreach ( preg_split( '/\r?\n/', (string) wp_unslash( $_POST['channels'] ?? '' ) ) as $line ) {
			$parts = array_map( 'trim', explode( '|', $line ) );
			if ( ! preg_match( '/^(UC[A-Za-z0-9_-]{22})s*(.*)$/', $parts[0], $m ) ) {
				continue;
			}
			$channels[] = array( $m[1], sanitize_text_field( $m[2] ), esc_url_raw( $parts[1] ?? '' ) );
		}

		// API 키: 빈 칸으로 저장하면 기존 키 유지, 「지우기」를 체크하면 삭제
		$old     = wooin_yt_settings();
		$new_key = sanitize_text_field( wp_unslash( $_POST['api_key'] ?? '' ) );
		$api_key = isset( $_POST['api_key_clear'] ) ? '' : ( '' !== $new_key ? $new_key : $old['api_key'] );

		update_option(
			WOOIN_YT_OPTION,
			array(
				'api_key'      => $api_key,
				'channel_id'   => preg_replace( '/[^A-Za-z0-9_-]/', '', (string) wp_unslash( $_POST['channel_id'] ?? '' ) ),
				'channel_url'  => esc_url_raw( wp_unslash( $_POST['channel_url'] ?? '' ) ),
				'channel_name' => sanitize_text_field( wp_unslash( $_POST['channel_name'] ?? '' ) ),
				'description'  => sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ),
				'subscribers'  => sanitize_text_field( wp_unslash( $_POST['subscribers'] ?? '' ) ),
				'playlists'    => $playlists,
				'channels'     => $channels,
			)
		);

		$notice = 'saved';
		if ( isset( $_POST['sync_now'] ) ) {
			$r      = wooin_yt_sync();
			$notice = $r['errors'] ? 'sync_error' : 'synced';
		}
		wp_safe_redirect( add_query_arg( 'wooin_notice', $notice, admin_url( 'edit.php?post_type=wooin_video&page=wooin-youtube' ) ) );
		exit;
	}
);

function wooin_yt_render_settings(): void {
	if ( ! current_user_can( 'wooin_manage_site_info' ) ) {
		return;
	}
	$s    = wooin_yt_settings();
	$last = get_option( 'wooin_youtube_last_sync' );
	?>
	<div class="wrap">
		<h1>유튜브 연동 설정</h1>
		<p>채널에 새 영상이 올라오면 1시간 안에 홈페이지 영상 목록과 메인에 자동으로 추가됩니다. 영상을 숨기려면 해당 영상을 초안으로 바꾸거나 휴지통으로 옮기세요.</p>
		<?php if ( is_array( $last ) ) : ?>
			<p><strong>최근 동기화:</strong> <?php echo esc_html( wp_date( 'Y-m-d H:i', $last['time'] ) ); ?> · <?php echo esc_html( 'api' === ( $last['via'] ?? '' ) ? 'Data API' : 'RSS' ); ?> · 신규 <?php echo (int) $last['created']; ?> · 갱신 <?php echo (int) $last['updated']; ?>
			<?php foreach ( (array) $last['errors'] as $error ) : ?>
				<br><span style="color:#b32d2e">오류: <?php echo esc_html( $error ); ?></span>
			<?php endforeach; ?></p>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="wooin_youtube_save">
			<?php wp_nonce_field( 'wooin_youtube_save' ); ?>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="yt-key">YouTube Data API 키</label></th><td>
					<?php if ( defined( 'WOOIN_YT_API_KEY' ) && WOOIN_YT_API_KEY ) : ?>
						<p>wp-config.php 의 <code>WOOIN_YT_API_KEY</code> 를 사용 중입니다.</p>
					<?php else : ?>
						<input class="regular-text" id="yt-key" name="api_key" type="password" autocomplete="off" value="" placeholder="<?php echo esc_attr( $s['api_key'] ? '저장됨 — 바꿀 때만 입력' : '비워두면 RSS(최신 15개, 불안정)로 동기화' ); ?>">
						<?php if ( $s['api_key'] ) : ?><label><input type="checkbox" name="api_key_clear" value="1"> 저장된 키 지우기</label><?php endif; ?>
						<p class="description">Google Cloud 콘솔에서 「YouTube Data API v3」를 사용 설정한 뒤 API 키를 만들어 입력합니다. 키는 이 화면에 다시 표시되지 않습니다.</p>
					<?php endif; ?>
				</td></tr>
				<tr><th scope="row"><label for="yt-channel">채널 ID</label></th><td><input class="regular-text" id="yt-channel" name="channel_id" value="<?php echo esc_attr( $s['channel_id'] ); ?>" placeholder="UC로 시작하는 ID"></td></tr>
				<tr><th scope="row"><label for="yt-url">채널 주소</label></th><td><input class="regular-text" id="yt-url" name="channel_url" value="<?php echo esc_attr( $s['channel_url'] ); ?>"></td></tr>
				<tr><th scope="row"><label for="yt-name">채널 이름</label></th><td><input class="regular-text" id="yt-name" name="channel_name" value="<?php echo esc_attr( $s['channel_name'] ); ?>"></td></tr>
				<tr><th scope="row"><label for="yt-subs">구독자 표시</label></th><td><input class="regular-text" id="yt-subs" name="subscribers" value="<?php echo esc_attr( $s['subscribers'] ); ?>" placeholder="예: 구독자 10.1만명"><p class="description">RSS 로는 구독자 수를 받을 수 없어 직접 입력합니다.</p></td></tr>
				<tr><th scope="row"><label for="yt-desc">채널 소개</label></th><td><textarea class="large-text" rows="3" id="yt-desc" name="description"><?php echo esc_textarea( $s['description'] ); ?></textarea></td></tr>
				<tr><th scope="row"><label for="yt-pl">재생목록 ID</label></th><td><textarea class="large-text code" rows="8" id="yt-pl" name="playlists"><?php echo esc_textarea( implode( "\n", $s['playlists'] ) ); ?></textarea><p class="description">한 줄에 하나. 위에서부터 영상 페이지에 표시되는 순서입니다.</p></td></tr>
				<tr><th scope="row"><label for="yt-ch">추가 채널</label></th><td><textarea class="large-text code" rows="3" id="yt-ch" name="channels"><?php echo esc_textarea( implode( "\n", array_map( static fn( $c ) => trim( $c[0] . ' ' . $c[1] ) . ( $c[2] ? ' | ' . $c[2] : '' ), $s['channels'] ) ) ); ?></textarea><p class="description">한 줄에 「채널ID 채널 이름 | 채널 주소」. 채널의 최신 영상이 영상 페이지 맨 위 줄과 전체 목록에 함께 나옵니다.</p></td></tr>
			</table>
			<?php submit_button( '저장', 'primary', 'submit', false ); ?>
			<?php submit_button( '저장 후 지금 동기화', 'secondary', 'sync_now', false ); ?>
		</form>
	</div>
	<?php
}

/* ---------------------------------------------------------------- 영상 편집: 메인 노출 · 직접 등록 */

add_action(
	'add_meta_boxes_wooin_video',
	static function () {
		add_meta_box(
			'wooin-video-home',
			'메인 노출 · 직접 등록',
			static function ( WP_Post $post ) {
				wp_nonce_field( 'wooin_video_meta', 'wooin_video_nonce' );
				$vid = (string) get_post_meta( $post->ID, 'video_id', true );
				?>
				<p><label><input type="checkbox" name="wooin_home_pick" value="1"<?php checked( (bool) get_post_meta( $post->ID, 'home_pick', true ) ); ?>> <strong>메인 캐러셀에 노출</strong></label></p>
				<p><label>노출 순서 <input type="number" name="wooin_home_order" min="1" max="99" style="width:5em" value="<?php echo esc_attr( (string) get_post_meta( $post->ID, 'home_order', true ) ); ?>"></label></p>
				<p class="description">체크한 영상 중 순서가 빠른 5개가 메인에 나옵니다. 하나도 없으면 최신 영상이 나옵니다.</p>
				<hr>
				<p><label for="wooin-yt-url"><strong>유튜브 주소</strong></label><input type="url" id="wooin-yt-url" name="wooin_yt_url" class="widefat" placeholder="https://www.youtube.com/watch?v=…" value="<?php echo esc_attr( $vid ? 'https://www.youtube.com/watch?v=' . $vid : '' ); ?>"></p>
				<p><label><input type="checkbox" name="wooin_is_short" value="1"<?php checked( (bool) get_post_meta( $post->ID, 'is_short', true ) ); ?>> 쇼츠 영상</label></p>
				<p class="description">자동 동기화되지 않은 영상도 주소를 붙여 넣어 직접 등록할 수 있습니다.</p>
				<?php
			},
			'wooin_video',
			'side',
			'high'
		);
	}
);

add_action(
	'save_post_wooin_video',
	static function ( $post_id ) {
		if ( ! isset( $_POST['wooin_video_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wooin_video_nonce'] ) ), 'wooin_video_meta' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, 'home_pick', ! empty( $_POST['wooin_home_pick'] ) );
		$order = isset( $_POST['wooin_home_order'] ) ? absint( $_POST['wooin_home_order'] ) : 0;
		if ( $order ) {
			update_post_meta( $post_id, 'home_order', $order );
		} else {
			delete_post_meta( $post_id, 'home_order' );
		}
		$vid = wooin_yt_parse_id( sanitize_text_field( wp_unslash( $_POST['wooin_yt_url'] ?? '' ) ) );
		if ( $vid ) {
			update_post_meta( $post_id, 'video_id', $vid );
		}
		// 목록 조회가 is_short 값을 기준으로 하므로 항상 저장
		update_post_meta( $post_id, 'is_short', ! empty( $_POST['wooin_is_short'] ) );
	}
);

// 영상 목록에 「메인」 칸
add_filter(
	'manage_wooin_video_posts_columns',
	static fn( $cols ) => array_slice( $cols, 0, 2, true ) + array( 'wooin_home' => '메인' ) + array_slice( $cols, 2, null, true )
);
add_action(
	'manage_wooin_video_posts_custom_column',
	static function ( $col, $post_id ) {
		if ( 'wooin_home' === $col && get_post_meta( $post_id, 'home_pick', true ) ) {
			$order = (string) get_post_meta( $post_id, 'home_order', true );
			echo '<strong>노출</strong>' . ( $order ? ' · ' . esc_html( $order ) . '번' : '' );
		}
	},
	10,
	2
);
