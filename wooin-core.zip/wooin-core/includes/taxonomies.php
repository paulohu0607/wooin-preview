<?php
/**
 * 분류.
 *
 * wooin_practice_area: 분야의 단일 관리 원본. 업무분야·변호사·사례·FAQ·소식이 같은 분야 ID 를 공유한다.
 * content_kind: 소식(post)의 유형 — 칼럼·사무소 소식·영상·보도.
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'wooin_core_register_taxonomies' );

function wooin_core_register_taxonomies(): void {
	$caps = array(
		'manage_terms' => 'wooin_manage_terms',
		'edit_terms'   => 'wooin_manage_terms',
		'delete_terms' => 'wooin_manage_terms',
		'assign_terms' => 'wooin_assign_terms',
	);

	register_taxonomy(
		'wooin_practice_area',
		array( 'wooin_service', 'wooin_person', 'wooin_case', 'wooin_faq', 'wooin_review', 'post' ),
		array(
			'labels'            => array(
				'name'          => '분야 분류',
				'singular_name' => '분야',
				'add_new_item'  => '분야 추가',
				'edit_item'     => '분야 수정',
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rewrite'           => array( 'slug' => 'area', 'with_front' => false ),
			'capabilities'      => $caps,
		)
	);

	register_taxonomy(
		'content_kind',
		array( 'post' ),
		array(
			'labels'            => array(
				'name'          => '소식 유형',
				'singular_name' => '소식 유형',
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rewrite'           => array( 'slug' => 'insights/kind', 'with_front' => false ),
			'capabilities'      => $caps,
		)
	);
}
