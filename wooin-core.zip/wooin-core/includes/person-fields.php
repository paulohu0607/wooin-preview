<?php
/**
 * 구성원 프로필 입력 — 「구성원」 편집 화면.
 *
 * 이름 = 글 제목, 사진 = 대표 이미지, 나머지는 메타 wooin_profile(배열) 하나에 저장한다.
 * 테마(inc/people.php)는 wooin_person_profile() 으로 읽고, 비어 있는 칸은 테마의 기본 원고를 쓴다.
 * 처음 한 번, 테마 기본 원고·사진을 이 칸들과 미디어 라이브러리로 옮겨 넣는다(wooin_people_migrate).
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

const WOOIN_PROFILE_META = 'wooin_profile';

/** 칸: 키 => [이름, 형식, 도움말] */
function wooin_person_profile_fields(): array {
	return array(
		'title'    => array( '직함', 'text', '예: 대표 변호사, 공인회계사' ),
		'en'       => array( '영문 직함', 'text', '사진 위 서명과 작은 제목에 쓰입니다. 예: Attorney at Law' ),
		'headline' => array( '큰 문구', 'lines', '메인 구성원 소개와 상세 페이지 맨 위 큰 글씨. [대괄호] 안은 강조색.' ),
		'intro'    => array( '소개 글', 'textarea', '' ),
		'points'   => array( '핵심 이력 (한 줄에 하나)', 'list', '메인에는 번호를 붙여 보여주고, 목록 카드에는 앞의 두 줄이 나옵니다.' ),
		'career'   => array( '상세 이력', 'textarea', "「# 경력」처럼 #으로 묶음 이름을 쓰고, 아래에 「기간 | 내용」을 한 줄씩 적습니다. 기간이 없으면 내용만 적어도 됩니다." ),
		'media'    => array( '언론 · 방송 (선택)', 'textarea', '한 줄에 「날짜 | 매체 | 기사 제목」. 비워 두면 언론 섹션을 숨깁니다.' ),
		'outlets'  => array( '출연 매체 이름 (선택)', 'text', '쉼표로 구분. 예: SBS뉴스, YTN라디오' ),
		'tone'     => array( '사진 배경 톤', 'tone', '사진 배경이 밝으면 「밝음」— 사진 위 서명 글자색이 맞춰집니다.' ),
	);
}

/** 저장된 프로필 (빈 칸은 빠짐). 테마가 읽는다. */
function wooin_person_profile( int $post_id ): array {
	$raw = get_post_meta( $post_id, WOOIN_PROFILE_META, true );
	$raw = is_array( $raw ) ? $raw : array();
	$out = array();
	foreach ( $raw as $k => $v ) {
		if ( '' === trim( (string) $v ) ) {
			continue;
		}
		$v = function_exists( 'wooin_yt_fill' ) ? wooin_yt_fill( (string) $v ) : $v;
		switch ( $k ) {
			case 'headline':
				$out[ $k ] = wooin_home_format( (string) $v, 'em' );
				break;
			case 'points':
				$out[ $k ] = array_values( array_filter( array_map( 'trim', explode( "\n", (string) $v ) ) ) );
				break;
			case 'outlets':
				$out[ $k ] = array_values( array_filter( array_map( 'trim', explode( ',', (string) $v ) ) ) );
				break;
			case 'career':
				$groups = array();
				$label  = '이력';
				foreach ( explode( "\n", (string) $v ) as $line ) {
					$line = trim( $line );
					if ( '' === $line ) {
						continue;
					}
					if ( str_starts_with( $line, '#' ) ) {
						$label            = trim( ltrim( $line, '#' ) );
						$groups[ $label ] = $groups[ $label ] ?? array();
						continue;
					}
					$parts              = array_map( 'trim', explode( '|', $line, 2 ) );
					$groups[ $label ][] = isset( $parts[1] ) ? array( $parts[0], $parts[1] ) : array( '', $parts[0] );
				}
				$out['groups'] = array_filter( $groups );
				break;
			case 'media':
				$rows = array();
				foreach ( explode( "\n", (string) $v ) as $line ) {
					$parts = array_map( 'trim', explode( '|', $line ) );
					if ( count( $parts ) >= 3 ) {
						$rows[] = array( $parts[0], $parts[1], implode( ' | ', array_slice( $parts, 2 ) ) );
					}
				}
				$out['media'] = $rows;
				break;
			default:
				$out[ $k ] = (string) $v;
		}
	}
	return $out;
}

/* ---------------------------------------------------------------- 편집 화면 */

add_action(
	'add_meta_boxes_wooin_person',
	static function () {
		add_meta_box( 'wooin-profile', '프로필 (홈페이지에 보이는 내용)', 'wooin_person_render_box', 'wooin_person', 'normal', 'high' );
	}
);

// 구성원은 본문 대신 위 프로필 칸을 쓴다
add_action(
	'init',
	static function () {
		remove_post_type_support( 'wooin_person', 'editor' );
	},
	20
);

add_filter(
	'enter_title_here',
	static fn( $text, $post ) => 'wooin_person' === $post->post_type ? '이름 (예: 이서영)' : $text,
	10,
	2
);

function wooin_person_render_box( WP_Post $post ): void {
	$raw = get_post_meta( $post->ID, WOOIN_PROFILE_META, true );
	$raw = is_array( $raw ) ? $raw : array();
	wp_nonce_field( 'wooin_profile_save', 'wooin_profile_nonce' );
	echo '<div class="wooin-admin wooin-profile-box"><p class="wooin-panel-desc">사진은 오른쪽(또는 아래) 「대표 이미지」에서 바꿉니다. 메인 순서는 「순서」 숫자가 작은 사람부터입니다.</p>';
	foreach ( wooin_person_profile_fields() as $key => $f ) {
		if ( 'tone' === $f[1] ) {
			$tone = $raw[ $key ] ?? 'dark';
			printf(
				'<div class="wooin-field"><label>%1$s</label><label class="wooin-inline"><input type="radio" name="wooin_profile[tone]" value="dark" %2$s> 어두움</label> <label class="wooin-inline"><input type="radio" name="wooin_profile[tone]" value="light" %3$s> 밝음</label><p class="description">%4$s</p></div>',
				esc_html( $f[0] ),
				checked( 'light' !== $tone, true, false ),
				checked( 'light' === $tone, true, false ),
				esc_html( $f[2] )
			);
			continue;
		}
		wooin_admin_field( 'wooin_profile[' . $key . ']', 'profile-' . $key, $f[0], $f[1], $raw[ $key ] ?? '', $f[2] );
	}
	echo '</div>';
}

add_action(
	'save_post_wooin_person',
	static function ( $post_id ) {
		if ( ! isset( $_POST['wooin_profile_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['wooin_profile_nonce'] ), 'wooin_profile_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$input = wp_unslash( (array) ( $_POST['wooin_profile'] ?? array() ) );
		$clean = array();
		foreach ( wooin_person_profile_fields() as $key => $f ) {
			$v             = (string) ( $input[ $key ] ?? '' );
			$clean[ $key ] = in_array( $f[1], array( 'text', 'tone' ), true ) ? sanitize_text_field( $v ) : trim( str_replace( "\r", '', sanitize_textarea_field( $v ) ) );
		}
		$clean['tone'] = 'light' === $clean['tone'] ? 'light' : 'dark';
		update_post_meta( $post_id, WOOIN_PROFILE_META, $clean );
	}
);

// 프로필 메타는 공개 REST 에 내보내지 않는다 (편집은 위 메타 상자에서만)
add_filter(
	'is_protected_meta',
	static fn( $protected, $key ) => WOOIN_PROFILE_META === $key ? true : $protected,
	10,
	2
);

/* ---------------------------------------------------------------- 테마 기본 원고 → 관리자 칸 (한 번만) */

/**
 * 테마 inc/people.php 의 기본 원고·사진을 구성원 글로 옮긴다. 이미 입력된 칸·사진은 건드리지 않는다.
 *
 * @return int 옮긴 사람 수.
 */
function wooin_people_migrate(): int {
	if ( ! function_exists( 'wooin_people_defaults' ) ) {
		return 0;
	}
	$done = 0;
	foreach ( wooin_people_defaults() as $slug => $p ) {
		$ids = get_posts( array( 'post_type' => 'wooin_person', 'name' => $slug, 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids' ) );
		if ( ! $ids ) {
			continue;
		}
		$id  = (int) $ids[0];
		$raw = get_post_meta( $id, WOOIN_PROFILE_META, true );
		if ( ! is_array( $raw ) || ! array_filter( $raw ) ) {
			$career = '';
			foreach ( $p['groups'] as $label => $rows ) {
				$career .= '# ' . $label . "\n";
				foreach ( $rows as $r ) {
					$career .= ( '' !== $r[0] ? $r[0] . ' | ' : '' ) . $r[1] . "\n";
				}
			}
			$headline = (string) preg_replace_callback( '#<em>(.*?)</em>#', static fn( $m ) => '[' . $m[1] . ']', preg_replace( '#<br\s*/?>#', "\n", $p['headline'] ) );
			update_post_meta(
				$id,
				WOOIN_PROFILE_META,
				array(
					'title'    => $p['title'],
					'en'       => $p['en'],
					'headline' => $headline,
					'intro'    => $p['intro'],
					'points'   => implode( "\n", $p['points'] ),
					'career'   => trim( $career ),
					'media'    => implode( "\n", array_map( static fn( $m ) => implode( ' | ', $m ), $p['media'] ) ),
					'outlets'  => implode( ', ', $p['outlets'] ),
					'tone'     => $p['tone'],
				)
			);
		}
		if ( ! has_post_thumbnail( $id ) && ! empty( $p['photo'] ) ) {
			$att = wooin_import_theme_image( 'assets/images/people/' . $p['photo'], $id, $p['name'] . ' ' . $p['title'] );
			if ( $att ) {
				set_post_thumbnail( $id, $att );
			}
		}
		++$done;
	}
	return $done;
}

/** 테마 폴더의 사진을 미디어 라이브러리로 복사 (같은 $key 로 이미 옮긴 파일이면 그 ID). */
function wooin_import_theme_image( string $rel, int $parent, string $alt, string $key = '' ): int {
	$src = get_theme_file_path( $rel );
	$key = $key ? $key : $rel;
	if ( ! is_readable( $src ) ) {
		return 0;
	}
	$found = get_posts( array( 'post_type' => 'attachment', 'meta_key' => '_wooin_theme_src', 'meta_value' => $key, 'posts_per_page' => 1, 'fields' => 'ids' ) );
	if ( $found ) {
		return (int) $found[0];
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$tmp = wp_tempnam( basename( $src ) );
	copy( $src, $tmp );
	$id = media_handle_sideload( array( 'name' => basename( $src ), 'tmp_name' => $tmp ), $parent, $alt );
	if ( is_wp_error( $id ) ) {
		wp_delete_file( $tmp );
		return 0;
	}
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	update_post_meta( $id, '_wooin_theme_src', $key );
	return (int) $id;
}

/**
 * 구성원 사진 보정본(2026-11-06: 얼굴 크기·위치 맞춤, 배경 통일)으로 한 번 교체.
 * 처음 자동으로 옮긴 사진을 그대로 쓰는 사람만 바꾼다 — 관리자가 직접 바꾼 사진은 건드리지 않는다.
 */
function wooin_people_photos_v2(): void {
	if ( '3' === get_option( 'wooin_people_photos' ) || ! function_exists( 'wooin_people_defaults' ) ) {
		return;
	}
	foreach ( wooin_people_defaults() as $slug => $p ) {
		$ids = get_posts( array( 'post_type' => 'wooin_person', 'name' => $slug, 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids' ) );
		if ( ! $ids || empty( $p['photo'] ) ) {
			continue;
		}
		$id    = (int) $ids[0];
		$thumb = (int) get_post_thumbnail_id( $id );
		$rel   = 'assets/images/people/' . $p['photo'];
		$src = $thumb ? (string) get_post_meta( $thumb, '_wooin_theme_src', true ) : '';
		if ( $src === $rel . '#v2' ) {
			continue; // 이미 보정본
		}
		// 처음 넣은 원본 사진(자동으로 옮긴 것, 또는 파일 이름이 원본과 같은 것 — 예: lee-seoyoung-1.jpg)만 교체. 다른 사진으로 직접 바꿨으면 그대로 둔다.
		$base = pathinfo( $p['photo'], PATHINFO_FILENAME );
		$file = $thumb ? pathinfo( (string) get_attached_file( $thumb ), PATHINFO_FILENAME ) : '';
		$file = (string) preg_replace( '/-(scaled|rotated|\d+x\d+)$/', '', $file );
		$same = $src === $rel || (bool) preg_match( '/^' . preg_quote( $base, '/' ) . '(-\d+)*$/', $file );
		if ( $thumb && ! $same ) {
			continue; // 직접 바꾼 사진
		}
		$att = wooin_import_theme_image( $rel, $id, $p['name'] . ' ' . $p['title'], $rel . '#v2' );
		if ( $att ) {
			set_post_thumbnail( $id, $att );
			$profile = get_post_meta( $id, WOOIN_PROFILE_META, true );
			if ( is_array( $profile ) ) {
				$profile['tone'] = $p['tone'];
				update_post_meta( $id, WOOIN_PROFILE_META, $profile );
			}
		}
	}
	update_option( 'wooin_people_photos', '3', false );
}
add_action( 'init', 'wooin_people_photos_v2', 40 );

add_action(
	'admin_init',
	static function () {
		if ( get_option( 'wooin_people_migrated' ) || ! current_user_can( 'edit_others_wooin_people' ) || ! function_exists( 'wooin_people_defaults' ) ) {
			return;
		}
		if ( wooin_people_migrate() ) {
			update_option( 'wooin_people_migrated', time(), false );
		}
	}
);
