<?php
/**
 * 의뢰인 후기 게시판 — wooin_review 글 유형 + 화면 블록
 *
 * 운영: 게시 동의를 받은 실제 후기만 관리자가 등록·게시한다(작성자 이름은 마스킹해서 입력).
 * 방문자가 직접 쓰는 기능은 없다(동의·스팸·검수 절차 확정 후 별도 구현).
 *
 * 블록
 *   wooin/review-board    목록: 분야 탭(?area=) · 검색(?q=) · 쪽 번호(?pg=)
 *   wooin/review-detail   상세: 제목 · 분야 · 작성자 · 날짜 · 본문 · 원문 보기 · 이전/다음 글
 *   wooin/review-carousel 메인 「의뢰인들의 이야기」 (메인 노출 표시된 후기 우선)
 *
 * @package wooin-core
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'init',
	static function () {
		register_post_type(
			'wooin_review',
			array(
				'labels'          => array(
					'name'          => '의뢰인 후기',
					'singular_name' => '후기',
					'add_new'       => '새 후기',
					'add_new_item'  => '후기 등록',
					'edit_item'     => '후기 수정',
					'all_items'     => '전체 후기',
					'search_items'  => '후기 검색',
					'not_found'     => '등록된 후기가 없습니다.',
				),
				'public'          => true,
				'show_in_rest'    => true,
				'menu_icon'       => 'dashicons-format-quote',
				'menu_position'   => 21,
				'has_archive'     => 'reviews',
				'rewrite'         => array( 'slug' => 'reviews', 'with_front' => false ),
				'supports'        => array( 'title', 'editor', 'excerpt', 'custom-fields', 'revisions' ),
				'taxonomies'      => array( 'wooin_practice_area' ),
				'capability_type' => array( 'wooin_review', 'wooin_reviews' ),
				'map_meta_cap'    => true,
			)
		);
		register_taxonomy_for_object_type( 'wooin_practice_area', 'wooin_review' );

		$auth   = static fn( $allowed, $key, $post_id ) => current_user_can( 'edit_post', $post_id );
		$fields = array(
			'reviewer'     => array( 'string', '작성자 표시 (마스킹, 예: 홍*동)', 'sanitize_text_field', true ),
			'review_stage' => array( 'string', '진행 결과 (예: 개시결정, 인가결정)', 'sanitize_text_field', true ),
			'source_url'   => array( 'string', '원문 주소 (네이버 카페 등)', 'esc_url_raw', true ),
			'featured'     => array( 'boolean', '메인 「의뢰인들의 이야기」 노출', null, true ),
			// 내부 확인용 — 공개 REST 에 내보내지 않는다
			'consent_ok'   => array( 'boolean', '게시 동의 확인', null, false ),
		);
		foreach ( $fields as $key => $f ) {
			register_post_meta(
				'wooin_review',
				$key,
				array_filter(
					array(
						'type'              => $f[0],
						'description'       => $f[1],
						'sanitize_callback' => $f[2],
						'single'            => true,
						'show_in_rest'      => $f[3],
						'auth_callback'     => $auth,
					),
					static fn( $v ) => null !== $v
				)
			);
		}

		foreach ( array(
			'review-board'    => array( '후기 게시판 목록', 'wooin_render_review_board' ),
			'review-detail'   => array( '후기 상세', 'wooin_render_review_detail' ),
			'review-carousel' => array( '후기 캐러셀 (메인)', 'wooin_render_review_carousel' ),
		) as $name => $b ) {
			register_block_type(
				'wooin/' . $name,
				array(
					'title'           => $b[0],
					'category'        => 'widgets',
					'editor_script'   => 'wooin-core-blocks',
					'render_callback' => $b[1],
					'supports'        => array( 'html' => false ),
					'attributes'      => array( 'limit' => array( 'type' => 'number', 'default' => 8 ) ),
				)
			);
		}
	}
);

/** 후기 분야 이름 (첫 번째 분야). */
function wooin_review_area( WP_Post $post ): string {
	$terms = get_the_terms( $post, 'wooin_practice_area' );
	return ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
}

function wooin_review_meta( WP_Post $post, string $key ): string {
	return (string) get_post_meta( $post->ID, $key, true );
}

/* ---------------------------------------------------------------- 목록 */

function wooin_render_review_board(): string {
	// 목록 · 공지 고정 · 법인 우선 정렬은 게시판 공통(boards.php)
	return wooin_board_list( wooin_board_config( 'wooin_review' ) );
}

/* ---------------------------------------------------------------- 상세 */

function wooin_render_review_detail(): string {
	$post = get_post();
	if ( ! $post || 'wooin_review' !== $post->post_type ) {
		return '';
	}
	$area   = wooin_review_area( $post );
	$stage  = wooin_review_meta( $post, 'review_stage' );
	$source = wooin_review_meta( $post, 'source_url' );

	$html  = '<article class="wooin-review-article">';
	$html .= '<header class="wooin-review-head">';
	$html .= '<p class="wooin-review-tags">' . ( $area ? '<span class="wooin-chip' . ( str_starts_with( $area, '법인' ) ? ' is-dark' : '' ) . '">' . esc_html( $area ) . '</span>' : '' ) . ( $stage ? '<span class="wooin-chip is-line">' . esc_html( $stage ) . '</span>' : '' ) . '</p>';
	$html .= '<h2>' . esc_html( get_the_title( $post ) ) . '</h2>';
	$html .= '<p class="wooin-review-info"><span>작성자 <b>' . esc_html( wooin_review_meta( $post, 'reviewer' ) ) . '</b></span><span>등록일 ' . esc_html( get_the_date( 'Y.m.d', $post ) ) . '</span></p>';
	$html .= '</header>';
	$html .= '<div class="wooin-review-body">' . wpautop( wp_kses_post( $post->post_content ) ) . '</div>';
	if ( $source ) {
		$html .= '<p class="wooin-review-source"><a href="' . esc_url( $source ) . '" target="_blank" rel="noopener"><span class="wooin-cafe-icon" aria-hidden="true"></span>네이버 카페에서 원문 보기<span class="wooin-arrow" aria-hidden="true"></span></a></p>';
	}
	$html .= '<p class="wooin-review-note">※ 의뢰인의 게시 동의를 받은 실제 후기입니다. 개인정보 보호를 위해 이름 일부를 가렸습니다.</p>';
	$html .= '</article>';

	// 이전 / 다음 글 (등록일 기준)
	$prev  = get_adjacent_post( false, '', true );
	$next  = get_adjacent_post( false, '', false );
	$html .= '<nav class="wooin-review-nav" aria-label="다른 후기">';
	$html .= '<div><small>이전 후기</small>' . ( $prev ? '<a href="' . esc_url( get_permalink( $prev ) ) . '">' . esc_html( get_the_title( $prev ) ) . '</a>' : '<span>이전 후기가 없습니다</span>' ) . '</div>';
	$html .= '<div><small>다음 후기</small>' . ( $next ? '<a href="' . esc_url( get_permalink( $next ) ) . '">' . esc_html( get_the_title( $next ) ) . '</a>' : '<span>다음 후기가 없습니다</span>' ) . '</div>';
	$html .= '</nav><p class="wooin-review-list-link"><a class="wooin-pill-link" href="' . esc_url( get_post_type_archive_link( 'wooin_review' ) ) . '">목록으로</a></p>';

	return '<div ' . get_block_wrapper_attributes( array( 'class' => 'wooin-review-detail' ) ) . '>' . $html . '</div>';
}

/* ---------------------------------------------------------------- 메인 캐러셀 */

function wooin_render_review_carousel( array $attrs ): string {
	$limit    = max( 3, min( 12, (int) ( $attrs['limit'] ?? 8 ) ) );
	$featured = get_posts( array( 'post_type' => 'wooin_review', 'post_status' => 'publish', 'posts_per_page' => $limit, 'meta_key' => 'featured', 'meta_value' => '1' ) );
	$posts    = $featured;
	if ( count( $posts ) < $limit ) {
		$more  = get_posts( array( 'post_type' => 'wooin_review', 'post_status' => 'publish', 'posts_per_page' => $limit, 'post__not_in' => wp_list_pluck( $posts, 'ID' ) ) );
		$posts = array_slice( array_merge( $posts, $more ), 0, $limit );
	}
	if ( ! $posts ) {
		return '<p class="wooin-placeholder">게시된 후기가 없습니다.</p>';
	}

	$html = '<div class="wooin-carousel" data-carousel="reviews" role="region" aria-roledescription="carousel" aria-label="의뢰인 후기"><ul class="wooin-carousel-track" tabindex="0">';
	foreach ( $posts as $i => $post ) {
		$quote = $post->post_excerpt ? $post->post_excerpt : wp_trim_words( wp_strip_all_tags( $post->post_content ), 34, '…' );
		$html .= sprintf(
			'<li class="wooin-carousel-slide" aria-roledescription="slide" aria-label="%1$s"><a class="wooin-quote" href="%2$s"><blockquote><p>%3$s</p></blockquote><span class="wooin-quote-cap"><b>%4$s</b> 님 <span>%5$s</span></span></a></li>',
			esc_attr( ( $i + 1 ) . ' / ' . count( $posts ) ),
			esc_url( get_permalink( $post ) ),
			esc_html( $quote ),
			esc_html( wooin_review_meta( $post, 'reviewer' ) ),
			esc_html( implode( ' · ', array_filter( array( wooin_review_area( $post ), wooin_review_meta( $post, 'review_stage' ) ) ) ) )
		);
	}
	$html .= '</ul><div class="wooin-carousel-dots" aria-hidden="true"></div></div>';
	return $html;
}
