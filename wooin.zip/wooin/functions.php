<?php
/**
 * Wooin theme — 화면 표현만 담당한다.
 * 콘텐츠 유형·필드·권한은 wooin-core 플러그인에 둔다.
 *
 * @package wooin
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/inc/subpage.php';
require_once __DIR__ . '/inc/service-detail.php';
require_once __DIR__ . '/inc/people.php';
require_once __DIR__ . '/inc/brand.php';
require_once __DIR__ . '/inc/home.php';

add_action(
	'after_setup_theme',
	static function () {
		add_theme_support( 'editor-styles' );
		add_editor_style( 'style.css' );
		remove_theme_support( 'core-block-patterns' );
	}
);

add_action(
	'wp_enqueue_scripts',
	static function () {
		// 배포(FTP)할 때마다 style.css 수정 시각이 바뀌어 브라우저 캐시가 자동으로 갱신된다
		$version = wp_get_theme()->get( 'Version' ) . '.' . filemtime( get_stylesheet_directory() . '/style.css' );
		// Pretendard (SIL OFL). 운영 전 테마 폴더에 자체 호스팅으로 옮긴다.
		wp_enqueue_style( 'wooin-font', 'https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css', array(), null );
		wp_enqueue_style( 'wooin', get_stylesheet_uri(), array( 'wooin-font' ), $version );
		wp_enqueue_script(
			'wooin-tabs',
			get_theme_file_uri( 'assets/js/tabs.js' ),
			array(),
			$version,
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
		wp_enqueue_script(
			'wooin-process',
			get_theme_file_uri( 'assets/js/process.js' ),
			array(),
			$version,
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
		wp_enqueue_script(
			'wooin-carousel',
			get_theme_file_uri( 'assets/js/carousel.js' ),
			array(),
			$version,
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
		wp_enqueue_script(
			'wooin-video',
			get_theme_file_uri( 'assets/js/video.js' ),
			array(),
			$version,
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
		wp_enqueue_script(
			'wooin-header',
			get_theme_file_uri( 'assets/js/header.js' ),
			array(),
			$version,
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
	}
);

add_action(
	'init',
	static function () {
		register_block_pattern_category( 'wooin', array( 'label' => '우인' ) );
	}
);

// 시안 비교용 색상안: ?scheme=a 네이비·골드, ?scheme=c 블루·화이트. 디자인 확정 후 제거.
add_filter(
	'body_class',
	static function ( array $classes ) {
		$scheme = isset( $_GET['scheme'] ) ? sanitize_key( wp_unslash( $_GET['scheme'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( in_array( $scheme, array( 'a', 'c' ), true ) ) {
			$classes[] = 'wooin-scheme-' . $scheme; // a = 네이비·골드, c = 블루·화이트
		}
		return $classes;
	}
);
