<?php
/**
 * Wooin theme — 화면 표현만 담당한다.
 * 콘텐츠 유형·필드·권한은 wooin-core 플러그인에 둔다.
 *
 * @package wooin
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/inc/subpage.php';
require_once __DIR__ . '/inc/service-detail.php';
require_once __DIR__ . '/inc/people.php';
require_once __DIR__ . '/inc/brand.php';
require_once __DIR__ . '/inc/home.php';
require_once __DIR__ . '/inc/ready.php';
require_once __DIR__ . '/inc/legal.php';

add_action(
	'after_setup_theme',
	static function () {
		add_theme_support( 'editor-styles' );
		add_editor_style( 'style.css' );
		remove_theme_support( 'core-block-patterns' );
	}
);

add_action(
	'wp_enqueue_scripts',
	static function () {
		// 배포(FTP)할 때마다 style.css 수정 시각이 바뀌어 브라우저 캐시가 자동으로 갱신된다
		$version = wp_get_theme()->get( 'Version' ) . '.' . filemtime( get_stylesheet_directory() . '/style.css' );
		// Pretendard v1.3.9 (SIL OFL, assets/fonts/pretendard/LICENSE.txt) — 테마 폴더에 둔다. 글자 범위별로 필요한 조각만 내려받는다.
		wp_enqueue_style( 'wooin-font', get_theme_file_uri( 'assets/fonts/pretendard/pretendard.css' ), array(), '1.3.9' );
		wp_enqueue_style( 'wooin', get_stylesheet_uri(), array( 'wooin-font' ), $version );
		wp_enqueue_script(
			'wooin-tabs',
			get_theme_file_uri( 'assets/js/tabs.js' ),
			array(),
			$version,
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
		wp_enqueue_script(
			'wooin-process',
			get_theme_file_uri( 'assets/js/process.js' ),
			array(),
			$version,
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
		wp_enqueue_script(
			'wooin-carousel',
			get_theme_file_uri( 'assets/js/carousel.js' ),
			array(),
			$version,
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
		wp_enqueue_script(
			'wooin-video',
			get_theme_file_uri( 'assets/js/video.js' ),
			array(),
			$version,
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
		if ( is_page( 'location' ) ) {
			wp_enqueue_script( 'wooin-map', get_theme_file_uri( 'assets/js/map.js' ), array(), $version, array( 'strategy' => 'defer', 'in_footer' => true ) );
		}
		wp_enqueue_script(
			'wooin-header',
			get_theme_file_uri( 'assets/js/header.js' ),
			array(),
			$version,
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
	}
);

add_action(
	'init',
	static function () {
		register_block_pattern_category( 'wooin', array( 'label' => '우인' ) );
	}
);

