<?php
/**
 * 메인 화면 — 관리자 「메인 화면 편집」 값을 화면에 그리는 도우미 + 섹션 순서 블록.
 *
 * 값과 기본 문구는 wooin-core (includes/home-fields.php). 테마는 읽어서 그리기만 한다.
 *
 * @package wooin
 */

defined( 'ABSPATH' ) || exit;

/** 일반 글자 (이스케이프 전). */
function wooin_hv( string $key ): string {
	return function_exists( 'wooin_home' ) ? (string) wooin_home( $key ) : '';
}

/** 꾸밈 규칙을 적용한 HTML (이미 이스케이프됨). $em = [대괄호] 강조에 쓸 태그. */
function wooin_hf( string $key, string $em = 'mark' ): string {
	return function_exists( 'wooin_home_format' ) ? wooin_home_format( wooin_hv( $key ), $em ) : '';
}

/** 링크 주소 (/로 시작하면 사이트 주소를 붙임). */
function wooin_hu( string $key ): string {
	return function_exists( 'wooin_home_url' ) ? wooin_home_url( $key ) : '';
}

/** 사진·영상 주소. */
function wooin_hm( string $key, string $size = 'full' ): string {
	return function_exists( 'wooin_home_media_url' ) ? wooin_home_media_url( $key, $size ) : '';
}

/** 「한 줄에 하나」 목록. */
function wooin_hl( string $key ): array {
	return array_values( array_filter( array_map( 'trim', explode( "\n", wooin_hv( $key ) ) ) ) );
}

// 메인 섹션을 관리자에서 정한 순서·표시대로 그린다 (templates/front-page.html).
add_action(
	'init',
	static function () {
		register_block_type(
			'wooin/home-sections',
			array(
				'title'           => '메인 섹션 (관리자 순서)',
				'category'        => 'theme',
				'render_callback' => static function (): string {
					$sections = function_exists( 'wooin_home' ) ? (array) wooin_home( 'sections' ) : array();
					if ( ! $sections ) {
						$sections = array_map( static fn( $k ) => array( $k, true ), array( 'hero', 'tracks', 'about', 'why', 'cases', 'lawyer', 'videos', 'process', 'services', 'reviews', 'insights', 'contact' ) );
					}
					$html = '';
					foreach ( $sections as $row ) {
						if ( ! empty( $row[1] ) ) {
							$html .= '<!-- wp:pattern {"slug":"wooin/home-' . sanitize_key( $row[0] ) . '"} /-->';
						}
					}
					return do_blocks( $html );
				},
				'supports'        => array( 'html' => false ),
			)
		);
	}
);
