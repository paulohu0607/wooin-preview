<?php
/**
 * 푸터 법정 표시 — wooin/legal-line 블록.
 * 사업자등록번호 · 광고책임변호사는 공통정보에서 읽는다 (비어 있는 항목은 표시하지 않음).
 *
 * @package wooin
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'init',
	static function () {
		register_block_type(
			'wooin/legal-line',
			array(
				'title'           => '법정 표시 (사업자등록번호 · 광고책임변호사)',
				'category'        => 'theme',
				'supports'        => array( 'html' => false ),
				'render_callback' => static function (): string {
					if ( ! function_exists( 'wooin_core_site_info' ) ) {
						return '';
					}
					$parts = array();
					foreach ( array( 'biz_no' => '사업자등록번호', 'ad_lawyer' => '광고책임변호사' ) as $key => $label ) {
						$value = trim( wooin_core_site_info( $key ) );
						if ( '' !== $value ) {
							$parts[] = $label . ' ' . $value;
						}
					}
					return $parts ? '<p class="wooin-footer-info wooin-footer-legal">' . esc_html( implode( ' · ', $parts ) ) . '</p>' : '';
				},
			)
		);
	}
);
