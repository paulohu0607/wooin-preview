<?php
/**
 * 업무분야 상세 4종 — 원고와 화면 구성.
 *
 * patterns/service-*.php 가 wooin_service_detail( '슬러그' ) 를 호출해 블록 마크업을 출력한다.
 * 원고는 일반적인 제도 안내 수준의 초안이다(법률 검토 필요). 우인 고유 수치·경력은 wooin.net 표기만 사용.
 *
 * @package wooin
 */

defined( 'ABSPATH' ) || exit;

function wooin_services_data(): array {
	return array(
		'personal-rehabilitation'  => array(
			'track'    => 'personal',
			'en'       => 'Personal Rehabilitation',
			'headline' => '갚을 수 있는 만큼만 갚고,<br><strong>남은 빚은 면책받는 제도</strong>',
			'lead'     => '개인회생은 꾸준한 소득이 있는 분이 법원이 인가한 변제계획에 따라 3~5년간 일정 금액을 갚으면, 남은 채무를 면책받는 절차입니다.',
			'body'     => '빚이 소득보다 커져 돌려막기로 버티고 있다면, 혼자 버티는 시간이 길어질수록 선택지는 줄어듭니다. 우인은 소득과 재산, 채무 구조를 먼저 분석해 예상 변제금과 가능성을 솔직하게 말씀드립니다.',
			'facts'    => array(
				array( '대상', '꾸준한 소득이 있는 개인 · 개인사업자' ),
				array( '채무 한도', '무담보 10억 원 · 담보 15억 원 이하' ),
				array( '변제 기간', '원칙 3년 (최장 5년)' ),
				array( '결과', '변제 완료 후 남은 채무 면책' ),
			),
			'for'      => array(
				array( '월급은 받지만, 빚 갚기에 다 들어가는 분', '원금은 줄지 않고 이자만 갚고 있다면 회생으로 구조를 바꿀 수 있습니다.' ),
				array( '카드·대출 돌려막기가 한계인 분', '연체가 시작되기 전, 지금이 가장 많은 선택지가 남아 있는 때입니다.' ),
				array( '급여·통장 압류가 걱정되는 분', '신청 후 금지명령으로 압류와 추심을 멈추도록 할 수 있습니다.' ),
				array( '자영업·프리랜서로 소득이 일정하지 않은 분', '사업소득·영업소득도 소득으로 인정받는 방법을 함께 찾습니다.' ),
			),
			'benefits' => array(
				array( '추심·독촉 중단', '금지명령·중지명령으로 채권자의 연락과 강제집행을 멈춥니다.' ),
				array( '원금까지 감면', '소득과 생계비를 기준으로 갚을 금액만 정하고, 나머지는 면책됩니다.' ),
				array( '압류된 급여 회복', '개시결정 이후 급여 압류가 중지되어 생활을 다시 꾸릴 수 있습니다.' ),
				array( '다시 시작할 신용', '면책 후 정상적인 경제 활동으로 돌아가는 길을 함께 안내합니다.' ),
			),
			'steps'    => array(
				array( '상담 · 자격 진단', '소득·재산·채무를 확인하고 예상 변제금을 안내합니다.' ),
				array( '서류 준비 · 신청', '필요 서류를 받은 날부터 2주 안에 법원에 신청합니다.' ),
				array( '금지·중지명령', '압류와 추심을 멈추도록 신청합니다.' ),
				array( '개시결정', '보정 명령에 빠르게 대응해 개시결정을 받습니다.' ),
				array( '변제계획 인가', '채권자 집회를 거쳐 변제계획 인가를 받습니다.' ),
				array( '변제 · 면책', '변제 기간을 함께 관리하고 면책결정으로 마무리합니다.' ),
			),
			'docs'     => array( '신분증', '주민등록등본·초본', '가족관계증명서', '소득 증빙 (급여명세서·원천징수영수증 또는 소득금액증명)', '재산 증빙 (부동산 등기부·자동차 등록원부·임대차계약서)', '채무 내역 (부채증명서 등)' ),
			'playlist' => 'PLbvZ-ZgskpAiRsleQ9M-Lm_UlqJIcdUQ0',
			'faq'      => array(
				array( '현재 소득이 없는데 개인회생을 할 수 있나요?', '개인회생은 앞으로도 꾸준한 소득이 있어야 진행할 수 있습니다. 소득이 없거나 매우 적다면 개인파산을 함께 검토합니다. 상담에서 두 절차 중 맞는 쪽을 안내해 드립니다.' ),
				array( '개인회생을 하면 신용카드·휴대폰을 쓸 수 있나요?', '진행 중에는 신용카드 사용이 제한되지만 체크카드와 휴대폰은 일반적으로 사용할 수 있습니다. 구체적인 사항은 사건별로 달라질 수 있어 상담 시 안내드립니다.' ),
				array( '가족이나 회사에 알려지지 않을까요?', '법원이 가족이나 직장에 따로 통지하는 절차는 원칙적으로 없습니다. 다만 사건에 따라 확인이 필요한 서류가 있어, 상담에서 미리 안내해 드립니다.' ),
			),
		),
		'personal-bankruptcy'      => array(
			'track'    => 'personal',
			'en'       => 'Personal Bankruptcy',
			'headline' => '더는 갚을 수 없을 때,<br><strong>빚의 굴레를 끊는 선택</strong>',
			'lead'     => '개인파산은 소득과 재산으로 빚을 갚을 수 없는 상태(지급불능)에서 파산선고와 면책결정을 받아 채무를 정리하는 절차입니다.',
			'body'     => '나이, 질병, 실직, 사업 실패로 더 이상 갚을 방법이 없다면 파산은 실패가 아니라 다시 시작하기 위한 법적 제도입니다. 우인은 면책까지 이어지도록 재산 조사와 면책 심문을 꼼꼼히 준비합니다.',
			'facts'    => array(
				array( '대상', '소득·재산으로 채무를 갚을 수 없는 개인' ),
				array( '핵심 요건', '지급불능 상태' ),
				array( '절차', '파산선고 → 면책결정' ),
				array( '결과', '면책결정으로 채무 정리 (일부 비면책채권 제외)' ),
			),
			'for'      => array(
				array( '소득이 없거나 최저생계비 수준인 분', '갚을 수 있는 소득이 없다면 회생보다 파산이 맞을 수 있습니다.' ),
				array( '고령·질병으로 일하기 어려운 분', '생활이 어려운 사정을 서류로 잘 정리하는 것이 중요합니다.' ),
				array( '사업 실패 후 빚만 남은 분', '폐업 후 남은 사업자 채무도 함께 검토합니다.' ),
				array( '오랫동안 독촉에 시달려 온 분', '신청 후 강제집행 정지 등으로 숨 쉴 틈을 만듭니다.' ),
			),
			'benefits' => array(
				array( '채무 면책', '면책결정을 받으면 남은 채무를 갚을 책임이 없어집니다.' ),
				array( '강제집행 정지', '파산선고 후 개별 강제집행이 제한됩니다.' ),
				array( '생계 재산 보호', '생활에 필요한 일정 재산은 면제재산으로 보호받을 수 있습니다.' ),
				array( '새 출발', '면책 이후 경제 활동을 다시 시작할 수 있도록 안내합니다.' ),
			),
			'steps'    => array(
				array( '상담 · 진단', '지급불능 여부와 회생·파산 중 맞는 절차를 판단합니다.' ),
				array( '서류 준비 · 신청', '재산·소득·채무 자료를 정리해 신청합니다.' ),
				array( '파산관재인 조사', '관재인이 선임되면 재산·경위 조사에 함께 대응합니다.' ),
				array( '파산선고', '법원이 지급불능을 인정하면 파산을 선고합니다.' ),
				array( '면책 심문', '면책 불허가 사유가 없도록 미리 준비합니다.' ),
				array( '면책결정', '면책결정으로 채무를 정리하고 마무리합니다.' ),
			),
			'docs'     => array( '신분증', '주민등록등본·초본', '가족관계증명서', '소득 증빙 또는 무소득 사실 확인 자료', '재산 증빙 (부동산·자동차·보험·예금)', '채무 내역 및 채무 발생 경위 자료' ),
			'playlist' => 'PLbvZ-ZgskpAgz3eG5Z1-K4YH4lN_Qz41o',
			'faq'      => array(
				array( '파산하면 모든 빚이 없어지나요?', '면책결정을 받으면 대부분의 채무를 갚을 책임이 없어지지만, 세금이나 벌금 등 법이 정한 일부 채권은 면책되지 않습니다. 상담에서 채무 종류별로 안내해 드립니다.' ),
				array( '파산하면 불이익이 있나요?', '파산선고를 받으면 일부 자격 제한이 있을 수 있으나, 면책결정을 받으면 대부분 회복됩니다. 직업별로 달라질 수 있어 미리 확인해 드립니다.' ),
				array( '개인회생과 개인파산, 어떻게 고르나요?', '꾸준한 소득이 있으면 개인회생, 갚을 소득과 재산이 없으면 개인파산이 기본입니다. 실제로는 재산·채무 구조에 따라 달라지므로 상담에서 함께 판단합니다.' ),
			),
		),
		'corporate-rehabilitation' => array(
			'track'    => 'corporate',
			'en'       => 'Corporate Rehabilitation',
			'headline' => '멈춘 회사를 다시 움직이게 하는,<br><strong>법인회생</strong>',
			'lead'     => '법인회생은 일시적인 자금난에 빠졌지만 계속 운영할 가치가 있는 회사가 법원의 관리 아래 채무를 조정하고 정상화하는 절차입니다.',
			'body'     => '회생의 성패는 「언제 신청하느냐」와 「신청 이후를 어떻게 관리하느냐」에 달려 있습니다. 우인은 보전처분부터 회생계획안, 관계인집회, 인가 이후 수행까지 같은 팀이 책임집니다.',
			'facts'    => array(
				array( '대상', '자금난이 있지만 계속기업가치가 있는 회사' ),
				array( '핵심 판단', '계속기업가치 > 청산가치' ),
				array( '보호 조치', '보전처분 · 포괄적 금지명령' ),
				array( '결과', '회생계획 인가 후 채무 조정 · 정상화' ),
			),
			'for'      => array(
				array( '계좌 압류·가압류 통지를 받은 회사', '보전처분과 금지명령으로 강제집행을 멈추는 것이 우선입니다.' ),
				array( '대출 만기 연장이 거절된 회사', '유동성 위기가 본격화되기 전에 신청 시기를 판단해야 합니다.' ),
				array( '급여·세금·4대보험이 밀리기 시작한 회사', '체불이 길어지기 전, 회생 가능성을 먼저 진단합니다.' ),
				array( '거래처는 남아 있지만 부채가 무거운 회사', '영업 기반이 살아 있다면 회생으로 다시 일어설 수 있습니다.' ),
			),
			'benefits' => array(
				array( '강제집행 중단', '보전처분·포괄적 금지명령으로 압류와 추심을 멈춥니다.' ),
				array( '채무 조정', '회생계획에 따라 채무를 감면·유예해 상환 부담을 줄입니다.' ),
				array( '영업 계속', '회사를 운영하면서 절차를 진행해 거래 관계를 지킵니다.' ),
				array( '경영 정상화', '인가 이후에도 계획 수행을 관리해 정상화를 돕습니다.' ),
			),
			'steps'    => array(
				array( '상담 · 진단', '재무 상황과 채무 구조, 회생 가능성을 판단합니다.' ),
				array( '신청서 작성 · 접수', '필요 서류를 받은 날부터 2주 안에 회생법원에 접수합니다.' ),
				array( '보전처분 · 포괄적 금지명령', '강제집행과 추심을 멈추고 숨 쉴 틈을 확보합니다.' ),
				array( '개시결정', '개시결정 이후 조사위원 조사에 함께 대응합니다.' ),
				array( '회생계획안 · 관계인집회', '변제 계획을 설계하고 채권자 동의를 이끌어냅니다.' ),
				array( '인가결정 · 정상화', '인가 이후 계획 수행까지 끝까지 관리합니다.' ),
			),
			'docs'     => array( '법인 등기사항증명서 · 정관', '최근 3년 재무제표', '채권자·채무 목록', '자산 목록 (부동산·설비·매출채권)', '자금 수지 · 향후 사업 계획', '주주 명부 · 임원 현황' ),
			'playlist' => 'PLbvZ-ZgskpAhflcQPgbcLshTgoyIW5zWx',
			'faq'      => array(
				array( '법인회생을 신청하면 대표이사 자리는 유지되나요?', '법인회생에서는 원칙적으로 기존 대표자를 관리인으로 보는 제도가 있어, 경영을 이어가며 절차를 진행할 수 있습니다. 사건에 따라 달라질 수 있어 상담에서 안내드립니다.' ),
				array( '회생 신청 후에도 거래처와 거래를 계속할 수 있나요?', '회생 절차 중에도 영업은 계속됩니다. 거래처 신뢰를 지키는 방법을 함께 준비합니다.' ),
				array( '대표이사의 연대보증 채무는 어떻게 되나요?', '법인회생만으로 대표 개인의 연대보증 채무가 정리되지는 않습니다. 필요한 경우 대표 개인의 회생·파산을 함께 검토합니다.' ),
			),
		),
		'corporate-bankruptcy'     => array(
			'track'    => 'corporate',
			'en'       => 'Corporate Bankruptcy',
			'headline' => '책임 있게 정리하고,<br><strong>다음을 준비하는 법인파산</strong>',
			'lead'     => '법인파산은 회생이 어려운 회사가 법원의 절차에 따라 재산을 정리하고 채권자에게 공평하게 배당한 뒤 법인을 정리하는 절차입니다.',
			'body'     => '회사를 정리하는 일도 대표님의 다음을 위한 준비입니다. 우인은 법인 정리와 함께 대표 개인의 연대보증·체불 책임까지 함께 살펴, 정리 이후의 부담을 최소화하는 방안을 찾습니다.',
			'facts'    => array(
				array( '대상', '회생이 어려운 지급불능 상태의 회사' ),
				array( '절차', '파산선고 → 관재인 환가·배당 → 종결' ),
				array( '함께 볼 것', '대표 개인의 연대보증 · 체불 책임' ),
				array( '결과', '법인 채무의 법적 정리' ),
			),
			'for'      => array(
				array( '회생 가능성이 낮다고 판단된 회사', '정리 시점과 방법에 따라 대표님의 부담이 달라집니다.' ),
				array( '이미 영업이 중단된 회사', '방치하면 채권자 대응과 책임 문제가 커질 수 있습니다.' ),
				array( '임금·퇴직금 체불이 있는 회사', '근로자 대지급금(옛 체당금) 제도를 함께 안내합니다.' ),
				array( '대표 개인이 연대보증을 선 회사', '법인 정리와 대표 개인 절차를 함께 설계합니다.' ),
			),
			'benefits' => array(
				array( '법적 정리', '법원 절차로 법인의 채무 관계를 공식적으로 정리합니다.' ),
				array( '공평한 배당', '관재인이 재산을 환가해 채권자에게 공평하게 배당합니다.' ),
				array( '분쟁 정리', '개별 채권자의 소송·집행 대응 부담을 줄입니다.' ),
				array( '대표님의 다음', '개인 절차 병행으로 정리 이후의 재기를 준비합니다.' ),
			),
			'steps'    => array(
				array( '상담 · 진단', '회생과 파산 중 맞는 길을 판단합니다.' ),
				array( '신청서 작성 · 접수', '재산·채무·근로자 현황을 정리해 신청합니다.' ),
				array( '파산선고 · 관재인 선임', '법원이 파산을 선고하고 관재인을 선임합니다.' ),
				array( '재산 환가', '관재인의 재산 조사·환가에 함께 대응합니다.' ),
				array( '배당', '채권자에게 공평하게 배당합니다.' ),
				array( '종결 · 대표 개인 절차', '법인 정리 후 대표 개인의 절차까지 마무리합니다.' ),
			),
			'docs'     => array( '법인 등기사항증명서 · 정관', '최근 재무제표 · 결산서', '채권자·채무 목록', '자산 목록 및 처분 내역', '근로자 현황 · 체불 내역', '대표이사 연대보증 내역' ),
			'playlist' => 'PLbvZ-ZgskpAhflcQPgbcLshTgoyIW5zWx',
			'faq'      => array(
				array( '법인이 파산하면 대표 개인 빚도 없어지나요?', '법인파산은 법인의 채무를 정리하는 절차로, 대표 개인의 연대보증 채무는 따로 정리해야 합니다. 대표 개인의 회생·파산을 함께 검토합니다.' ),
				array( '직원 급여·퇴직금은 어떻게 되나요?', '체불 임금은 법에서 우선 순위를 두고 있으며, 대지급금(옛 체당금) 제도를 함께 안내합니다.' ),
				array( '회생과 파산 중 어떤 절차가 맞을까요?', '계속 운영할 가치가 청산 가치보다 크면 회생, 그렇지 않으면 파산을 검토합니다. 재무 자료를 보고 함께 판단합니다.' ),
			),
		),
	);
}

/**
 * 업무분야 상세 본문 블록 마크업.
 */
function wooin_service_detail( string $slug ): string {
	$all = wooin_services_data();
	if ( ! isset( $all[ $slug ] ) ) {
		return '';
	}
	$d    = $all[ $slug ];
	$allow = array( 'br' => array(), 'strong' => array() );
	ob_start();
	?>
<!-- wp:html -->
<section class="wooin-sd-intro wooin-sub-section">
	<div class="wooin-sd-wrap wooin-sd-intro-grid">
		<div>
			<p class="wooin-eyebrow is-spaced"><?php echo esc_html( $d['en'] ); ?></p>
			<h2 class="wooin-display"><?php echo wp_kses( $d['headline'], $allow ); ?></h2>
			<p class="wooin-lead"><?php echo esc_html( $d['lead'] ); ?></p>
			<p class="wooin-sd-body"><?php echo esc_html( $d['body'] ); ?></p>
		</div>
		<dl class="wooin-sd-facts">
			<?php foreach ( $d['facts'] as $f ) : ?>
			<div><dt><?php echo esc_html( $f[0] ); ?></dt><dd><?php echo esc_html( $f[1] ); ?></dd></div>
			<?php endforeach; ?>
		</dl>
	</div>
</section>

<section class="wooin-sd-for wooin-sub-section is-tinted">
	<div class="wooin-sd-wrap">
		<div class="wooin-section-head is-center"><p class="wooin-eyebrow is-spaced">Check</p><h2 class="wooin-display">이런 분께 <strong>필요합니다</strong></h2></div>
		<ul class="wooin-sd-checks">
			<?php foreach ( $d['for'] as $item ) : ?>
			<li><h3><?php echo esc_html( $item[0] ); ?></h3><p><?php echo esc_html( $item[1] ); ?></p></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="wooin-sd-benefits wooin-sub-section is-dark">
	<div class="wooin-sd-wrap">
		<div class="wooin-section-head is-center"><p class="wooin-eyebrow is-light is-spaced">Benefits</p><h2 class="wooin-display">신청하면 <em>이렇게 달라집니다</em></h2></div>
		<ol class="wooin-sd-benefit-list">
			<?php foreach ( $d['benefits'] as $i => $b ) : ?>
			<li><span><?php echo esc_html( sprintf( '%02d', $i + 1 ) ); ?></span><h3><?php echo esc_html( $b[0] ); ?></h3><p><?php echo esc_html( $b[1] ); ?></p></li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>

<section class="wooin-sd-steps wooin-sub-section">
	<div class="wooin-sd-wrap wooin-sd-two">
		<div>
			<p class="wooin-eyebrow is-spaced">Process</p>
			<h2 class="wooin-display">진행 <strong>절차</strong></h2>
			<p class="wooin-sd-body">사건마다 기간과 순서가 조금씩 다를 수 있습니다. 단계마다 무엇을 준비해야 하는지 미리 안내해 드립니다.</p>
			<p><a class="wooin-pill-link" href="/procedure/">전체 절차 보기 +</a></p>
		</div>
		<ol class="wooin-steps">
			<?php foreach ( $d['steps'] as $i => $s ) : ?>
			<li><span class="wooin-step-no"><?php echo esc_html( sprintf( '%02d', $i + 1 ) ); ?></span><div><h3><?php echo esc_html( $s[0] ); ?></h3><p><?php echo esc_html( $s[1] ); ?></p></div></li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>

<section class="wooin-sd-docs wooin-sub-section is-tinted">
	<div class="wooin-sd-wrap">
		<div class="wooin-section-head is-center"><p class="wooin-eyebrow is-spaced">Documents</p><h2 class="wooin-display">준비하면 좋은 <strong>서류</strong></h2><p class="has-muted-color">상담 단계에서는 없어도 괜찮습니다. 필요한 서류는 사건에 맞춰 다시 안내해 드립니다.</p></div>
		<ul class="wooin-sd-doc-list">
			<?php foreach ( $d['docs'] as $doc ) : ?>
			<li><?php echo esc_html( $doc ); ?></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="wooin-sd-cases wooin-sub-section">
	<div class="wooin-sd-wrap">
		<div class="wooin-section-head is-row"><div><p class="wooin-eyebrow is-spaced">Solved Cases</p><h2 class="wooin-display">관련 <strong>해결 사례</strong></h2></div><a class="wooin-pill-link" href="/cases/?type=<?php echo esc_attr( $d['track'] ); ?>">사례 전체 보기 +</a></div>
<!-- /wp:html -->
<!-- wp:wooin/case-table {"track":"<?php echo esc_attr( $d['track'] ); ?>","area":"<?php echo esc_attr( $slug ); ?>","limit":5} /-->
<!-- wp:html -->
	</div>
</section>

<section class="wooin-sd-videos wooin-sub-section is-tinted">
	<div class="wooin-sd-wrap">
		<div class="wooin-section-head is-row"><div><p class="wooin-yt-logo"><span aria-hidden="true"></span>이서영 변호사 TV</p><h2 class="wooin-display">영상으로 <strong>쉽게 알아보기</strong></h2></div><a class="wooin-pill-link" href="/videos/">영상 전체 보기 +</a></div>
<!-- /wp:html -->
<!-- wp:wooin/video-grid {"playlist":"<?php echo esc_attr( $d['playlist'] ); ?>","limit":4} /-->
<!-- wp:html -->
	</div>
</section>

<section class="wooin-sd-faq wooin-sub-section">
	<div class="wooin-sd-wrap is-narrow">
		<div class="wooin-section-head is-center"><p class="wooin-eyebrow is-spaced">FAQ</p><h2 class="wooin-display">자주 묻는 <strong>질문</strong></h2></div>
		<div class="wooin-accordion">
			<?php foreach ( $d['faq'] as $q ) : ?>
			<details><summary><?php echo esc_html( $q[0] ); ?></summary><p><?php echo esc_html( $q[1] ); ?></p></details>
			<?php endforeach; ?>
		</div>
		<p class="wooin-mock-note">※ 일반적인 안내이며, 구체적인 사안은 상담을 통해 확인해 주세요.</p>
	</div>
</section>
<!-- /wp:html -->
	<?php
	return (string) ob_get_clean();
}
