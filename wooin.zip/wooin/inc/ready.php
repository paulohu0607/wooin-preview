<?php
/**
 * 원고가 아직 없는 페이지(「준비 중」 = wooin/coming-soon 패턴)는 방문자 메뉴에서 숨긴다.
 *
 * - 헤더 메뉴 · 2차 메뉴 · 본문 바로가기 링크에서 빠진다. 주소로 직접 들어오면 「준비 중」 화면은 그대로 보인다.
 * - 편집 권한자(관리자 등)에게는 그대로 보여 원고를 넣고 확인할 수 있다.
 * - 원고를 넣어 「준비 중」 패턴이 빠지면 자동으로 메뉴에 다시 나온다.
 * - 개인정보처리방침 · 면책공고 등 푸터 법정 링크는 숨기지 않는다.
 *
 * @package wooin
 */

defined( 'ABSPATH' ) || exit;

function wooin_path_ready( string $url ): bool {
	if ( current_user_can( 'edit_pages' ) ) {
		return true;
	}
	$path = trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
	if ( '' === $path ) {
		return true;
	}
	static $cache = array();
	if ( ! isset( $cache[ $path ] ) ) {
		$page           = get_page_by_path( $path );
		$cache[ $path ] = ! ( $page && str_contains( (string) $page->post_content, 'wooin/coming-soon' ) );
	}
	return $cache[ $path ];
}

add_filter(
	'render_block_core/navigation-link',
	static fn( $html, $block ) => wooin_path_ready( (string) ( $block['attrs']['url'] ?? '' ) ) ? $html : '',
	10,
	2
);
