<?php
/**
 * 브랜드 표기 — wooin/brand 블록 (헤더 · 푸터)
 *
 * 「회생파산연구소」 로고 + 「법률사무소 우인」을 한 줄로 (2026-10-26 클라이언트 요청, 모바일 포함).
 * 로고는 클라이언트 제공 AI 파일을 투명 PNG 로 변환 (assets/images/brand/rehab-lab-logo.png).
 * 글자색을 따라가도록 CSS mask 로 칠한다 → 흰 헤더에서는 검정, 메인 첫 화면(투명 헤더)·푸터에서는 흰색.
 * 사무소 이름은 공통정보(brand_name)에서 읽는다.
 *
 * @package wooin
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'init',
	static function () {
		register_block_type(
			'wooin/brand',
			array(
				'title'           => '브랜드 (로고 + 사무소 이름)',
				'category'        => 'theme',
				'render_callback' => 'wooin_render_brand',
				'supports'        => array( 'html' => false ),
			)
		);
	}
);

function wooin_render_brand(): string {
	$name = function_exists( 'wooin_core_site_info' ) ? wooin_core_site_info( 'brand_name' ) : '';
	$name = $name ? $name : get_bloginfo( 'name' );
	$logo = get_theme_file_uri( 'assets/images/brand/rehab-lab-logo.png' );
	return sprintf(
		'<a class="wooin-brand" href="%1$s" rel="home"><span class="wooin-brand-logo" role="img" aria-label="회생파산연구소" style="--logo:url(%2$s)"></span><span class="wooin-brand-bar" aria-hidden="true"></span><span class="wooin-brand-name">%3$s</span></a>',
		esc_url( home_url( '/' ) ),
		esc_url( $logo ),
		esc_html( $name )
	);
}
