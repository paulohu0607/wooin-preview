<?php
/**
 * 구성원 — 이서영 변호사 · 서동기 회계사 · 박만용 세무사
 *
 * 원고 출처 (2026-10-15 사용자 제공): 로톡 이서영 변호사 프로필 이력, 로집사 세무회계 구성원 프로필.
 * 실제 내용은 관리자 「구성원」 글(이름·순서·대표 이미지 + 프로필 칸, wooin-core person-fields.php)에서 읽는다.
 * 아래 wooin_people_defaults() 는 기본 원고 — 처음 한 번 관리자 칸으로 옮겨지고, 비어 있는 칸을 채울 때만 쓴다.
 * 한 곳(wooin_people)에서 메인 구성원 캐러셀 · 구성원 목록 · 각 상세 페이지를 함께 그린다.
 * 사진: assets/images/people/ (lee-seoyoung-light.jpg 는 인사말·하단바용 원본) — 세 분 얼굴 크기·위치를 맞추고 배경을 같은 어두운 회색으로 통일한 보정본 (2026-11-06, 사진관 표기 제거).
 *
 * @package wooin
 */

defined( 'ABSPATH' ) || exit;

function wooin_people_defaults(): array {
	return array(
		'lee-seoyoung' => array(
			'name'     => '이서영',
			'title'    => '대표 변호사',
			'en'       => 'Attorney at Law',
			'photo'    => 'lee-seoyoung.jpg',
			'tone'     => 'dark',
			'headline' => '회생과 파산의 답,<br><em>이서영 변호사</em>에게 있습니다.',
			'intro'    => '2016년 변호사가 된 뒤 오직 도산 분야만 연구했습니다. 4천 건이 넘는 사건에서 기업과 대표님, 전문직 의뢰인과 함께하며 배운 것은 하나입니다. 위기는 빨리 마주할수록 선택지가 많아진다는 것. 이제 그 경험으로 위기의 기업과 채무에 묶인 대표님 곁에 서겠습니다.',
			'points'   => array(
				'9년간 오직 도산 분야만 연구',
				'4천 건 이상의 회생·파산 성공사례',
				'대한변호사협회 이사',
				'대한변호사협회 광고심사위원회 위원',
				'관세청 특허심사위원회 위원',
				'유튜브 구독자 {구독자}',
			),
			'groups'   => array(
				'경력' => array(
					array( '2023 ~', '법률사무소 우인 대표변호사' ),
					array( '2025 ~', '대한변호사협회 이사' ),
					array( '2025 ~', '대한변호사협회 광고심사위원회 위원' ),
					array( '2025 ~', '대한변호사협회 대의원' ),
					array( '2025 ~', '관세청 특허심사위원회 위원' ),
					array( '2022 ~ 2023', '법무법인 에이파트 대표변호사' ),
					array( '2016 ~ 2022', '변호사 이서영 법률사무소 대표변호사' ),
				),
				'자격' => array(
					array( '2016', '변호사' ),
				),
				'학력' => array(
					array( '2013 ~ 2016', '중앙대학교 법학전문대학원 석사 졸업' ),
					array( '2007 ~ 2012', '경북대학교 국어국문학과 학사 졸업' ),
				),
			),
			'media'    => array(
				array( '2024.10', '부티플', '"카드값 밀리면 생기는 일" 1일, 5일, 90일, 6개월 기간별로' ),
				array( '2024.08', '지식인사이드', '대한민국 서민이 빚 \'1억\' 가장 빨리 갚는 현실적인 방법' ),
				array( '2024.01', '문화일보', '개인회생·법인파산 \'역대 최고\'… 꽁꽁 언 바닥경기' ),
				array( '2023.03', 'SBS뉴스', '"코로나 때 겨우 버텼는데"…"이젠 한계" 꽉 찬 민원실' ),
				array( '2023.01', '아주경제', '김명수 "회생 지역편차 극복"…\'회생법원 확대\' 강조' ),
				array( '2023.01', 'YTN라디오', '"결혼식 앞두고 알게 된 예비신랑의 복잡한 여자관계와 빚' ),
				array( '2022.07', '아주경제', '서울 사람만 구제?...회생법원 \'주식·코인 탕감\' 형평성 논란' ),
				array( '2022.07', '경인일보', '개인회생 때 코인·주식 빚 탕감… 경기도민은 해당 안돼' ),
				array( '2022.07', 'SBS뉴스', '"주식 · 가상화폐 투자 빚 없는 걸로 쳐주겠다" 결정 논란' ),
				array( '2022.07', '조선경제', '코인 빚투 안 갚아도 된다고?… 개인 회생 신청하는 2030 급증' ),
				array( '2022.07', '경인일보', '"서울 두 달, 경기 반년 걸려"… 채무자 피말리는 \'파산 선고\'' ),
				array( '2022.06', '성공예감', '빚내서 코인으로 날려도 파산 면책 가능할까?' ),
			),
			'outlets'  => array( 'SBS뉴스', 'YTN라디오', '문화일보', '조선경제', '아주경제', '경인일보', '지식인사이드' ),
		),
		'seo-donggi'   => array(
			'name'     => '서동기',
			'title'    => '공인회계사',
			'en'       => 'Certified Public Accountant',
			'photo'    => 'seo-donggi.jpg',
			'tone'     => 'dark',
			'headline' => '회사의 가치를<br><em>숫자로 증명</em>합니다.',
			'intro'    => '법인회생의 성패는 계속기업가치를 얼마나 설득력 있게 입증하느냐에 달려 있습니다. 회생법원 관리위원 경험을 바탕으로, 조사위원 대응부터 회생계획안의 재무 전략까지 함께 설계합니다.',
			'points'   => array(
				'전 대전지방법원 회생법원 관리위원',
				'고난도 조사위원 대응',
				'계속기업가치·청산가치 이의',
				'회생계획안 재무 전략 자문',
				'회생 M&A 재무 자문',
				'부동산 비중이 큰 회생기업 자문',
			),
			'groups'   => array(
				'주요 이력' => array(
					array( '전', '대전지방법원 회생법원 관리위원' ),
				),
				'주요 업무' => array(
					array( '', '고난도 조사위원 대응' ),
					array( '', '계속기업가치·청산가치 이의' ),
					array( '', '회생계획안 재무 전략 자문' ),
					array( '', '부동산 비중이 큰 회생기업 자문' ),
					array( '', '회생 M&A 재무 자문' ),
					array( '', '법인파산 시 재무 정리' ),
					array( '', '회생기업 회계 처리 자문' ),
					array( '', '채무자 의견서 작성' ),
				),
			),
			'media'    => array(),
			'outlets'  => array(),
		),
		'park-manyong' => array(
			'name'     => '박만용',
			'title'    => '세무사',
			'en'       => 'Certified Tax Accountant',
			'photo'    => 'park-manyong.jpg',
			'tone'     => 'dark',
			'headline' => '회생 기업의 세무,<br><em>신청부터 인가 이후까지</em>',
			'intro'    => '회생 절차 중에도 회사의 장부와 세무는 멈추지 않습니다. 법원 조사위원 경험을 바탕으로 법원에 내는 재무 서류부터 이월결손금 활용, 인가 이후 재무제표 재작성까지 세무 전 과정을 책임집니다.',
			'points'   => array(
				'전 대전지방법원 조사위원',
				'회생기업 기장 통합 관리',
				'법원 허가 신청 재무 서류',
				'조사위원 대응 자료 작성',
				'이월결손금 활용 설계',
				'인가 후 재무제표 재작성',
			),
			'groups'   => array(
				'주요 이력' => array(
					array( '전', '대전지방법원 조사위원' ),
				),
				'주요 업무' => array(
					array( '', '회생기업 기장 통합 관리' ),
					array( '', '산업별 월간업무보고서 작성' ),
					array( '', '법원 허가 신청 재무 서류' ),
					array( '', '회생·파산 세무 종합' ),
					array( '', '자본 회복 전략의 세무 효과' ),
					array( '', '이월결손금 활용 설계' ),
					array( '', '조사위원 대응 자료 작성' ),
					array( '', '인가 후 재무제표 재작성' ),
				),
			),
			'media'    => array(),
			'outlets'  => array(),
		),
	);
}

/**
 * 화면에 보일 구성원 — 공개된 「구성원」 글을 순서대로. 글이 하나도 없으면 기본 원고.
 *
 * @return array<string, array> slug => 프로필 (photo_url 포함)
 */
function wooin_people(): array {
	static $people = null;
	if ( null !== $people ) {
		return $people;
	}
	$defaults = wooin_people_defaults();
	$blank    = array( 'name' => '', 'title' => '', 'en' => '', 'photo' => '', 'tone' => 'dark', 'headline' => '', 'intro' => '', 'points' => array(), 'groups' => array(), 'media' => array(), 'outlets' => array() );
	$posts    = get_posts( array( 'post_type' => 'wooin_person', 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'ASC' ) ) );

	if ( ! $posts ) {
		$fill   = static fn( $t ) => function_exists( 'wooin_yt_fill' ) ? wooin_yt_fill( $t ) : $t;
		$people = array_map( static fn( $p ) => array_merge( $p, array( 'points' => array_map( $fill, $p['points'] ), 'photo_url' => get_theme_file_uri( 'assets/images/people/' . $p['photo'] ) ) ), $defaults );
		return $people;
	}
	$people = array();
	foreach ( $posts as $post ) {
		$p         = ( $defaults[ $post->post_name ] ?? array() ) + $blank;
		$saved     = function_exists( 'wooin_person_profile' ) ? wooin_person_profile( $post->ID ) : array();
		$p         = array_merge( $p, $saved );
		// 글 제목이 「이서영 변호사」처럼 직함까지 포함하면 이름만 쓴다 (직함은 따로 표시됨)
		$name  = trim( get_the_title( $post ) );
		$words = preg_split( '/\s+/u', $name );
		if ( count( $words ) > 1 && '' !== $p['title'] && str_contains( $p['title'], (string) end( $words ) ) ) {
			array_pop( $words );
			$name = implode( ' ', $words );
		}
		$p['name'] = $name;
		if ( isset( $saved['headline'] ) ) {
			$p['headline'] = $saved['headline']; // 이미 이스케이프·꾸밈 적용
		}
		$thumb          = get_the_post_thumbnail_url( $post, 'large' );
		$p['photo_url'] = $thumb ? $thumb : ( $p['photo'] ? get_theme_file_uri( 'assets/images/people/' . $p['photo'] ) : '' );
		$p['points']    = $p['points'] ? $p['points'] : array( $p['title'] );
		$people[ $post->post_name ] = $p;
	}
	return $people;
}

function wooin_person_photo( array $p ): string {
	return (string) ( $p['photo_url'] ?? get_theme_file_uri( 'assets/images/people/' . $p['photo'] ) );
}

function wooin_person_url( string $slug ): string {
	return home_url( '/people/' . $slug . '/' );
}

/* ---------------------------------------------------------------- 블록: 구성원 상세 · 구성원 목록 */

add_action(
	'init',
	static function () {
		register_block_type(
			'wooin/person-detail',
			array(
				'title'           => '구성원 상세',
				'category'        => 'theme',
				'attributes'      => array( 'slug' => array( 'type' => 'string', 'default' => '' ) ),
				'render_callback' => static function ( $attrs ) {
					$slug = $attrs['slug'] ? $attrs['slug'] : (string) get_post_field( 'post_name', get_the_ID() );
					return do_blocks( wooin_person_detail( $slug ) );
				},
				'supports'        => array( 'html' => false ),
			)
		);
		register_block_type(
			'wooin/people-list',
			array(
				'title'           => '구성원 목록',
				'category'        => 'theme',
				'render_callback' => static fn() => '<section class="wooin-sub-section"><div class="wooin-sd-wrap"><div class="wooin-section-head is-center"><p class="wooin-eyebrow is-spaced">One Team</p><h2 class="wooin-display">변호사 · 회계사 · 세무사가<br><strong>한 팀으로 움직입니다</strong></h2><p class="has-muted-color">법인회생은 법률만으로 끝나지 않습니다. 기업가치 평가와 세무까지 처음부터 함께 설계합니다.</p></div>' . wooin_people_cards() . '</div></section>',
				'supports'        => array( 'html' => false ),
			)
		);
	}
);

/* ---------------------------------------------------------------- 메인 구성원 캐러셀 */

function wooin_people_carousel(): string {
	$allow = array( 'br' => array(), 'em' => array() );
	ob_start();
	?>
<div class="wooin-people-head">
	<p class="wooin-eyebrow is-light is-spaced">Our Experts</p>
	<div class="wooin-carousel-nav is-dark" data-carousel-nav="people">
		<button type="button" class="wooin-carousel-btn" data-dir="-1" aria-label="이전 구성원">←</button>
		<button type="button" class="wooin-carousel-btn" data-dir="1" aria-label="다음 구성원">→</button>
	</div>
</div>
<div class="wooin-carousel is-people" data-carousel="people" role="region" aria-roledescription="carousel" aria-label="구성원 소개">
	<ul class="wooin-carousel-track" tabindex="0">
		<?php foreach ( wooin_people() as $slug => $p ) : ?>
		<li class="wooin-carousel-slide" aria-roledescription="slide" aria-label="<?php echo esc_attr( $p['title'] . ' ' . $p['name'] ); ?>">
			<div class="wooin-person-slide">
				<div class="wooin-person-photo is-<?php echo esc_attr( $p['tone'] ); ?>" style="background-image:url(<?php echo esc_url( wooin_person_photo( $p ) ); ?>)">
					<p class="wooin-person-sign"><?php echo esc_html( $p['name'] ); ?><br><span><?php echo esc_html( $p['en'] ); ?></span></p>
				</div>
				<div class="wooin-person-text">
					<p class="wooin-eyebrow is-light is-spaced"><?php echo esc_html( $p['en'] ); ?></p>
					<h2 class="wooin-display has-white-color"><?php echo wp_kses( $p['headline'], $allow ); ?></h2>
					<p class="wooin-lawyer-intro"><?php echo esc_html( $p['intro'] ); ?></p>
					<p class="wooin-lawyer-name"><?php echo esc_html( $p['title'] ); ?> <strong><?php echo esc_html( $p['name'] ); ?></strong></p>
					<ul class="wooin-points">
						<?php foreach ( $p['points'] as $i => $pt ) : ?>
						<li class="wooin-point"><b><?php echo esc_html( sprintf( '%02d', $i + 1 ) ); ?></b><?php echo esc_html( $pt ); ?></li>
						<?php endforeach; ?>
					</ul>
					<p class="wooin-person-more"><a class="wooin-track-cta" href="<?php echo esc_url( wooin_person_url( $slug ) ); ?>"><?php echo esc_html( $p['name'] . ' ' . $p['title'] ); ?> 소개 →</a></p>
				</div>
			</div>
		</li>
		<?php endforeach; ?>
	</ul>
	<div class="wooin-carousel-dots" aria-hidden="true"></div>
</div>
	<?php
	return (string) ob_get_clean();
}

/* ---------------------------------------------------------------- 구성원 카드 목록 */

function wooin_people_cards( string $except = '' ): string {
	$html = '<ul class="wooin-team">';
	foreach ( wooin_people() as $slug => $p ) {
		if ( $slug === $except ) {
			continue;
		}
		$html .= sprintf(
			'<li><a href="%1$s"><span class="wooin-team-photo is-%2$s" style="background-image:url(%3$s)"></span><span class="wooin-team-role">%4$s</span><strong>%5$s</strong><span class="wooin-team-line">%6$s</span><span class="wooin-team-more">프로필 보기 →</span></a></li>',
			esc_url( wooin_person_url( $slug ) ),
			esc_attr( $p['tone'] ),
			esc_url( wooin_person_photo( $p ) ),
			esc_html( $p['title'] ),
			esc_html( $p['name'] ),
			esc_html( implode( ' · ', array_slice( $p['points'], 0, 2 ) ) )
		);
	}
	return $html . '</ul>';
}

/* ---------------------------------------------------------------- 구성원 상세 */

function wooin_person_detail( string $slug ): string {
	$all = wooin_people();
	if ( ! isset( $all[ $slug ] ) ) {
		return '';
	}
	$p     = $all[ $slug ];
	$allow = array( 'br' => array(), 'em' => array() );
	ob_start();
	?>
<!-- wp:html -->
<section class="wooin-sub-section">
	<div class="wooin-sd-wrap wooin-profile">
		<div class="wooin-person-photo is-<?php echo esc_attr( $p['tone'] ); ?>" style="background-image:url(<?php echo esc_url( wooin_person_photo( $p ) ); ?>)">
			<p class="wooin-person-sign"><?php echo esc_html( $p['name'] ); ?><br><span><?php echo esc_html( $p['en'] ); ?></span></p>
		</div>
		<div class="wooin-profile-text">
			<p class="wooin-eyebrow is-spaced"><?php echo esc_html( $p['en'] ); ?></p>
			<h2 class="wooin-display"><?php echo wp_kses( $p['headline'], $allow ); ?></h2>
			<p class="wooin-sd-body"><?php echo esc_html( $p['intro'] ); ?></p>
			<p class="wooin-profile-name"><?php echo esc_html( $p['title'] ); ?> <strong><?php echo esc_html( $p['name'] ); ?></strong></p>
			<ul class="wooin-profile-points">
				<?php foreach ( $p['points'] as $pt ) : ?><li><?php echo esc_html( $pt ); ?></li><?php endforeach; ?>
			</ul>
		</div>
	</div>
</section>

<section class="wooin-sub-section is-tinted">
	<div class="wooin-sd-wrap wooin-sd-two">
		<div>
			<p class="wooin-eyebrow is-spaced">Profile</p>
			<h2 class="wooin-display">주요 <strong>이력</strong></h2>
			<p class="wooin-sd-body">확인된 이력만 게재합니다.</p>
		</div>
		<div class="wooin-career">
			<?php foreach ( $p['groups'] as $label => $rows ) : ?>
			<h3><?php echo esc_html( $label ); ?></h3>
			<ul>
				<?php foreach ( $rows as $row ) : ?>
				<li><?php echo $row[0] ? '<b' . ( mb_strlen( $row[0] ) < 2 ? ' class="is-short"' : '' ) . '>' . esc_html( $row[0] ) . '</b>' : ''; ?><?php echo esc_html( $row[1] ); ?></li>
				<?php endforeach; ?>
			</ul>
			<?php endforeach; ?>
		</div>
	</div>
</section>
	<?php if ( $p['media'] ) : ?>

<section class="wooin-sub-section">
	<div class="wooin-sd-wrap">
		<div class="wooin-section-head is-center"><p class="wooin-eyebrow is-spaced">Media</p><h2 class="wooin-display">언론 · 방송 <strong>활동</strong></h2><p class="has-muted-color">회생·파산 이슈마다 언론이 이서영 변호사의 의견을 묻습니다.</p></div>
		<ul class="wooin-outlets"><?php foreach ( $p['outlets'] as $o ) : ?><li><?php echo esc_html( $o ); ?></li><?php endforeach; ?></ul>
		<ol class="wooin-media-list">
			<?php foreach ( $p['media'] as $m ) : ?>
			<li><time><?php echo esc_html( $m[0] ); ?></time><span class="wooin-chip is-line"><?php echo esc_html( $m[1] ); ?></span><p><?php echo esc_html( $m[2] ); ?></p></li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>
	<?php endif; ?>
<!-- /wp:html -->
	<?php if ( 'lee-seoyoung' === $slug ) : ?>

<!-- wp:group {"className":"wooin-sub-section is-tinted","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group wooin-sub-section is-tinted">
	<!-- wp:html -->
	<div class="wooin-section-head is-row"><div><p class="wooin-yt-logo"><span aria-hidden="true"></span>이서영 변호사 TV</p><h2 class="wooin-display">영상으로 만나는 <strong>이서영 변호사</strong></h2></div><a class="wooin-pill-link" href="/videos/">영상 전체 보기 +</a></div>
	<!-- /wp:html -->
	<!-- wp:wooin/video-grid {"limit":4} /-->
</div>
<!-- /wp:group -->
	<?php endif; ?>

<!-- wp:html -->
<section class="wooin-sub-section">
	<div class="wooin-sd-wrap">
		<div class="wooin-section-head is-center"><p class="wooin-eyebrow is-spaced">One Team</p><h2 class="wooin-display">변호사 · 회계사 · 세무사가<br><strong>한 팀으로 움직입니다</strong></h2></div>
		<?php echo wooin_people_cards( $slug ); // phpcs:ignore WordPress.Security.EscapeOutput -- 함수 안에서 이스케이프 ?>
	</div>
</section>
<!-- /wp:html -->
	<?php
	return (string) ob_get_clean();
}
