<?php
/**
 * 서브페이지 공통 상단 밴드 — wooin/sub-hero 블록
 *
 * 현재 주소로 메뉴 그룹(전송 메뉴 구조)을 찾아 영문 소제목 · 제목 · 설명 · 배경 · 경로(breadcrumb) · 2차 메뉴 탭을 그린다.
 * 템플릿에 <!-- wp:wooin/sub-hero /--> 한 줄만 넣으면 된다. 메뉴 구성이 바뀌면 이 파일의 wooin_menu_groups() 와 parts/header.html 을 함께 고친다.
 *
 * @package wooin
 */

defined( 'ABSPATH' ) || exit;

/**
 * 메뉴 그룹 = 헤더 1차 메뉴. items 는 2차 메뉴(경로 => 이름). 배경은 시안용 Unsplash 샘플.
 */
function wooin_menu_groups(): array {
	return array(
		'about'    => array(
			'label' => '법률사무소 우인',
			'en'    => 'About Wooin',
			'bg'    => 'photo-1714974528749-fc028e54feb9',
			'items' => array(
				'/about/'               => '인사말',
				'/people/'              => '구성원 소개',
				'/why/'                 => '왜 우인인가',
				'/news/'                => '우인 소식',
				'/location/'            => '오시는 길',
			),
		),
		'services' => array(
			'label' => '업무분야',
			'en'    => 'Practice Areas',
			'bg'    => 'photo-1601923112035-3e4819c82317',
			'items' => array(
				'/services/corporate-rehabilitation/' => '법인회생',
				'/services/corporate-bankruptcy/'     => '법인파산',
				'/services/personal-rehabilitation/'  => '개인회생',
				'/services/personal-bankruptcy/'      => '개인파산',
				'/procedure/'                         => '회생·파산 절차',
				'/support/'                           => '지원 사업 안내',
			),
		),
		'cases'    => array(
			'label' => '해결사례',
			'en'    => 'Solved Cases',
			'bg'    => 'photo-1450101499163-c8848c66ca85',
			'items' => array(
				'/cases/'       => '성공사례',
				'/major-cases/' => '주요 도산 사건',
			),
		),
		'info'     => array(
			'label' => '법률정보',
			'en'    => 'Legal Insights',
			'bg'    => 'photo-1564846824194-346b7871b855',
			'items' => array(
				'/videos/'  => '이서영 변호사 TV',
				'/column/'  => '전문가 칼럼',
				'/faq/'     => '자주 묻는 질문',
				'/notices/' => '회생·파산 기업 공고',
			),
		),
		'contact'  => array(
			'label' => '상담안내',
			'en'    => 'Consultation',
			'bg'    => 'photo-1643175517006-4a1bd8ad37cb',
			'items' => array(
				'/consultation-guide/' => '상담 절차 안내',
				'/contact/corporate/'  => '법인회생·파산 상담 신청',
				'/contact/personal/'   => '개인회생·파산 상담 신청',
			),
		),
		'reviews'  => array(
			'label' => '의뢰인 후기',
			'en'    => 'Client Reviews',
			'bg'    => 'photo-1714974528693-f77f6fcc56af',
			'items' => array(
				'/reviews/' => '의뢰인 후기',
			),
		),
		'policy'   => array(
			'label' => '안내',
			'en'    => 'Policy',
			'bg'    => '',
			'items' => array(
				'/privacy/'      => '개인정보처리방침',
				'/disclaimer/'   => '면책공고',
				'/email-policy/' => '이메일무단수집거부',
			),
		),
	);
}

/**
 * 페이지별 설명 문구 (경로 => 설명). 없으면 요약(excerpt)을 쓴다.
 */
function wooin_sub_descriptions(): array {
	return array(
		'/about/'              => '위기의 기업과 대표님, 채무에 묶인 전문직 곁에서 다시 시작하는 길을 함께 찾습니다.',
		'/why/'                => '4,000건의 경험이 만든 우인의 6가지 원칙을 소개합니다.',
		'/location/'           => '방문 상담은 예약 후 진행됩니다. 오시기 전 연락 주세요.',
		'/services/'           => '개인부터 법인까지, 도산 한 분야에만 집중합니다.',
		'/procedure/'          => '신청부터 인가·면책까지, 단계마다 해야 할 일을 안내합니다.',
		'/cases/'              => '얼마의 부채가, 어떻게 정리되었는지. 우인이 함께한 결과를 공개합니다.',
		'/news/'               => '우인의 공지와 활동 소식을 전합니다.',
		'/people/'             => '도산 전문 변호사와 회계사 · 세무사가 한 팀으로 함께합니다.',
		'/reviews/'            => '같은 길을 먼저 지나온 의뢰인들이 직접 남긴 이야기입니다.',
		'/faq/'                => '상담에서 가장 많이 받는 질문을 모았습니다.',
		'/column/'             => '회생·파산 실무와 판례를 이서영 변호사가 쉽게 풀어 드립니다.',
		'/consultation-guide/' => '상담 신청부터 진행 결정까지, 어떻게 진행되는지 안내합니다.',
		'/contact/'            => '남겨주신 내용은 담당 변호사와 상담 담당자만 확인합니다.',
		'/contact/personal/'   => '개인회생·개인파산 상담을 신청합니다. 남겨주신 내용은 비밀이 보장됩니다.',
		'/contact/corporate/'  => '법인회생·법인파산 상담을 신청합니다. 남겨주신 내용은 비밀이 보장됩니다.',
	);
}

/** 현재 요청 경로 (/services/personal-rehabilitation/ 형태). */
function wooin_current_path(): string {
	$path = wp_parse_url( home_url( add_query_arg( array() ) ), PHP_URL_PATH );
	$path = '/' . trim( (string) $path, '/' ) . '/';
	return '//' === $path ? '/' : $path;
}

/** 현재 경로가 속한 그룹 키. 2차 메뉴 경로의 앞부분 일치로 찾는다. */
function wooin_current_group( string $path ): string {
	$prefixes = array(
		'/people/'   => 'about',
		'/news/'     => 'about',
		'/services/' => 'services',
		'/cases/'    => 'cases',
		'/reviews/'  => 'reviews',
		'/videos/'   => 'info',
		'/contact/'  => 'contact',
	);
	foreach ( wooin_menu_groups() as $key => $group ) {
		if ( isset( $group['items'][ $path ] ) ) {
			return $key;
		}
	}
	foreach ( $prefixes as $prefix => $key ) {
		if ( str_starts_with( $path, $prefix ) ) {
			return $key;
		}
	}
	return '';
}

function wooin_sub_title(): string {
	// 게시판 글 상세는 상단에 게시판 이름을, 본문에 글 제목을 보여준다
	if ( is_singular( 'wooin_review' ) ) {
		return '의뢰인 후기';
	}
	if ( is_singular( 'wooin_news' ) ) {
		return '우인 소식';
	}
	if ( is_singular() ) {
		return get_the_title();
	}
	if ( is_home() ) {
		return '전문가 칼럼';
	}
	if ( is_post_type_archive( 'wooin_case' ) ) {
		return '해결 사례';
	}
	if ( is_post_type_archive( 'wooin_news' ) ) {
		return '우인 소식';
	}
	if ( is_post_type_archive( 'wooin_person' ) ) {
		return '구성원 소개';
	}
	if ( is_post_type_archive( 'wooin_review' ) ) {
		return '의뢰인 후기';
	}
	if ( is_post_type_archive( 'wooin_service' ) ) {
		return '업무분야';
	}
	if ( is_archive() ) {
		return wp_strip_all_tags( get_the_archive_title() );
	}
	if ( is_404() ) {
		return '페이지를 찾을 수 없습니다';
	}
	return get_bloginfo( 'name' );
}

add_action(
	'init',
	static function () {
		register_block_type(
			'wooin/sub-hero',
			array(
				'title'           => '서브페이지 상단 밴드',
				'category'        => 'theme',
				'render_callback' => 'wooin_render_sub_hero',
				'supports'        => array( 'html' => false ),
			)
		);
	}
);

function wooin_render_sub_hero(): string {
	$path   = wooin_current_path();
	$key    = wooin_current_group( $path );
	$groups = wooin_menu_groups();
	$group  = $key ? $groups[ $key ] : null;
	$title  = wooin_sub_title();
	$descs  = wooin_sub_descriptions();
	$desc   = $descs[ $path ] ?? ( is_singular() && has_excerpt() ? get_the_excerpt() : '' );

	$bg = ( $group && $group['bg'] )
		? 'background-image: linear-gradient(90deg, rgba(0,0,0,.82), rgba(0,0,0,.45)), url(https://images.unsplash.com/' . $group['bg'] . '?w=2000&q=70&auto=format);'
		: '';

	$html  = '<section class="wooin-sub-hero" style="' . esc_attr( $bg ) . '">';
	$html .= '<div class="wooin-sub-hero-inner">';
	$html .= '<nav class="wooin-crumb" aria-label="현재 위치"><a href="' . esc_url( home_url( '/' ) ) . '">홈</a>';
	if ( $group ) {
		$first = array_key_first( $group['items'] );
		$html .= '<span aria-hidden="true">›</span><a href="' . esc_url( home_url( $first ) ) . '">' . esc_html( $group['label'] ) . '</a>';
	}
	$html .= '<span aria-hidden="true">›</span><span aria-current="page">' . esc_html( $title ) . '</span></nav>';
	if ( $group ) {
		$html .= '<p class="wooin-eyebrow is-light is-spaced">' . esc_html( $group['en'] ) . '</p>';
	}
	$html .= '<h1 class="wooin-sub-title">' . esc_html( $title ) . '</h1>';
	if ( $desc ) {
		$html .= '<p class="wooin-sub-desc">' . esc_html( $desc ) . '</p>';
	}
	$html .= '</div></section>';

	if ( $group && count( $group['items'] ) > 1 ) {
		$html .= '<nav class="wooin-localnav" aria-label="' . esc_attr( $group['label'] ) . ' 메뉴"><ul>';
		foreach ( $group['items'] as $href => $label ) {
			$current = ( $href === $path || ( in_array( $href, array( '/cases/', '/people/', '/news/' ), true ) && str_starts_with( $path, $href ) ) );
			$html   .= '<li><a href="' . esc_url( home_url( $href ) ) . '"' . ( $current ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a></li>';
		}
		$html .= '</ul></nav>';
	}

	return $html;
}
