// 좌우 캐러셀: 스크롤 스냅 트랙 + 이전/다음 버튼 + 점 + 자동 넘김(마우스·포커스 시 멈춤, 동작 줄이기 설정 시 끔).
( function () {
	var reduce = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	document.querySelectorAll( '[data-carousel]' ).forEach( function ( root ) {
		var track = root.querySelector( '.wooin-carousel-track' );
		var slides = Array.prototype.slice.call( track.children );
		var dotsBox = root.querySelector( '.wooin-carousel-dots' );
		var nav = document.querySelector( '[data-carousel-nav="' + root.getAttribute( 'data-carousel' ) + '"]' );
		var timer = null;

		function step() {
			return slides.length > 1 ? slides[ 1 ].offsetLeft - slides[ 0 ].offsetLeft : track.clientWidth;
		}
		function perView() {
			return Math.max( 1, Math.round( track.clientWidth / step() ) );
		}
		function pages() {
			return Math.max( 1, slides.length - perView() + 1 );
		}
		function current() {
			return Math.min( pages() - 1, Math.round( track.scrollLeft / step() ) );
		}
		function go( index ) {
			var last = pages() - 1;
			if ( index > last ) { index = 0; }
			if ( index < 0 ) { index = last; }
			track.scrollTo( { left: index * step(), behavior: reduce ? 'auto' : 'smooth' } );
		}

		function renderDots() {
			dotsBox.innerHTML = '';
			for ( var i = 0; i < pages(); i++ ) {
				var dot = document.createElement( 'button' );
				dot.type = 'button';
				dot.setAttribute( 'aria-label', ( i + 1 ) + '번째 슬라이드로' );
				dot.addEventListener( 'click', go.bind( null, i ) );
				dotsBox.appendChild( dot );
			}
			syncDots();
		}
		function syncDots() {
			var c = current();
			Array.prototype.forEach.call( dotsBox.children, function ( d, i ) {
				d.classList.toggle( 'is-on', i === c );
			} );
			// 트랙 안에 완전히 보이는 카드만 강조
			var left = track.scrollLeft - 4;
			var right = track.scrollLeft + track.clientWidth + 4;
			slides.forEach( function ( s ) {
				s.classList.toggle( 'is-current', s.offsetLeft - track.offsetLeft >= left && s.offsetLeft - track.offsetLeft + s.offsetWidth <= right );
			} );
		}

		if ( nav ) {
			nav.querySelectorAll( '[data-dir]' ).forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					go( current() + parseInt( btn.getAttribute( 'data-dir' ), 10 ) );
					restart();
				} );
			} );
		}
		track.addEventListener( 'keydown', function ( e ) {
			if ( 'ArrowRight' === e.key ) { e.preventDefault(); go( current() + 1 ); }
			if ( 'ArrowLeft' === e.key ) { e.preventDefault(); go( current() - 1 ); }
		} );

		var scrollTick = null;
		track.addEventListener( 'scroll', function () {
			clearTimeout( scrollTick );
			scrollTick = setTimeout( syncDots, 80 );
		}, { passive: true } );

		function start() {
			if ( reduce || timer ) { return; }
			timer = setInterval( function () { go( current() + 1 ); }, 5000 );
		}
		function stop() {
			clearInterval( timer );
			timer = null;
		}
		function restart() {
			stop();
			start();
		}
		root.addEventListener( 'mouseenter', stop );
		root.addEventListener( 'mouseleave', start );
		root.addEventListener( 'focusin', stop );
		root.addEventListener( 'focusout', start );
		window.addEventListener( 'resize', renderDots );

		renderDots();
		start();
	} );
} )();
