// 썸네일을 누르면 그 자리에서 유튜브 플레이어로 바꾼다 (처음부터 iframe 을 띄우지 않아 메인이 가볍다).
( function () {
	document.addEventListener( 'click', function ( event ) {
		var button = event.target.closest( '[data-wooin-play]' );
		if ( ! button ) {
			return;
		}
		var id = button.getAttribute( 'data-wooin-play' );
		var frame = document.createElement( 'iframe' );
		frame.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent( id ) + '?autoplay=1&rel=0';
		frame.title = button.getAttribute( 'aria-label' ) || '유튜브 영상';
		frame.allow = 'accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture';
		frame.allowFullscreen = true;
		frame.className = 'wooin-yt-iframe';
		button.replaceWith( frame );
	} );
} )();
