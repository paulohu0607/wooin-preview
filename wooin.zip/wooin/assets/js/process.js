// 우인 프로세스: 스크롤에 따라 진행선이 채워지고, 화면 가운데를 지나는 단계가 활성화된다.
( function () {
	var section = document.querySelector( '.wooin-process' );
	if ( ! section || window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
		return;
	}
	section.classList.add( 'is-scroll' );

	var now = section.querySelector( '[data-step-now]' );
	var title = section.querySelector( '[data-step-title]' );
	var bar = section.querySelector( '.wooin-process-bar i' );
	var finalCta = section.querySelector( '[data-cta-final]' );
	var ticking = false;

	function update() {
		ticking = false;
		var list = section.querySelector( '.wooin-steps:not([hidden])' );
		if ( ! list ) { return; }
		var items = list.querySelectorAll( 'li' );
		var focus = window.innerHeight * 0.5;
		var rect = list.getBoundingClientRect();
		var progress = Math.min( Math.max( ( focus - rect.top ) / rect.height, 0 ), 1 );
		list.style.setProperty( '--p', progress.toFixed( 4 ) );

		var active = 0;
		items.forEach( function ( li, i ) {
			if ( li.getBoundingClientRect().top < focus ) { active = i; }
		} );
		items.forEach( function ( li, i ) {
			li.classList.toggle( 'is-done', i < active );
			li.classList.toggle( 'is-active', i === active );
		} );

		var step = items[ active ];
		if ( now ) { now.textContent = String( active + 1 ).padStart( 2, '0' ); }
		if ( title && step ) { title.textContent = step.querySelector( 'h3' ).textContent; }
		if ( bar ) { bar.style.width = ( ( active + 1 ) / items.length * 100 ) + '%'; }
		section.classList.toggle( 'is-final', active === items.length - 1 && progress > 0.85 );
		if ( finalCta ) {
			var track = list.getAttribute( 'data-track' ) || 'personal';
			finalCta.setAttribute( 'data-wooin-track', track );
			finalCta.setAttribute( 'href', '/contact/' + track + '/' );
		}
	}

	function request() {
		if ( ! ticking ) {
			ticking = true;
			requestAnimationFrame( update );
		}
	}
	window.addEventListener( 'scroll', request, { passive: true } );
	window.addEventListener( 'resize', request );
	section.querySelectorAll( '[role="tab"]' ).forEach( function ( tab ) {
		tab.addEventListener( 'click', function () { setTimeout( update, 0 ); } );
	} );
	update();
} )();
