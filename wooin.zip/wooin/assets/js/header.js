( function () {
	// 헤더: 스크롤하면 흰색으로
	var header = document.querySelector( '.wooin-header' );
	if ( header ) {
		var update = function () {
			header.classList.toggle( 'is-scrolled', window.scrollY > 40 );
		};
		update();
		window.addEventListener( 'scroll', update, { passive: true } );
	}

	// 스크롤 등장: 요소가 화면에 들어오면 흐릿함 → 선명하게 (같은 줄의 요소는 차례로)
	var reduce = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var SELECTOR = [
		'.wooin-track', '.wooin-section-head', '.wooin-en-title', '.wooin-lead', '.wooin-about p:not(.wooin-photo-tag)', '.wooin-more-links',
		'.wooin-about-photo', '.wooin-stat', '.wooin-why-card', '.wooin-tabs:not(.is-form) > .wooin-tab-list', '.wooin-case-table',
		'.wooin-lawyer-photo', '.wooin-lawyer .wp-block-column > *', '.wooin-point', '.wooin-yt-latest .wooin-yt-feature',
		'.wooin-yt-latest .wooin-yt-card', '.wooin-area', '.wooin-industry-line', '.wooin-carousel', '.wooin-col-head',
		'.wooin-insights .wooin-list > li', '.wooin-contact .wp-block-column > *', '.wooin-process-head > *', '.wooin-mock-note',
		'.wooin-sd-intro-grid > *', '.wooin-sd-checks li', '.wooin-sd-benefit-list li', '.wooin-sd-doc-list li', '.wooin-sd-two > *', '.wooin-cases',
		'.wooin-accordion', '.wooin-greeting > *', '.wooin-guide-steps li', '.wooin-prepare > div', '.wooin-location > *', '.wooin-case-fact', '.wooin-cta-band-inner > *',
	].join( ',' );

	function countUp( el ) {
		var raw = el.getAttribute( 'data-count' );
		var target = parseFloat( raw );
		var decimals = ( raw.split( '.' )[ 1 ] || '' ).length;
		var start = null;
		function step( t ) {
			if ( ! start ) { start = t; }
			var p = Math.min( ( t - start ) / 1400, 1 );
			var v = target * ( 1 - Math.pow( 1 - p, 3 ) );
			el.textContent = v.toLocaleString( 'ko-KR', { minimumFractionDigits: decimals, maximumFractionDigits: decimals } );
			if ( p < 1 ) { requestAnimationFrame( step ); }
		}
		requestAnimationFrame( step );
	}

	if ( reduce || ! ( 'IntersectionObserver' in window ) ) {
		return;
	}
	document.documentElement.classList.add( 'wooin-motion' );

	var found = Array.prototype.slice.call( document.querySelectorAll( SELECTOR ) );
	// 바깥 요소가 이미 대상이면 안쪽 요소는 제외 (이중 효과 방지)
	var items = found.filter( function ( el ) {
		if ( el.closest( '.wooin-hero' ) ) { return false; }
		for ( var p = el.parentElement; p; p = p.parentElement ) {
			if ( found.indexOf( p ) > -1 ) { return false; }
		}
		return true;
	} );

	// 같은 부모 안에서 순서대로 지연
	items.forEach( function ( el ) {
		var siblings = Array.prototype.filter.call( el.parentElement.children, function ( s ) { return items.indexOf( s ) > -1; } );
		var i = siblings.indexOf( el );
		el.style.setProperty( '--fx-delay', ( Math.min( i, 6 ) * 0.09 ) + 's' );
		el.classList.add( 'wooin-fx' );
	} );

	// 등장이 끝나면 효과 클래스를 지워 원래 hover 효과 등이 그대로 동작하게
	function settle( el ) {
		el.addEventListener( 'transitionend', function done( e ) {
			if ( e.target !== el || 'opacity' !== e.propertyName ) { return; }
			el.removeEventListener( 'transitionend', done );
			el.classList.remove( 'wooin-fx', 'is-in' );
			el.style.removeProperty( '--fx-delay' );
		} );
	}

	var io = new IntersectionObserver( function ( entries ) {
		entries.forEach( function ( entry ) {
			if ( ! entry.isIntersecting ) { return; }
			var el = entry.target;
			settle( el );
			el.classList.add( 'is-in' );
			el.querySelectorAll( '[data-count]' ).forEach( countUp );
			io.unobserve( el );
		} );
	}, { threshold: 0.15, rootMargin: '0px 0px -6% 0px' } );
	items.forEach( function ( el ) { io.observe( el ); } );
} )();
