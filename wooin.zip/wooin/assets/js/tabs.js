// 탭(사례·절차·상담폼)과 개인/법인 상담 구분.
( function () {
	var LABEL = { personal: '개인회생·파산', corporate: '법인회생·파산' };

	function select( tabs, tab ) {
		tabs.querySelectorAll( '[role="tab"]' ).forEach( function ( t ) {
			var on = t === tab;
			t.setAttribute( 'aria-selected', on ? 'true' : 'false' );
			t.tabIndex = on ? 0 : -1;
			var panel = document.getElementById( t.getAttribute( 'aria-controls' ) );
			if ( ! panel ) { return; }
			panel.hidden = ! on;
			// 숨긴 구분의 입력값은 검증·전송에서 빠지도록 비활성화
			panel.querySelectorAll( 'input, select, textarea' ).forEach( function ( f ) { f.disabled = ! on; } );
		} );

		var form = tabs.closest( '[data-wooin-consult]' );
		var track = tab.getAttribute( 'data-track' );
		if ( form && track ) {
			form.querySelector( 'input[name="track"]' ).value = track;
			form.querySelector( '[data-track-label]' ).textContent = LABEL[ track ];
			form.classList.toggle( 'is-corporate', 'corporate' === track );
			form.querySelector( '.wooin-form-status' ).textContent = '';
		}
	}

	function selectTrack( root, track ) {
		root.querySelectorAll( '[data-wooin-tabs]' ).forEach( function ( tabs ) {
			var tab = tabs.querySelector( '[role="tab"][data-track="' + track + '"]' );
			if ( tab ) { select( tabs, tab ); }
		} );
	}

	document.querySelectorAll( '[data-wooin-tabs]' ).forEach( function ( tabs ) {
		var list = tabs.querySelectorAll( '[role="tab"]' );
		list.forEach( function ( tab, i ) {
			tab.addEventListener( 'click', function () { select( tabs, tab ); } );
			tab.addEventListener( 'keydown', function ( e ) {
				var next = 'ArrowRight' === e.key ? i + 1 : 'ArrowLeft' === e.key ? i - 1 : null;
				if ( null === next ) { return; }
				var target = list[ ( next + list.length ) % list.length ];
				select( tabs, target );
				target.focus();
			} );
		} );
		var current = tabs.querySelector( '[role="tab"][aria-selected="true"]' ) || list[ 0 ];
		select( tabs, current );
	} );

	// 들어온 주소로 구분 미리 선택: /contact/corporate/, ?type=corporate (사례·FAQ·절차 탭 포함)
	var form = document.querySelector( '[data-wooin-consult]' );
	var m = location.pathname.match( /\/contact\/(personal|corporate)/ );
	var initial = m ? m[ 1 ] : new URLSearchParams( location.search ).get( 'type' );
	if ( 'personal' === initial || 'corporate' === initial ) {
		selectTrack( document, initial );
	}

	// 같은 페이지에 상담폼이 있으면 「개인/법인 상담 신청」 버튼은 폼으로 이동 + 구분 전환
	document.addEventListener( 'click', function ( e ) {
		var link = e.target.closest( '[data-wooin-track]' );
		if ( ! link || ! form ) { return; }
		e.preventDefault();
		selectTrack( form, link.getAttribute( 'data-wooin-track' ) );
		form.scrollIntoView( { behavior: 'smooth', block: 'center' } );
	} );

	// 시안: 실제 전송 대신 확인 안내
	if ( form ) {
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var status = form.querySelector( '.wooin-form-status' );
			if ( ! form.checkValidity() ) {
				var bad = form.querySelector( ':invalid' );
				status.textContent = '필수 항목을 확인해 주세요.';
				if ( bad ) { bad.focus(); }
				return;
			}
			status.textContent = '[시안] ' + LABEL[ form.querySelector( 'input[name="track"]' ).value ] + ' 상담으로 접수될 내용입니다. 실제 전송은 다음 단계에서 연결됩니다.';
		} );
	}
} )();
