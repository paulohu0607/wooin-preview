// 오시는 길 — 카카오맵. 키·주소는 패턴(page-location.php)의 data- 속성으로 받는다.
// 키가 없거나 불러오지 못하면 아무것도 하지 않는다 (주소 카드와 「카카오맵에서 보기 · 길찾기」 버튼이 그대로 보임).
( function () {
	var box = document.querySelector( '[data-wooin-map]' );
	if ( ! box || ! box.dataset.key || ! box.dataset.address ) {
		return;
	}
	var canvas = box.querySelector( '.wooin-map-canvas' );
	var name = box.dataset.name || '';

	function draw() {
		var geocoder = new window.kakao.maps.services.Geocoder();
		geocoder.addressSearch( box.dataset.address, function ( result, status ) {
			if ( status !== window.kakao.maps.services.Status.OK || ! result.length ) {
				box.classList.add( 'is-failed' );
				return;
			}
			var lat = result[ 0 ].y;
			var lng = result[ 0 ].x;
			var pos = new window.kakao.maps.LatLng( lat, lng );
			canvas.innerHTML = '';
			box.classList.add( 'is-ready' );
			var map = new window.kakao.maps.Map( canvas, { center: pos, level: 3 } );
			map.setZoomable( false ); // 페이지를 스크롤할 때 지도가 확대되지 않게 (확대·축소는 버튼으로)
			map.addControl( new window.kakao.maps.ZoomControl(), window.kakao.maps.ControlPosition.RIGHT );
			new window.kakao.maps.Marker( { map: map, position: pos } );
			var label = document.createElement( 'div' );
			label.className = 'wooin-map-label';
			label.textContent = name;
			new window.kakao.maps.CustomOverlay( { map: map, position: pos, content: label, yAnchor: 2.6 } );

			// 버튼을 정확한 위치로
			var place = encodeURIComponent( name ) + ',' + lat + ',' + lng;
			var view = box.querySelector( '[data-map-view]' );
			var route = box.querySelector( '[data-map-route]' );
			if ( view ) { view.href = 'https://map.kakao.com/link/map/' + place; }
			if ( route ) { route.href = 'https://map.kakao.com/link/to/' + place; }

			window.addEventListener( 'resize', function () {
				map.relayout();
				map.setCenter( pos );
			} );
		} );
	}

	var script = document.createElement( 'script' );
	script.src = 'https://dapi.kakao.com/v2/maps/sdk.js?autoload=false&libraries=services&appkey=' + encodeURIComponent( box.dataset.key );
	script.async = true;
	script.onload = function () {
		if ( window.kakao && window.kakao.maps ) {
			window.kakao.maps.load( draw );
		} else {
			box.classList.add( 'is-failed' );
		}
	};
	script.onerror = function () {
		box.classList.add( 'is-failed' );
	};
	document.head.appendChild( script );
} )();
