<?php
/**
 * Title: 메인 06 · 이서영 변호사 TV (유튜브 자동 연동)
 * Slug: wooin/home-videos
 * Categories: wooin
 * Inserter: no
 *
 * 영상은 관리자 「유튜브 영상」에서 「메인 캐러셀에 노출」 체크한 것(최대 5개, 순서 지정). 없으면 최신 영상.
 * 제목·설명은 관리자 「메인 화면 편집 › 섹션 제목 · 문구」({구독자} = 자동 갱신 구독자 수, 「유튜브 연동 설정」). 「구독하기」는 유튜브로 바로 보내지 않고 우리 영상 페이지(/videos/)로.
 */
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-videos wooin-reveal","backgroundColor":"base","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-videos wooin-reveal has-base-background-color has-background">
	<!-- wp:group {"className":"wooin-section-head is-row","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
	<div class="wp-block-group wooin-section-head is-row">
		<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->
		<div class="wp-block-group">
			<!-- wp:paragraph {"className":"wooin-yt-logo"} -->
			<p class="wooin-yt-logo"><span aria-hidden="true"></span><?php echo esc_html( wooin_hv( 'videos_label' ) ); ?></p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"className":"wooin-display"} -->
			<h2 class="wp-block-heading wooin-display"><?php echo wooin_hf( 'videos_title', 'em' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"muted"} -->
			<p class="has-muted-color has-text-color"><?php echo wooin_hf( 'videos_desc', 'strong' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
		<!-- wp:buttons -->
		<div class="wp-block-buttons">
			<!-- wp:button {"className":"is-style-outline wooin-pill","textColor":"navy"} -->
			<div class="wp-block-button is-style-outline wooin-pill"><a class="wp-block-button__link has-navy-color has-text-color wp-element-button" href="/videos/">영상 전체 보기 +</a></div>
			<!-- /wp:button -->
			<!-- wp:button {"className":"wooin-btn-youtube wooin-pill"} -->
			<div class="wp-block-button wooin-btn-youtube wooin-pill"><a class="wp-block-button__link wp-element-button" href="/videos/">▶ 구독하기</a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<div class="wooin-carousel-nav is-videos" data-carousel-nav="videos">
		<button type="button" class="wooin-carousel-btn" data-dir="-1" aria-label="이전 영상">←</button>
		<button type="button" class="wooin-carousel-btn" data-dir="1" aria-label="다음 영상">→</button>
	</div>
	<!-- /wp:html -->

	<!-- wp:wooin/video-picks /-->
</div>
<!-- /wp:group -->
