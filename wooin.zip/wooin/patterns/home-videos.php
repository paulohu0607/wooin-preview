<?php
/**
 * Title: 메인 06 · 이서영 변호사 TV (유튜브 자동 연동)
 * Slug: wooin/home-videos
 * Categories: wooin
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-videos wooin-reveal","backgroundColor":"base","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-videos wooin-reveal has-base-background-color has-background">
	<!-- wp:group {"className":"wooin-section-head is-row","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
	<div class="wp-block-group wooin-section-head is-row">
		<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->
		<div class="wp-block-group">
			<!-- wp:paragraph {"className":"wooin-yt-logo"} -->
			<p class="wooin-yt-logo"><span aria-hidden="true"></span>이서영변호사의 회생파산연구소</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"className":"wooin-display"} -->
			<h2 class="wp-block-heading wooin-display">구독자 <em>10.1만 명</em>이 찾아보는<br><strong>‘빚’ 전문 채널</strong></h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"muted"} -->
			<p class="has-muted-color has-text-color">개인회생부터 법인 도산까지, 어렵고 낯선 절차를 이서영 변호사가 영상으로 쉽게 설명합니다.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
		<!-- wp:buttons -->
		<div class="wp-block-buttons">
			<!-- wp:button {"className":"is-style-outline wooin-pill","textColor":"navy"} -->
			<div class="wp-block-button is-style-outline wooin-pill"><a class="wp-block-button__link has-navy-color has-text-color wp-element-button" href="/videos/">영상 전체 보기 +</a></div>
			<!-- /wp:button -->
			<!-- wp:button {"className":"wooin-btn-youtube wooin-pill","metadata":{"bindings":{"url":{"source":"wooin/site-info","args":{"key":"youtube_url"}}}}} -->
			<div class="wp-block-button wooin-btn-youtube wooin-pill"><a class="wp-block-button__link wp-element-button" href="/videos/" target="_blank" rel="noopener">▶ 구독하기</a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
	<!-- /wp:group -->

	<!-- wp:wooin/video-latest /-->
</div>
<!-- /wp:group -->
