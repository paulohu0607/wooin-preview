<?php
/**
 * Title: 서브 · 인사말
 * Slug: wooin/page-greeting
 * Categories: wooin
 * Inserter: no
 *
 * 인사말 원고는 wooin.net 의 이서영 변호사 인사말을 바탕으로 개인·법인 통합 방향에 맞게 다듬은 초안.
 */
?>
<!-- wp:html -->
<section class="wooin-sub-section">
	<div class="wooin-sd-wrap wooin-greeting">
		<div class="wooin-greeting-photo" aria-hidden="true"></div>
		<div class="wooin-greeting-text">
			<p class="wooin-eyebrow is-spaced">Greeting</p>
			<h2 class="wooin-display">빚에 대한 답,<br><em>이서영 변호사</em>에게 있습니다.</h2>
			<p class="wooin-lead">안녕하세요. 법률사무소 우인 대표 변호사 이서영입니다.</p>
			<p>10여 년 변호사의 길을 걸어오면서 저는 오직 도산 분야만 연구해 왔습니다. 의뢰인 한 분 한 분이 하루라도 빨리 빚에서 벗어나 새 삶을 다시 시작하는 것, 그 하나만을 목표로 이 일을 해 오고 있습니다.</p>
			<p>지난 10년간 4천 명이 넘는 의뢰인이 저와 함께 새 출발을 했습니다. 그 시간 동안 배운 것은, 위기는 빨리 마주할수록 선택지가 많아진다는 것입니다.</p>
			<p>이제 그 경험을 개인회생·개인파산을 넘어 법인회생·법인파산까지 넓혀, 빚 앞에 선 개인과 위기의 기업 곁에 함께 서겠습니다. 혼자 버티지 마시고, 지금 상황을 먼저 들려주세요.</p>
			<p class="wooin-greeting-sign">법률사무소 우인 대표 변호사 <strong>이서영</strong></p>
		</div>
	</div>
</section>
<!-- /wp:html -->

<!-- wp:pattern {"slug":"wooin/home-why"} /-->
