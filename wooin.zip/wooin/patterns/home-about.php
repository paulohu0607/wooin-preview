<?php
/**
 * Title: 메인 02 · About Wooin
 * Slug: wooin/home-about
 * Categories: wooin
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-reveal","backgroundColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-reveal has-white-background-color has-background">
	<!-- wp:columns {"verticalAlignment":"center","className":"wooin-about","style":{"spacing":{"blockGap":{"left":"clamp(2rem, 6vw, 6rem)"}}}} -->
	<div class="wp-block-columns are-vertically-aligned-center wooin-about">
		<!-- wp:column {"verticalAlignment":"center","width":"48%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:48%">
			<!-- wp:heading {"className":"wooin-en-title"} -->
			<h2 class="wp-block-heading wooin-en-title">About <span>Wooin</span></h2>
			<!-- /wp:heading -->

			<!-- wp:paragraph {"className":"wooin-lead"} -->
			<p class="wooin-lead">빚의 무게를 내려놓고 다시 시작하게 하는 일,<br><strong>우인이 가장 잘하는 일</strong>입니다.</p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph {"textColor":"muted"} -->
			<p class="has-muted-color has-text-color">회생과 파산은 신청서 한 장으로 끝나지 않습니다. 보정 명령, 채권자 이의, 변제계획과 회생계획안까지 한 단계라도 놓치면 새 출발이 늦어집니다.</p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph {"textColor":"muted"} -->
			<p class="has-muted-color has-text-color">법률사무소 우인은 10여 년간 도산 분야만 연구해 온 이서영 변호사를 중심으로, 개인 의뢰인은 일상에, 대표님은 사업에 집중하는 동안 절차의 모든 순간을 관리합니다.</p>
			<!-- /wp:paragraph -->

			<!-- wp:buttons {"className":"wooin-more-links"} -->
			<div class="wp-block-buttons wooin-more-links">
				<!-- wp:button {"className":"is-style-outline wooin-pill","textColor":"navy"} -->
				<div class="wp-block-button is-style-outline wooin-pill"><a class="wp-block-button__link has-navy-color has-text-color wp-element-button" href="/cases/">해결 사례 더보기 +</a></div>
				<!-- /wp:button -->
				<!-- wp:button {"className":"is-style-outline wooin-pill","textColor":"navy"} -->
				<div class="wp-block-button is-style-outline wooin-pill"><a class="wp-block-button__link has-navy-color has-text-color wp-element-button" href="/people/lee-seoyoung/">변호사 소개 +</a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:group {"className":"wooin-about-photo","layout":{"type":"default"}} -->
			<div class="wp-block-group wooin-about-photo">
				<!-- wp:paragraph {"className":"wooin-photo-tag"} -->
				<p class="wooin-photo-tag">시안용 샘플 사진 · 우인 사무실 사진으로 교체</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:group {"className":"wooin-stats","layout":{"type":"grid","columnCount":4,"minimumColumnWidth":"10rem"}} -->
	<div class="wp-block-group wooin-stats">
		<!-- wp:group {"className":"wooin-stat","layout":{"type":"flex","orientation":"vertical"}} -->
		<div class="wp-block-group wooin-stat"><!-- wp:paragraph {"className":"wooin-stat-num"} --><p class="wooin-stat-num"><span data-count="9">9</span><small>년</small></p><!-- /wp:paragraph --><!-- wp:paragraph {"className":"wooin-stat-label"} --><p class="wooin-stat-label">오직 도산 분야만 연구</p><!-- /wp:paragraph --></div>
		<!-- /wp:group -->
		<!-- wp:group {"className":"wooin-stat","layout":{"type":"flex","orientation":"vertical"}} -->
		<div class="wp-block-group wooin-stat"><!-- wp:paragraph {"className":"wooin-stat-num"} --><p class="wooin-stat-num"><span data-count="4000">4,000</span><small>건+</small></p><!-- /wp:paragraph --><!-- wp:paragraph {"className":"wooin-stat-label"} --><p class="wooin-stat-label">회생·파산 성공사례</p><!-- /wp:paragraph --></div>
		<!-- /wp:group -->
		<!-- wp:group {"className":"wooin-stat","layout":{"type":"flex","orientation":"vertical"}} -->
		<div class="wp-block-group wooin-stat"><!-- wp:paragraph {"className":"wooin-stat-num"} --><p class="wooin-stat-num"><span data-count="2">2</span><small>주</small></p><!-- /wp:paragraph --><!-- wp:paragraph {"className":"wooin-stat-label"} --><p class="wooin-stat-label">서류 수령 후 법원 접수</p><!-- /wp:paragraph --></div>
		<!-- /wp:group -->
		<!-- wp:group {"className":"wooin-stat","layout":{"type":"flex","orientation":"vertical"}} -->
		<div class="wp-block-group wooin-stat"><!-- wp:paragraph {"className":"wooin-stat-num"} --><p class="wooin-stat-num"><span data-count="10.1">10.1</span><small>만</small></p><!-- /wp:paragraph --><!-- wp:paragraph {"className":"wooin-stat-label"} --><p class="wooin-stat-label">유튜브 구독자</p><!-- /wp:paragraph --></div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
