<?php
/**
 * Title: 메인 02 · About Wooin
 * Slug: wooin/home-about
 * Categories: wooin
 * Inserter: no
 *
 * 문구·사진·숫자는 관리자 「메인 화면 편집 › 우인 소개 · 숫자」.
 */
$wooin_photo = wooin_hm( 'about_photo', 'large' );
$wooin_stats = array();
for ( $n = 1; $n <= 4; $n++ ) {
	if ( '' !== wooin_hv( "stat{$n}_num" ) ) {
		$wooin_stats[] = array( wooin_hv( "stat{$n}_num" ), wooin_hv( "stat{$n}_unit" ), wooin_hv( "stat{$n}_label" ) );
	}
}
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-reveal","backgroundColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-reveal has-white-background-color has-background">
	<!-- wp:columns {"verticalAlignment":"center","className":"wooin-about","style":{"spacing":{"blockGap":{"left":"clamp(2rem, 6vw, 6rem)"}}}} -->
	<div class="wp-block-columns are-vertically-aligned-center wooin-about">
		<!-- wp:column {"verticalAlignment":"center","width":"48%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:48%">
			<!-- wp:heading {"className":"wooin-en-title"} -->
			<h2 class="wp-block-heading wooin-en-title">About <span>Wooin</span></h2>
			<!-- /wp:heading -->

			<!-- wp:paragraph {"className":"wooin-lead"} -->
			<p class="wooin-lead"><?php echo wooin_hf( 'about_lead', 'strong' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></p>
			<!-- /wp:paragraph -->

			<?php foreach ( array( 'about_body1', 'about_body2' ) as $wooin_key ) : ?>
				<?php if ( '' !== wooin_hv( $wooin_key ) ) : ?>
			<!-- wp:paragraph {"textColor":"muted"} -->
			<p class="has-muted-color has-text-color"><?php echo wooin_hf( $wooin_key, 'strong' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></p>
			<!-- /wp:paragraph -->
				<?php endif; ?>
			<?php endforeach; ?>

			<!-- wp:buttons {"className":"wooin-more-links"} -->
			<div class="wp-block-buttons wooin-more-links">
				<!-- wp:button {"className":"is-style-outline wooin-pill","textColor":"navy"} -->
				<div class="wp-block-button is-style-outline wooin-pill"><a class="wp-block-button__link has-navy-color has-text-color wp-element-button" href="/cases/">해결 사례 더보기 +</a></div>
				<!-- /wp:button -->
				<!-- wp:button {"className":"is-style-outline wooin-pill","textColor":"navy"} -->
				<div class="wp-block-button is-style-outline wooin-pill"><a class="wp-block-button__link has-navy-color has-text-color wp-element-button" href="/people/lee-seoyoung/">변호사 소개 +</a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:group {"className":"wooin-about-photo","layout":{"type":"default"}} -->
			<div class="wp-block-group wooin-about-photo"<?php echo $wooin_photo ? ' style="--wooin-about-img:url(' . esc_url( $wooin_photo ) . ')"' : ''; ?>>
				<?php if ( ! $wooin_photo && current_user_can( 'wooin_edit_home' ) ) : // 안내는 편집 권한자에게만 (방문자에게는 사진만) ?>
				<!-- wp:paragraph {"className":"wooin-photo-tag"} -->
				<p class="wooin-photo-tag">기본 사진 · 관리자 「메인 화면 편집 › 우인 소개」에서 사무실 사진으로 교체</p>
				<!-- /wp:paragraph -->
				<?php endif; ?>
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<?php if ( $wooin_stats ) : ?>
	<!-- wp:group {"className":"wooin-stats","layout":{"type":"grid","columnCount":4,"minimumColumnWidth":"10rem"}} -->
	<div class="wp-block-group wooin-stats">
		<?php foreach ( $wooin_stats as $wooin_s ) : ?>
		<?php $wooin_num = str_replace( ',', '', $wooin_s[0] ); ?>
		<!-- wp:group {"className":"wooin-stat","layout":{"type":"flex","orientation":"vertical"}} -->
		<div class="wp-block-group wooin-stat"><!-- wp:paragraph {"className":"wooin-stat-num"} --><p class="wooin-stat-num"><?php if ( is_numeric( $wooin_num ) ) : ?><span data-count="<?php echo esc_attr( $wooin_num ); ?>"><?php echo esc_html( $wooin_s[0] ); ?></span><?php else : ?><span><?php echo esc_html( $wooin_s[0] ); ?></span><?php endif; ?><small><?php echo esc_html( $wooin_s[1] ); ?></small></p><!-- /wp:paragraph --><!-- wp:paragraph {"className":"wooin-stat-label"} --><p class="wooin-stat-label"><?php echo esc_html( $wooin_s[2] ); ?></p><!-- /wp:paragraph --></div>
		<!-- /wp:group -->
		<?php endforeach; ?>
	</div>
	<!-- /wp:group -->
	<?php endif; ?>
</div>
<!-- /wp:group -->
