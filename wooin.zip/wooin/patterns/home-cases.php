<?php
/**
 * Title: 메인 04 · 해결 사례 (온강 표 형식, 개인/법인 탭)
 * Slug: wooin/home-cases
 * Categories: wooin
 * Inserter: no
 *
 * 표는 wooin-core 의 wooin/case-table 블록이 wooin_case 데이터로 그린다 (개인: wooin.net 공개 성공사례 5건).
 */
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-reveal","backgroundColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-reveal has-white-background-color has-background">
	<!-- wp:group {"className":"wooin-section-head is-center","layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
	<div class="wp-block-group wooin-section-head is-center">
		<!-- wp:paragraph {"className":"wooin-eyebrow is-spaced"} -->
		<p class="wooin-eyebrow is-spaced">Solved Cases</p>
		<!-- /wp:paragraph -->
		<!-- wp:heading {"textAlign":"center","className":"wooin-display"} -->
		<h2 class="wp-block-heading has-text-align-center wooin-display">말이 아닌 <strong>결과</strong>로 증명합니다</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph {"align":"center","textColor":"muted"} -->
		<p class="has-text-align-center has-muted-color has-text-color">얼마의 부채가, 어떻게 정리되었는지. 우인이 함께한 결과를 그대로 공개합니다.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:wooin/case-table {"track":"both","limit":5} /-->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"2.5rem"}}}} -->
	<div class="wp-block-buttons" style="margin-top:2.5rem">
		<!-- wp:button {"className":"is-style-outline wooin-pill","textColor":"navy"} -->
		<div class="wp-block-button is-style-outline wooin-pill"><a class="wp-block-button__link has-navy-color has-text-color wp-element-button" href="/cases/">해결 사례 전체 보기 +</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
