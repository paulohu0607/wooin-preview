<?php
/**
 * Title: 서브 · 상담 절차 안내
 * Slug: wooin/page-guide
 * Categories: wooin
 * Inserter: no
 *
 * 무료 상담·대표 직접 상담 등은 운영 확인 전 쓰지 않는다. 회신 번호·운영시간은 공통정보에서 읽는다.
 */
$info = static fn( string $k ): string => function_exists( 'wooin_core_site_info' ) ? wooin_core_site_info( $k ) : '';
$tail = $info( 'callback_tail' );
$steps = array(
	array( '상담 신청', '홈페이지 상담 신청서(개인/법인) 또는 전화로 신청합니다. 지금 상황을 한 줄만 적어주셔도 괜찮습니다.' ),
	array( '담당자 연락', $tail ? '담당자가 끝자리 ' . $tail . ' 번호로 연락드립니다. 모르는 번호라도 꼭 받아주세요.' : '담당자가 남겨주신 연락처로 연락드립니다.' ),
	array( '상담 · 진단', '소득·재산·채무(법인은 재무 상황)를 확인하고, 회생과 파산 중 맞는 절차와 예상 결과를 안내합니다.' ),
	array( '진행 결정', '충분히 설명을 들으신 뒤 진행 여부를 결정하시면 됩니다. 계약을 서두르지 않습니다.' ),
);
?>
<!-- wp:html -->
<section class="wooin-sub-section">
	<div class="wooin-sd-wrap">
		<div class="wooin-section-head is-center"><p class="wooin-eyebrow is-spaced">How it works</p><h2 class="wooin-display">상담은 이렇게 <strong>진행됩니다</strong></h2></div>
		<ol class="wooin-guide-steps">
			<?php foreach ( $steps as $i => $s ) : ?>
			<li><span><?php echo esc_html( sprintf( 'STEP %02d', $i + 1 ) ); ?></span><h3><?php echo esc_html( $s[0] ); ?></h3><p><?php echo esc_html( $s[1] ); ?></p></li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>

<section class="wooin-sub-section is-tinted">
	<div class="wooin-sd-wrap wooin-sd-two">
		<div>
			<p class="wooin-eyebrow is-spaced">Prepare</p>
			<h2 class="wooin-display">상담 전에 <strong>알아두시면 좋은 것</strong></h2>
			<p class="wooin-sd-body">정확한 자료가 없어도 상담은 가능합니다. 아래 내용을 대략이라도 알고 계시면 더 정확하게 안내해 드릴 수 있습니다.</p>
		</div>
		<div class="wooin-prepare">
			<div><h3>법인회생 · 파산</h3><ul><li>최근 재무제표와 부채 규모</li><li>압류·체납 등 현재 상황</li><li>주요 채권자와 거래처 현황</li><li>대표이사 연대보증 여부</li></ul><a class="wooin-track-cta" href="/contact/corporate/">법인 상담 신청<span class="wooin-arrow" aria-hidden="true"></span></a></div>
			<div><h3>개인회생 · 파산</h3><ul><li>월 평균 실수령액과 소득 형태</li><li>카드·대출·사채를 포함한 총 채무</li><li>부동산·자동차·보증금 등 재산</li><li>부양 가족 수</li></ul><a class="wooin-track-cta is-dark" href="/contact/personal/">개인 상담 신청<span class="wooin-arrow" aria-hidden="true"></span></a></div>
		</div>
	</div>
</section>

<section class="wooin-sub-section">
	<div class="wooin-sd-wrap">
		<dl class="wooin-sd-facts is-row">
			<div><dt>상담 전화</dt><dd><a href="<?php echo esc_url( $info( 'phone_href' ) ); ?>"><?php echo esc_html( $info( 'phone_display' ) ); ?></a></dd></div>
			<div><dt>상담 시간</dt><dd><?php echo esc_html( $info( 'hours' ) ); ?></dd></div>
			<div><dt>방문 상담</dt><dd>예약 후 진행 · <a href="/location/">오시는 길</a></dd></div>
		</dl>
	</div>
</section>
<!-- /wp:html -->
