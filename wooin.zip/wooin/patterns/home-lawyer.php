<?php
/**
 * Title: 메인 05 · 구성원 (이서영 변호사 · 서동기 회계사 · 박만용 세무사 좌우 캐러셀)
 * Slug: wooin/home-lawyer
 * Categories: wooin
 * Inserter: no
 *
 * 원고·사진은 inc/people.php 한 곳에서 관리 (상세 페이지와 공유). 동작: assets/js/carousel.js.
 */
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-lawyer wooin-reveal","backgroundColor":"navy","textColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-lawyer wooin-reveal has-white-color has-navy-background-color has-text-color has-background">
	<!-- wp:html -->
	<?php echo wooin_people_carousel(); // phpcs:ignore WordPress.Security.EscapeOutput -- 함수 안에서 이스케이프 ?>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
