<?php
/**
 * Title: 메인 01-1 · 개인 / 법인 길 나누기
 * Slug: wooin/home-tracks
 * Categories: wooin
 * Inserter: no
 *
 * 히어로 바로 아래에서 방문자가 자신의 상황(개인·법인)을 고르게 한다. 상담 신청도 이 구분으로 접수된다.
 */
$tracks = array(
	array(
		'corporate',
		'For Companies',
		'법인회생 · 법인파산',
		'멈춘 회사의<br><strong>재기</strong>',
		'압류·체납·만기 거절 앞에서. 회사를 살리거나, 책임 있게 정리하는 길을 설계합니다.',
		array( '회생 가능성 진단', '보전처분·금지명령', '인가 후 정상화까지' ),
		'/services/corporate-rehabilitation/',
		'/contact/corporate/',
		'법인 상담 신청',
	),
	array(
		'personal',
		'For Individuals',
		'개인회생 · 개인파산',
		'채무를 정리하고<br><strong>다시 본업으로</strong>',
		'개인사업자·전문직·직장인. 감당하기 어려운 채무를 법이 정한 절차로 줄이거나 정리합니다.',
		array( '월 변제금 · 탕감률 진단', '추심·독촉 중단', '면책까지 관리' ),
		'/services/personal-rehabilitation/',
		'/contact/personal/',
		'개인 상담 신청',
	),
);
?>
<!-- wp:group {"align":"full","className":"wooin-tracks-wrap","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-tracks-wrap">
	<!-- wp:html -->
	<div class="wooin-tracks">
		<?php foreach ( $tracks as $t ) : ?>
		<section class="wooin-track is-<?php echo esc_attr( $t[0] ); ?>">
			<p class="wooin-track-en"><?php echo esc_html( $t[1] ); ?></p>
			<p class="wooin-track-label"><?php echo esc_html( $t[2] ); ?></p>
			<h2 class="wooin-track-title"><?php echo wp_kses( $t[3], array( 'br' => array(), 'strong' => array() ) ); ?></h2>
			<p class="wooin-track-desc"><?php echo esc_html( $t[4] ); ?></p>
			<ul class="wooin-track-points">
				<?php foreach ( $t[5] as $point ) : ?><li><?php echo esc_html( $point ); ?></li><?php endforeach; ?>
			</ul>
			<div class="wooin-track-actions">
				<a class="wooin-track-cta" href="<?php echo esc_url( $t[7] ); ?>" data-wooin-track="<?php echo esc_attr( $t[0] ); ?>"><?php echo esc_html( $t[8] ); ?><span class="wooin-arrow" aria-hidden="true"></span></a>
				<a class="wooin-track-more" href="<?php echo esc_url( $t[6] ); ?>">자세히 보기 +</a>
			</div>
		</section>
		<?php endforeach; ?>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
