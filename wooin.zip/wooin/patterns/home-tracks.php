<?php
/**
 * Title: 메인 01-1 · 개인 / 법인 길 나누기
 * Slug: wooin/home-tracks
 * Categories: wooin
 * Inserter: no
 *
 * 히어로 바로 아래에서 방문자가 자신의 상황(개인·법인)을 고르게 한다. 상담 신청도 이 구분으로 접수된다.
 */
// 문구는 관리자 「메인 화면 편집 › 법인 / 개인 갈림길」 (wooin-core home-fields.php 에 기본 문구).
$tracks = array();
foreach ( array( 'corp' => 'corporate', 'pers' => 'personal' ) as $k => $track ) {
	$tracks[] = array(
		$track,
		wooin_hv( "track_{$k}_en" ),
		wooin_hv( "track_{$k}_label" ),
		wooin_hf( "track_{$k}_title", 'strong' ),
		wooin_hv( "track_{$k}_desc" ),
		wooin_hl( "track_{$k}_points" ),
		wooin_hu( "track_{$k}_more_url" ),
		wooin_hu( "track_{$k}_cta_url" ),
		wooin_hv( "track_{$k}_cta_label" ),
	);
}
?>
<!-- wp:group {"align":"full","className":"wooin-tracks-wrap","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-tracks-wrap">
	<!-- wp:html -->
	<div class="wooin-tracks">
		<?php foreach ( $tracks as $t ) : ?>
		<section class="wooin-track is-<?php echo esc_attr( $t[0] ); ?>">
			<p class="wooin-track-en"><?php echo esc_html( $t[1] ); ?></p>
			<p class="wooin-track-label"><?php echo esc_html( $t[2] ); ?></p>
			<h2 class="wooin-track-title"><?php echo wp_kses( $t[3], array( 'br' => array(), 'strong' => array() ) ); ?></h2>
			<p class="wooin-track-desc"><?php echo esc_html( $t[4] ); ?></p>
			<ul class="wooin-track-points">
				<?php foreach ( $t[5] as $point ) : ?><li><?php echo esc_html( $point ); ?></li><?php endforeach; ?>
			</ul>
			<div class="wooin-track-actions">
				<a class="wooin-track-cta" href="<?php echo esc_url( $t[7] ); ?>" data-wooin-track="<?php echo esc_attr( $t[0] ); ?>"><?php echo esc_html( $t[8] ); ?><span class="wooin-arrow" aria-hidden="true"></span></a>
				<a class="wooin-track-more" href="<?php echo esc_url( $t[6] ); ?>">자세히 보기 +</a>
			</div>
		</section>
		<?php endforeach; ?>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
