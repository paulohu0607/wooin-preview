<?php
/**
 * Title: 업무분야 상세 · corporate-rehabilitation
 * Slug: wooin/service-corporate-rehabilitation
 * Categories: wooin
 * Inserter: no
 *
 * 원고·구성: inc/service-detail.php
 */
echo wooin_service_detail( 'corporate-rehabilitation' ); // phpcs:ignore WordPress.Security.EscapeOutput -- 함수 안에서 이스케이프
