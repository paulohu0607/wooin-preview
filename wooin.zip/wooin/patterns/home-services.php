<?php
/**
 * Title: 메인 08 · 업무분야 (온강식 세로 이미지 컬럼, 마우스를 올리면 넓어짐)
 * Slug: wooin/home-services
 * Categories: wooin
 * Inserter: no
 *
 * 배경 사진은 시안용 샘플(CSS .wooin-area.is-1~4). 분야별 촬영·선정 이미지로 교체.
 */
$areas = array(
	array( '개인회생', 'Personal Rehabilitation', '갚을 수 있는 만큼만, 다시 시작', '소득이 있다면 빚의 상당 부분을 줄이고, 3~5년 변제 후 남은 빚을 면책받을 수 있습니다.', '/services/personal-rehabilitation/' ),
	array( '개인파산', 'Personal Bankruptcy', '더는 갚을 수 없을 때의 선택', '소득과 재산으로 빚을 감당할 수 없다면, 파산·면책으로 빚의 굴레를 끊습니다.', '/services/personal-bankruptcy/' ),
	array( '법인회생', 'Corporate Rehabilitation', '다시 일어설 회사를 위한 선택', '계속기업가치를 입증하고 회생계획안부터 인가결정까지, 회사가 살아남을 길을 설계합니다.', '/services/corporate-rehabilitation/' ),
	array( '법인파산', 'Corporate Bankruptcy', '책임 있게 정리하고, 다음을 준비합니다', '회생이 어려운 경우, 법인과 대표님 개인의 부담을 최소화하는 정리 방안을 찾습니다.', '/services/corporate-bankruptcy/' ),
);
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-services wooin-reveal","backgroundColor":"navy","textColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-services wooin-reveal has-white-color has-navy-background-color has-text-color has-background">
	<!-- wp:group {"className":"wooin-section-head is-center","layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
	<div class="wp-block-group wooin-section-head is-center">
		<!-- wp:paragraph {"className":"wooin-eyebrow is-light is-spaced"} -->
		<p class="wooin-eyebrow is-light is-spaced">Practice Areas</p>
		<!-- /wp:paragraph -->
		<!-- wp:heading {"textAlign":"center","className":"wooin-display","textColor":"white"} -->
		<h2 class="wp-block-heading has-text-align-center wooin-display has-white-color has-text-color">개인부터 법인까지, <em>도산 한 분야</em>에만 집중합니다</h2>
		<!-- /wp:heading -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<div class="wooin-areas alignwide">
		<?php foreach ( $areas as $i => $area ) : ?>
		<a class="wooin-area is-<?php echo (int) $i + 1; ?>" href="<?php echo esc_url( $area[4] ); ?>">
			<span class="wooin-area-no"><?php echo esc_html( sprintf( '%02d', $i + 1 ) ); ?></span>
			<span class="wooin-area-body">
				<strong><?php echo esc_html( $area[0] ); ?></strong>
				<small><?php echo esc_html( $area[1] ); ?></small>
				<em><?php echo esc_html( $area[2] ); ?></em>
				<span class="wooin-area-desc"><?php echo esc_html( $area[3] ); ?></span>
				<span class="wooin-area-more">자세히 보기 ↗</span>
			</span>
		</a>
		<?php endforeach; ?>
	</div>
	<!-- /wp:html -->

	<!-- wp:paragraph {"align":"center","className":"wooin-industry-line"} -->
	<p class="has-text-align-center wooin-industry-line"><a href="/procedure/">회생·파산 절차 안내 →</a>　·　<a href="/support/">절차 비용 지원 사업 안내 →</a></p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
