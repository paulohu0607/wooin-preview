<?php
/**
 * Title: 메인 08 · 업무분야 (온강식 세로 이미지 컬럼, 마우스를 올리면 넓어짐)
 * Slug: wooin/home-services
 * Categories: wooin
 * Inserter: no
 *
 * 배경 사진은 시안용 샘플(CSS .wooin-area.is-c-rehab 등 분야별). 분야별 촬영·선정 이미지로 교체.
 */
// 한 줄·설명은 관리자 「메인 화면 편집 › 섹션 제목 · 문구 › 업무분야」
$areas = array(
	array( '법인회생', 'Corporate Rehabilitation', wooin_hv( 'svc1_tagline' ), wooin_hv( 'svc1_desc' ), '/services/corporate-rehabilitation/', 'c-rehab' ),
	array( '법인파산', 'Corporate Bankruptcy', wooin_hv( 'svc2_tagline' ), wooin_hv( 'svc2_desc' ), '/services/corporate-bankruptcy/', 'c-bank' ),
	array( '개인회생', 'Personal Rehabilitation', wooin_hv( 'svc3_tagline' ), wooin_hv( 'svc3_desc' ), '/services/personal-rehabilitation/', 'p-rehab' ),
	array( '개인파산', 'Personal Bankruptcy', wooin_hv( 'svc4_tagline' ), wooin_hv( 'svc4_desc' ), '/services/personal-bankruptcy/', 'p-bank' ),
);
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-services wooin-reveal","backgroundColor":"navy","textColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-services wooin-reveal has-white-color has-navy-background-color has-text-color has-background">
	<!-- wp:group {"className":"wooin-section-head is-center","layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
	<div class="wp-block-group wooin-section-head is-center">
		<!-- wp:paragraph {"className":"wooin-eyebrow is-light is-spaced"} -->
		<p class="wooin-eyebrow is-light is-spaced"><?php echo esc_html( wooin_hv( 'services_eyebrow' ) ); ?></p>
		<!-- /wp:paragraph -->
		<!-- wp:heading {"textAlign":"center","className":"wooin-display","textColor":"white"} -->
		<h2 class="wp-block-heading has-text-align-center wooin-display has-white-color has-text-color"><?php echo wooin_hf( 'services_title', 'em' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></h2>
		<!-- /wp:heading -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<div class="wooin-areas alignwide">
		<?php foreach ( $areas as $i => $area ) : ?>
		<a class="wooin-area is-<?php echo esc_attr( $area[5] ); ?>" href="<?php echo esc_url( $area[4] ); ?>">
			<span class="wooin-area-no"><?php echo esc_html( sprintf( '%02d', $i + 1 ) ); ?></span>
			<span class="wooin-area-body">
				<strong><?php echo esc_html( $area[0] ); ?></strong>
				<small><?php echo esc_html( $area[1] ); ?></small>
				<em><?php echo esc_html( $area[2] ); ?></em>
				<span class="wooin-area-desc"><?php echo esc_html( $area[3] ); ?></span>
				<span class="wooin-area-more">자세히 보기<span class="wooin-arrow" aria-hidden="true"></span></span>
			</span>
		</a>
		<?php endforeach; ?>
	</div>
	<!-- /wp:html -->

	<!-- wp:paragraph {"align":"center","className":"wooin-industry-line"} -->
	<p class="has-text-align-center wooin-industry-line"><a href="/procedure/">회생·파산 절차 안내 →</a>　·　<a href="/support/">절차 비용 지원 사업 안내 →</a></p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
