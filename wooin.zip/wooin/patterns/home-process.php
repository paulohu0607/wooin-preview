<?php
/**
 * Title: 메인 07 · 진행 절차 (개인회생 / 법인회생 탭, 번호 타임라인)
 * Slug: wooin/home-process
 * Categories: wooin
 * Inserter: no
 *
 * 절차 명칭은 채무자회생법상 일반 절차. 「2주 안에 접수」는 wooin.net 표기.
 */
// 단계 이름·설명은 관리자 「메인 화면 편집 › 진행 절차」. 이름을 비운 단계는 숨긴다.
$flows = array();
foreach ( array( 'corporate' => array( 'corp', '법인회생' ), 'personal' => array( 'pers', '개인회생' ) ) as $track => $def ) {
	$steps = array();
	for ( $n = 1; $n <= 6; $n++ ) {
		if ( '' !== wooin_hv( "process_{$def[0]}{$n}_title" ) ) {
			$steps[] = array( wooin_hv( "process_{$def[0]}{$n}_title" ), wooin_hv( "process_{$def[0]}{$n}_text" ) );
		}
	}
	if ( $steps ) {
		$flows[ $track ] = array( $def[1], $steps );
	}
}
$wooin_first_steps = $flows ? reset( $flows )[1] : array();
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-process wooin-reveal","backgroundColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-process wooin-reveal has-white-background-color has-background">
	<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"clamp(2rem, 6vw, 6rem)"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column {"width":"38%","className":"wooin-process-head"} -->
		<div class="wp-block-column wooin-process-head" style="flex-basis:38%">
			<!-- wp:heading {"className":"wooin-en-title"} -->
			<h2 class="wp-block-heading wooin-en-title"><span>W</span>ooin <span>P</span>rocess</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"className":"wooin-lead"} -->
			<p class="wooin-lead"><?php echo wooin_hf( 'process_lead', 'strong' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"textColor":"muted"} -->
			<p class="has-muted-color has-text-color"><?php echo wooin_hf( 'process_desc', 'strong' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></p>
			<!-- /wp:paragraph -->
			<!-- wp:html -->
			<div class="wooin-process-now" aria-hidden="true">
				<p class="wooin-process-count"><span data-step-now>01</span><small>/ <?php echo esc_html( sprintf( '%02d', count( $wooin_first_steps ) ) ); ?></small></p>
				<p class="wooin-process-title" data-step-title><?php echo esc_html( $wooin_first_steps[0][0] ?? '' ); ?></p>
				<div class="wooin-process-bar"><i></i></div>
			</div>
			<p class="wooin-process-cta">
				<a class="wooin-pill-link" href="/procedure/" data-cta-default>절차 자세히 보기 +</a>
				<a class="wooin-pill-link is-solid" href="/contact/corporate/" data-cta-final data-wooin-track="corporate">상담 신청하기<span class="wooin-arrow" aria-hidden="true"></span></a>
			</p>
			<!-- /wp:html -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="wooin-tabs" data-wooin-tabs>
				<div class="wooin-tab-list" role="tablist" aria-label="절차 구분">
					<?php $first = true; foreach ( $flows as $key => $flow ) : ?>
					<button type="button" role="tab" id="flow-tab-<?php echo esc_attr( $key ); ?>" aria-controls="flow-<?php echo esc_attr( $key ); ?>" aria-selected="<?php echo $first ? 'true' : 'false'; ?>" data-track="<?php echo esc_attr( $key ); ?>"<?php echo $first ? '' : ' tabindex="-1"'; ?>><?php echo esc_html( $flow[0] ); ?> 절차</button>
					<?php $first = false; endforeach; ?>
				</div>
				<?php $first = true; foreach ( $flows as $key => $flow ) : ?>
				<ol class="wooin-steps" data-track="<?php echo esc_attr( $key ); ?>" role="tabpanel" id="flow-<?php echo esc_attr( $key ); ?>" aria-labelledby="flow-tab-<?php echo esc_attr( $key ); ?>"<?php echo $first ? '' : ' hidden'; ?>>
					<?php foreach ( $flow[1] as $i => $step ) : ?>
					<li><span class="wooin-step-no"><?php echo esc_html( sprintf( '%02d', $i + 1 ) ); ?></span><div><h3><?php echo esc_html( $step[0] ); ?></h3><p><?php echo esc_html( $step[1] ); ?></p></div></li>
					<?php endforeach; ?>
				</ol>
				<?php $first = false; endforeach; ?>
			</div>
			<!-- /wp:html -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
