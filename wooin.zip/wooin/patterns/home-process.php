<?php
/**
 * Title: 메인 07 · 진행 절차 (개인회생 / 법인회생 탭, 번호 타임라인)
 * Slug: wooin/home-process
 * Categories: wooin
 * Inserter: no
 *
 * 절차 명칭은 채무자회생법상 일반 절차. 「2주 안에 접수」는 wooin.net 표기.
 */
$flows = array(
	'corporate' => array(
		'법인회생',
		array(
			array( '상담 · 진단', '재무 상황과 채무 구조를 확인하고, 회생과 파산 중 회사에 맞는 길을 함께 판단합니다.' ),
			array( '신청서 작성 · 접수', '필요 서류를 받은 날부터 2주 안에 회생법원에 신청서를 접수합니다.' ),
			array( '보전처분 · 포괄적 금지명령', '강제집행과 가압류, 채권자의 추심을 멈추고 회사의 숨 쉴 틈을 확보합니다.' ),
			array( '개시결정', '법원이 회생절차 개시를 결정하면, 조사위원의 조사에 함께 대응합니다.' ),
			array( '회생계획안 · 관계인집회', '변제 계획을 설계하고, 채권자를 설득해 동의를 이끌어냅니다.' ),
			array( '인가결정 · 정상화', '인가 이후에도 계획이 차질 없이 수행되도록 끝까지 관리합니다.' ),
		),
	),
	'personal'  => array(
		'개인회생',
		array(
			array( '상담 · 자격 진단', '소득과 재산, 채무를 확인해 개인회생과 개인파산 중 맞는 절차와 예상 변제금을 안내합니다.' ),
			array( '서류 준비 · 신청', '필요 서류를 받은 날부터 2주 안에 법원에 신청서를 접수합니다.' ),
			array( '금지·중지명령', '급여 압류와 채권자의 추심·독촉을 멈추도록 신청합니다.' ),
			array( '개시결정', '보정 명령에 빠르게 대응해 개시결정을 이끌어냅니다.' ),
			array( '변제계획 인가', '채권자 집회를 거쳐 변제계획 인가를 받습니다.' ),
			array( '변제 수행 · 면책', '변제 기간 동안 함께 관리하고, 면책결정으로 마무리합니다.' ),
		),
	),
);
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-process wooin-reveal","backgroundColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-process wooin-reveal has-white-background-color has-background">
	<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"clamp(2rem, 6vw, 6rem)"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column {"width":"38%","className":"wooin-process-head"} -->
		<div class="wp-block-column wooin-process-head" style="flex-basis:38%">
			<!-- wp:heading {"className":"wooin-en-title"} -->
			<h2 class="wp-block-heading wooin-en-title"><span>W</span>ooin <span>P</span>rocess</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"className":"wooin-lead"} -->
			<p class="wooin-lead">상담부터 마무리까지,<br><strong>6단계를 함께 걷습니다.</strong></p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"textColor":"muted"} -->
			<p class="has-muted-color has-text-color">회생은 신청서를 내는 것으로 끝나지 않습니다. 오히려 신청 이후가 더 중요합니다. 우인은 절차의 처음과 끝을 같은 팀이 책임집니다.</p>
			<!-- /wp:paragraph -->
			<!-- wp:html -->
			<div class="wooin-process-now" aria-hidden="true">
				<p class="wooin-process-count"><span data-step-now>01</span><small>/ 06</small></p>
				<p class="wooin-process-title" data-step-title>상담 · 진단</p>
				<div class="wooin-process-bar"><i></i></div>
			</div>
			<p class="wooin-process-cta">
				<a class="wooin-pill-link" href="/procedure/" data-cta-default>절차 자세히 보기 +</a>
				<a class="wooin-pill-link is-solid" href="/contact/corporate/" data-cta-final data-wooin-track="corporate">상담 신청하기<span class="wooin-arrow" aria-hidden="true"></span></a>
			</p>
			<!-- /wp:html -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="wooin-tabs" data-wooin-tabs>
				<div class="wooin-tab-list" role="tablist" aria-label="절차 구분">
					<?php $first = true; foreach ( $flows as $key => $flow ) : ?>
					<button type="button" role="tab" id="flow-tab-<?php echo esc_attr( $key ); ?>" aria-controls="flow-<?php echo esc_attr( $key ); ?>" aria-selected="<?php echo $first ? 'true' : 'false'; ?>" data-track="<?php echo esc_attr( $key ); ?>"<?php echo $first ? '' : ' tabindex="-1"'; ?>><?php echo esc_html( $flow[0] ); ?> 절차</button>
					<?php $first = false; endforeach; ?>
				</div>
				<?php $first = true; foreach ( $flows as $key => $flow ) : ?>
				<ol class="wooin-steps" data-track="<?php echo esc_attr( $key ); ?>" role="tabpanel" id="flow-<?php echo esc_attr( $key ); ?>" aria-labelledby="flow-tab-<?php echo esc_attr( $key ); ?>"<?php echo $first ? '' : ' hidden'; ?>>
					<?php foreach ( $flow[1] as $i => $step ) : ?>
					<li><span class="wooin-step-no"><?php echo esc_html( sprintf( '%02d', $i + 1 ) ); ?></span><div><h3><?php echo esc_html( $step[0] ); ?></h3><p><?php echo esc_html( $step[1] ); ?></p></div></li>
					<?php endforeach; ?>
				</ol>
				<?php $first = false; endforeach; ?>
			</div>
			<!-- /wp:html -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
