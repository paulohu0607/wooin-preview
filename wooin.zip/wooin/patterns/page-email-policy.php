<?php
/**
 * Title: 서브 · 이메일무단수집거부
 * Slug: wooin/page-email-policy
 * Categories: wooin
 * Inserter: no
 *
 * 2026-11-24 초안 — 「정보통신망 이용촉진 및 정보보호 등에 관한 법률」 제50조의2 · 제74조 기준. 사무소 최종 검토 필요.
 */
$info = static fn( string $k ): string => function_exists( 'wooin_core_site_info' ) ? wooin_core_site_info( $k ) : '';
$name = $info( 'brand_name' ) ? $info( 'brand_name' ) : '법률사무소 우인';
?>
<!-- wp:html -->
<section class="wooin-sub-section">
	<div class="wooin-sd-wrap is-narrow wooin-legal">
		<p class="wooin-legal-lead">이 홈페이지에 게시된 이메일 주소가 전자우편 수집 프로그램이나 그 밖의 기술적 장치를 이용하여 무단으로 수집되는 것을 거부합니다.</p>
		<p>이를 위반하면 「정보통신망 이용촉진 및 정보보호 등에 관한 법률」에 따라 형사 처벌을 받을 수 있습니다.</p>

		<h3>관련 법령</h3>
		<p><b>정보통신망 이용촉진 및 정보보호 등에 관한 법률 제50조의2 (전자우편주소의 무단 수집행위 등 금지)</b></p>
		<ol>
			<li>누구든지 인터넷 홈페이지 운영자 또는 관리자의 사전 동의 없이 인터넷 홈페이지에서 자동으로 전자우편주소를 수집하는 프로그램이나 그 밖의 기술적 장치를 이용하여 전자우편주소를 수집하여서는 아니 된다.</li>
			<li>누구든지 제1항을 위반하여 수집된 전자우편주소를 판매·유통하여서는 아니 된다.</li>
			<li>누구든지 제1항과 제2항에 따라 수집·판매 및 유통이 금지된 전자우편주소임을 알면서 이를 정보 전송에 이용하여서는 아니 된다.</li>
		</ol>
		<p><b>제74조 (벌칙)</b> 제50조의2를 위반하여 전자우편주소를 수집·판매·유통하거나 정보 전송에 이용한 자는 1천만원 이하의 벌금에 처한다.</p>

		<p class="wooin-legal-date"><?php echo esc_html( $name ); ?> · 게시일 2026년 11월 24일</p>
	</div>
</section>
<!-- /wp:html -->
