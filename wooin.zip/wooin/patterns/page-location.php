<?php
/**
 * Title: 서브 · 오시는 길
 * Slug: wooin/page-location
 * Categories: wooin
 * Inserter: no
 *
 * 주소·전화·운영시간은 공통정보에서 읽는다. 지도는 카카오맵/네이버지도 연동 방식 확정 후 삽입.
 */
$info = static fn( string $k ): string => function_exists( 'wooin_core_site_info' ) ? wooin_core_site_info( $k ) : '';
?>
<!-- wp:html -->
<section class="wooin-sub-section">
	<div class="wooin-sd-wrap wooin-location">
		<div class="wooin-map-slot" role="img" aria-label="지도 자리">
			<p>지도 연동 예정<br><small>카카오맵 또는 네이버지도</small></p>
		</div>
		<dl class="wooin-sd-facts is-location">
			<div><dt>주소</dt><dd><?php echo esc_html( $info( 'address' ) ? $info( 'address' ) : '주소 확정 후 표시' ); ?></dd></div>
			<div><dt>상담 전화</dt><dd><a href="<?php echo esc_url( $info( 'phone_href' ) ); ?>"><?php echo esc_html( $info( 'phone_display' ) ); ?></a></dd></div>
			<div><dt>상담 시간</dt><dd><?php echo esc_html( $info( 'hours' ) ); ?></dd></div>
			<div><dt>방문 상담</dt><dd>예약 후 진행됩니다. 방문 전 꼭 연락 주세요.</dd></div>
		</dl>
	</div>
</section>

<section class="wooin-sub-section is-tinted">
	<div class="wooin-sd-wrap">
		<div class="wooin-section-head is-center"><p class="wooin-eyebrow is-spaced">Directions</p><h2 class="wooin-display">찾아오시는 <strong>방법</strong></h2></div>
		<ul class="wooin-sd-checks is-3">
			<li><h3>지하철</h3><p class="wooin-placeholder-text">가까운 역·출구 정보 확인 후 게재</p></li>
			<li><h3>버스</h3><p class="wooin-placeholder-text">정류장·노선 정보 확인 후 게재</p></li>
			<li><h3>주차</h3><p class="wooin-placeholder-text">건물 주차 가능 여부 확인 후 게재</p></li>
		</ul>
	</div>
</section>
<!-- /wp:html -->
