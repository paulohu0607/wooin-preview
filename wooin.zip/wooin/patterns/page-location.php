<?php
/**
 * Title: 서브 · 오시는 길
 * Slug: wooin/page-location
 * Categories: wooin
 * Inserter: no
 *
 * 주소·전화·운영시간은 공통정보에서 읽는다.
 * 지도: 카카오맵 JavaScript API (키 = 공통정보 「카카오맵 JavaScript 키」, 동작 = assets/js/map.js).
 * 키가 없거나 지도를 못 불러와도 「카카오맵에서 보기 · 길찾기 · 네이버 지도」 버튼은 주소 검색으로 동작한다.
 */
$info  = static fn( string $k ): string => function_exists( 'wooin_core_site_info' ) ? wooin_core_site_info( $k ) : '';
$query = $info( 'map_query' );
$name  = $info( 'brand_name' ) ? $info( 'brand_name' ) : get_bloginfo( 'name' );
$key   = $info( 'kakao_map_key' );
?>
<!-- wp:html -->
<section class="wooin-sub-section">
	<div class="wooin-sd-wrap wooin-location">
		<div class="wooin-map" data-wooin-map data-key="<?php echo esc_attr( $key ); ?>" data-address="<?php echo esc_attr( $query ); ?>" data-name="<?php echo esc_attr( $name ); ?>">
			<div class="wooin-map-canvas" role="region" aria-label="<?php echo esc_attr( $name . ' 위치 지도' ); ?>">
				<div class="wooin-map-fallback">
					<span class="wooin-map-pin" aria-hidden="true"></span>
					<p><strong><?php echo esc_html( $name ); ?></strong><br><?php echo esc_html( $query ? $query : '주소 확정 후 표시' ); ?></p>
				</div>
			</div>
			<?php if ( $query ) : ?>
			<div class="wooin-map-links">
				<a href="<?php echo esc_url( 'https://map.kakao.com/link/search/' . rawurlencode( $query ) ); ?>" target="_blank" rel="noopener" data-map-view>카카오맵에서 보기<span class="screen-reader-text"> (새 창)</span></a>
				<a href="<?php echo esc_url( 'https://map.kakao.com/link/search/' . rawurlencode( $query ) ); ?>" target="_blank" rel="noopener" data-map-route>길찾기<span class="screen-reader-text"> (카카오맵, 새 창)</span></a>
				<a href="<?php echo esc_url( 'https://map.naver.com/p/search/' . rawurlencode( $query ) ); ?>" target="_blank" rel="noopener">네이버 지도<span class="screen-reader-text"> (새 창)</span></a>
			</div>
			<?php endif; ?>
		</div>
		<dl class="wooin-sd-facts is-location">
			<div><dt>주소</dt><dd><?php echo esc_html( $info( 'address' ) ? $info( 'address' ) : '주소 확정 후 표시' ); ?></dd></div>
			<div><dt>상담 전화</dt><dd><a href="<?php echo esc_url( $info( 'phone_href' ) ); ?>"><?php echo esc_html( $info( 'phone_display' ) ); ?></a></dd></div>
			<div><dt>상담 시간</dt><dd><?php echo esc_html( $info( 'hours' ) ); ?></dd></div>
			<div><dt>방문 상담</dt><dd>예약 후 진행됩니다. 방문 전 꼭 연락 주세요.</dd></div>
		</dl>
	</div>
</section>

<section class="wooin-sub-section is-tinted">
	<div class="wooin-sd-wrap">
		<div class="wooin-section-head is-center"><p class="wooin-eyebrow is-spaced">Directions</p><h2 class="wooin-display">찾아오시는 <strong>방법</strong></h2></div>
		<ul class="wooin-sd-checks is-3">
			<li><h3>지하철</h3><p class="wooin-placeholder-text">가까운 역·출구 정보 확인 후 게재</p></li>
			<li><h3>버스</h3><p class="wooin-placeholder-text">정류장·노선 정보 확인 후 게재</p></li>
			<li><h3>주차</h3><p class="wooin-placeholder-text">건물 주차 가능 여부 확인 후 게재</p></li>
		</ul>
	</div>
</section>
<!-- /wp:html -->
