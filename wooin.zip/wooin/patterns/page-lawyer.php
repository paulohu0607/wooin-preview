<?php
/**
 * Title: 서브 · 이서영 변호사 프로필
 * Slug: wooin/page-lawyer
 * Categories: wooin
 * Inserter: no
 *
 * 원고는 inc/people.php. 구성원 상세 템플릿은 wooin/person-detail 블록을 직접 쓴다 — 이 패턴은 일반 페이지에 넣을 때용.
 */
?>
<!-- wp:wooin/person-detail {"slug":"lee-seoyoung"} /-->
