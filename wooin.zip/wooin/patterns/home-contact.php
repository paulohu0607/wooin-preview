<?php
/**
 * Title: 메인 11 · CONTACT
 * Slug: wooin/home-contact
 * Categories: wooin
 * Inserter: no
 *
 * 오른쪽 폼은 시안용 화면(전송 기능 없음). 5단계에서 비공개 저장·알림 폼으로 교체.
 */
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-contact wooin-reveal","backgroundColor":"navy","textColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-contact wooin-reveal has-white-color has-navy-background-color has-text-color has-background">
	<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"clamp(2rem, 6vw, 6rem)"}}}} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:paragraph {"className":"wooin-eyebrow is-light is-spaced"} -->
			<p class="wooin-eyebrow is-light is-spaced">Contact Us</p>
			<!-- /wp:paragraph -->

			<!-- wp:heading {"className":"wooin-display","textColor":"white"} -->
			<h2 class="wp-block-heading wooin-display has-white-color has-text-color">압류와 독촉이 시작되기 전,<br><em>지금이 가장 빠른 때</em>입니다.</h2>
			<!-- /wp:heading -->

			<!-- wp:paragraph {"className":"wooin-contact-sub"} -->
			<p class="wooin-contact-sub">이런 신호가 하나라도 보인다면, 혼자 버티지 마세요.</p>
			<!-- /wp:paragraph -->

			<!-- wp:html -->
			<div class="wooin-signal-cols">
				<div><p class="wooin-signal-head">법인</p><ul class="wooin-signals"><li>계좌 압류·가압류 통지를 받았다</li><li>급여·세금·4대보험이 밀리기 시작했다</li><li>대출 만기 연장이 거절됐다</li></ul></div>
				<div><p class="wooin-signal-head">대표 · 개인사업자</p><ul class="wooin-signals"><li>카드·대출 돌려막기가 한계에 왔다</li><li>급여·통장 압류 통지를 받았다</li><li>독촉 전화가 하루에도 몇 번씩 온다</li></ul></div>
			</div>
			<!-- /wp:html -->

			<!-- wp:group {"className":"wooin-contact-call","layout":{"type":"flex","orientation":"vertical"}} -->
			<div class="wp-block-group wooin-contact-call">
				<!-- wp:paragraph {"className":"wooin-contact-label"} -->
				<p class="wooin-contact-label">법인 · 개인 회생파산 상담 · 비밀 보장</p>
				<!-- /wp:paragraph -->
				<!-- wp:paragraph {"className":"wooin-contact-phone","metadata":{"bindings":{"content":{"source":"wooin/site-info","args":{"key":"phone_display"}}}}} -->
				<p class="wooin-contact-phone">전화번호 미확정</p>
				<!-- /wp:paragraph -->
				<!-- wp:paragraph {"className":"wooin-contact-hours","metadata":{"bindings":{"content":{"source":"wooin/site-info","args":{"key":"hours"}}}}} -->
				<p class="wooin-contact-hours">운영시간 미확정</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:pattern {"slug":"wooin/consult-form"} /-->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
