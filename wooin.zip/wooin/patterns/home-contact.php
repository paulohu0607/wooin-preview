<?php
/**
 * Title: 메인 11 · CONTACT
 * Slug: wooin/home-contact
 * Categories: wooin
 * Inserter: no
 *
 * 오른쪽 폼은 시안용 화면(전송 기능 없음). 5단계에서 비공개 저장·알림 폼으로 교체.
 */
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-contact wooin-reveal","backgroundColor":"navy","textColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-contact wooin-reveal has-white-color has-navy-background-color has-text-color has-background">
	<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"clamp(2rem, 6vw, 6rem)"}}}} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:paragraph {"className":"wooin-eyebrow is-light is-spaced"} -->
			<p class="wooin-eyebrow is-light is-spaced"><?php echo esc_html( wooin_hv( 'contact_eyebrow' ) ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:heading {"className":"wooin-display","textColor":"white"} -->
			<h2 class="wp-block-heading wooin-display has-white-color has-text-color"><?php echo wooin_hf( 'contact_title', 'em' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></h2>
			<!-- /wp:heading -->

			<!-- wp:paragraph {"className":"wooin-contact-sub"} -->
			<p class="wooin-contact-sub"><?php echo esc_html( wooin_hv( 'contact_sub' ) ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:html -->
			<div class="wooin-signal-cols">
				<?php foreach ( array( 'corp', 'pers' ) as $wooin_k ) : ?>
					<?php if ( wooin_hl( "contact_{$wooin_k}_list" ) ) : ?>
				<div><p class="wooin-signal-head"><?php echo esc_html( wooin_hv( "contact_{$wooin_k}_head" ) ); ?></p><ul class="wooin-signals"><?php foreach ( wooin_hl( "contact_{$wooin_k}_list" ) as $wooin_li ) : ?><li><?php echo esc_html( $wooin_li ); ?></li><?php endforeach; ?></ul></div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
			<!-- /wp:html -->

			<!-- wp:group {"className":"wooin-contact-call","layout":{"type":"flex","orientation":"vertical"}} -->
			<div class="wp-block-group wooin-contact-call">
				<!-- wp:paragraph {"className":"wooin-contact-label"} -->
				<p class="wooin-contact-label"><?php echo esc_html( wooin_hv( 'contact_label' ) ); ?></p>
				<!-- /wp:paragraph -->
				<!-- wp:paragraph {"className":"wooin-contact-phone","metadata":{"bindings":{"content":{"source":"wooin/site-info","args":{"key":"phone_display"}}}}} -->
				<p class="wooin-contact-phone">전화번호 미확정</p>
				<!-- /wp:paragraph -->
				<!-- wp:paragraph {"className":"wooin-contact-hours","metadata":{"bindings":{"content":{"source":"wooin/site-info","args":{"key":"hours"}}}}} -->
				<p class="wooin-contact-hours">운영시간 미확정</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:pattern {"slug":"wooin/consult-form"} /-->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
