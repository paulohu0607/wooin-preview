<?php
/**
 * Title: 메인 09 · 의뢰인 후기 (좌우 캐러셀)
 * Slug: wooin/home-reviews
 * Categories: wooin
 * Inserter: no
 *
 * 카드는 「의뢰인 후기」 게시판(wooin_review) 데이터 — 메인 노출 표시한 후기 우선, 부족하면 최신 후기.
 * 카드를 누르면 후기 상세로, 「실제 후기 더 보기」는 게시판 목록으로 간다.
 * 동작: assets/js/carousel.js (좌우 버튼 · 점 · 스와이프 · 자동 넘김, 마우스 올리면 멈춤).
 */
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-reviews wooin-reveal","backgroundColor":"base","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-reviews wooin-reveal has-base-background-color has-background">
	<!-- wp:group {"className":"wooin-section-head is-row","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
	<div class="wp-block-group wooin-section-head is-row">
		<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->
		<div class="wp-block-group">
			<!-- wp:paragraph {"className":"wooin-eyebrow is-spaced"} -->
			<p class="wooin-eyebrow is-spaced">Client Reviews</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"className":"wooin-display"} -->
			<h2 class="wp-block-heading wooin-display">같은 길을 먼저 지나온<br><strong>의뢰인들의 이야기</strong></h2>
			<!-- /wp:heading -->
		</div>
		<!-- /wp:group -->
		<!-- wp:html -->
		<div class="wooin-carousel-nav" data-carousel-nav="reviews">
			<button type="button" class="wooin-carousel-btn" data-dir="-1" aria-label="이전 후기">←</button>
			<button type="button" class="wooin-carousel-btn" data-dir="1" aria-label="다음 후기">→</button>
		</div>
		<!-- /wp:html -->
	</div>
	<!-- /wp:group -->

	<!-- wp:wooin/review-carousel {"limit":8} /-->

	<!-- wp:paragraph {"className":"wooin-mock-note"} -->
	<p class="wooin-mock-note">※ 의뢰인의 게시 동의를 받은 실제 후기입니다. 개인정보 보호를 위해 이름 일부를 가렸습니다.</p>
	<!-- /wp:paragraph -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button {"className":"is-style-outline wooin-pill","textColor":"navy"} -->
		<div class="wp-block-button is-style-outline wooin-pill"><a class="wp-block-button__link has-navy-color has-text-color wp-element-button" href="/reviews/">실제 후기 더 보기 +</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
