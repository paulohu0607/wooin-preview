<?php
/**
 * Title: 메인 10 · 칼럼 · FAQ
 * Slug: wooin/home-insights
 * Categories: wooin
 * Inserter: no
 *
 * 등록된 글이 없을 때는 대표님들이 실제로 많이 묻는 질문 「제목」만 예시로 보여준다(답변은 FAQ 등록 시 작성).
 */
$sample_faq = array(
	array( '개인', '현재 소득이 없는데 개인회생을 할 수 있나요?' ),
	array( '개인', '개인회생을 하면 신용카드·휴대폰을 쓸 수 있나요?' ),
	array( '개인', '가족이나 회사에 알려지지 않을까요?' ),
	array( '법인', '법인회생을 신청하면 대표이사 자리는 유지되나요?' ),
	array( '법인', '대표이사의 연대보증 채무는 어떻게 되나요?' ),
);
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-reveal","backgroundColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-reveal has-white-background-color has-background">
	<!-- wp:columns {"className":"wooin-insights","style":{"spacing":{"blockGap":{"left":"clamp(2rem, 5vw, 5rem)"}}}} -->
	<div class="wp-block-columns wooin-insights">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"className":"wooin-col-head","layout":{"type":"flex","justifyContent":"space-between"}} -->
			<div class="wp-block-group wooin-col-head">
				<!-- wp:heading {"level":3} -->
				<h3 class="wp-block-heading">이서영 변호사의 <em>도산 칼럼</em></h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph -->
				<p><a class="wooin-more" href="/column/">전체보기 →</a></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->

			<!-- wp:query {"queryId":31,"query":{"perPage":5,"postType":"post","order":"desc","orderBy":"date","inherit":false}} -->
			<div class="wp-block-query">
				<!-- wp:post-template {"className":"wooin-list"} -->
					<!-- wp:group {"className":"wooin-list-item","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
					<div class="wp-block-group wooin-list-item">
						<!-- wp:post-title {"isLink":true,"level":4} /-->
						<!-- wp:post-date {"format":"Y.m.d"} /-->
					</div>
					<!-- /wp:group -->
				<!-- /wp:post-template -->
				<!-- wp:query-no-results -->
					<!-- wp:html -->
					<ul class="wooin-list is-sample">
						<li><span>개인회생 변제금, 2027년 생계비 인상으로 무엇이 달라지나</span><time>칼럼 예정</time></li>
						<li><span>법인회생, 언제 신청해야 가장 유리할까</span><time>칼럼 예정</time></li>
						<li><span>개인회생과 개인파산, 나에게 맞는 절차는</span><time>칼럼 예정</time></li>
						<li><span>법인파산 후 대표님 개인에게 남는 책임</span><time>칼럼 예정</time></li>
					</ul>
					<!-- /wp:html -->
				<!-- /wp:query-no-results -->
			</div>
			<!-- /wp:query -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"className":"wooin-col-head","layout":{"type":"flex","justifyContent":"space-between"}} -->
			<div class="wp-block-group wooin-col-head">
				<!-- wp:heading {"level":3} -->
				<h3 class="wp-block-heading"><em>가장 많이 묻는</em> 질문</h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph -->
				<p><a class="wooin-more" href="/faq/">전체보기 →</a></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->

			<!-- wp:query {"queryId":32,"query":{"perPage":5,"postType":"wooin_faq","order":"asc","orderBy":"menu_order","inherit":false}} -->
			<div class="wp-block-query">
				<!-- wp:post-template {"className":"wooin-list"} -->
					<!-- wp:post-title {"level":4,"className":"wooin-faq-q"} /-->
				<!-- /wp:post-template -->
				<!-- wp:query-no-results -->
					<!-- wp:html -->
					<ul class="wooin-list is-sample">
						<?php foreach ( $sample_faq as $q ) : ?>
						<li><h4 class="wooin-faq-q"><span class="wooin-chip<?php echo '법인' === $q[0] ? ' is-dark' : ''; ?>"><?php echo esc_html( $q[0] ); ?></span><?php echo esc_html( $q[1] ); ?></h4></li>
						<?php endforeach; ?>
					</ul>
					<!-- /wp:html -->
				<!-- /wp:query-no-results -->
			</div>
			<!-- /wp:query -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
