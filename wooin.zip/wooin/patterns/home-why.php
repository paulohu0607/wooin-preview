<?php
/**
 * Title: 메인 03 · 우인의 원칙 (Wooin System)
 * Slug: wooin/home-why
 * Categories: wooin
 * Inserter: no
 *
 * 각 원칙은 wooin.net 표기 기반. 법인 사건에도 같은 운영인지 업체 확인 중 (체크리스트 A7).
 */
// 문구는 관리자 「메인 화면 편집 › 우인의 원칙」. 제목을 비운 카드는 숨긴다.
$items = array();
for ( $n = 1; $n <= 6; $n++ ) {
	if ( '' !== wooin_hv( "why{$n}_title" ) ) {
		$items[] = array( wooin_hv( "why{$n}_title" ), wooin_hv( "why{$n}_text" ) );
	}
}
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-reveal","backgroundColor":"base","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-reveal has-base-background-color has-background">
	<!-- wp:group {"className":"wooin-section-head is-center","layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
	<div class="wp-block-group wooin-section-head is-center">
		<!-- wp:paragraph {"className":"wooin-eyebrow is-spaced"} -->
		<p class="wooin-eyebrow is-spaced"><?php echo esc_html( wooin_hv( 'why_eyebrow' ) ); ?></p>
		<!-- /wp:paragraph -->
		<!-- wp:heading {"textAlign":"center","className":"wooin-display"} -->
		<h2 class="wp-block-heading has-text-align-center wooin-display"><?php echo wooin_hf( 'why_title', 'em' ); // phpcs:ignore WordPress.Security.EscapeOutput -- 이스케이프 후 꾸밈 ?></h2>
		<!-- /wp:heading -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"className":"wooin-why-grid","layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"16rem"}} -->
	<div class="wp-block-group wooin-why-grid">
		<?php foreach ( $items as $i => $item ) : ?>
		<!-- wp:group {"className":"wooin-why-card","layout":{"type":"flex","orientation":"vertical"}} -->
		<div class="wp-block-group wooin-why-card"><!-- wp:paragraph {"className":"wooin-why-no"} --><p class="wooin-why-no"><?php echo esc_html( sprintf( '%02d', $i + 1 ) ); ?></p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3 class="wp-block-heading"><?php echo esc_html( $item[0] ); ?></h3><!-- /wp:heading --><!-- wp:paragraph --><p><?php echo esc_html( $item[1] ); ?></p><!-- /wp:paragraph --></div>
		<!-- /wp:group -->
		<?php endforeach; ?>
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
