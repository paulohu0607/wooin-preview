<?php
/**
 * Title: 메인 03 · 우인의 원칙 (Wooin System)
 * Slug: wooin/home-why
 * Categories: wooin
 * Inserter: no
 *
 * 각 원칙은 wooin.net 표기 기반. 법인 사건에도 같은 운영인지 업체 확인 중 (체크리스트 A7).
 */
$items = array(
	array( '빚만 연구했습니다', '9년간 오직 도산 분야만 연구한 변호사가 사건의 전 과정을 검토하고 관리합니다.' ),
	array( '적게 맡아, 깊이 봅니다', '매월 수임하는 사건 수를 제한해 한 분, 한 회사에 집중합니다.' ),
	array( '독촉은 우인이 받습니다', '채권자의 추심·독촉 연락은 우인이 대응합니다. 의뢰인은 일상과 사업에만 집중하세요.' ),
	array( '담당자가 바뀌지 않습니다', '1:1 전담 직원이 처음부터 끝까지 함께하며, 언제든 진행 상황을 확인할 수 있습니다.' ),
	array( '2주 안에 접수합니다', '서류를 받은 날부터 2주 안에 법원 접수를 약속합니다. 회생은 시간이 곧 기회입니다.' ),
	array( '계약을 서두르지 않습니다', '무조건 계약을 유도하는 사무장이 없습니다. 가능성은 변호사가 판단합니다.' ),
);
?>
<!-- wp:group {"align":"full","className":"wooin-section wooin-reveal","backgroundColor":"base","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull wooin-section wooin-reveal has-base-background-color has-background">
	<!-- wp:group {"className":"wooin-section-head is-center","layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
	<div class="wp-block-group wooin-section-head is-center">
		<!-- wp:paragraph {"className":"wooin-eyebrow is-spaced"} -->
		<p class="wooin-eyebrow is-spaced">Wooin · System</p>
		<!-- /wp:paragraph -->
		<!-- wp:heading {"textAlign":"center","className":"wooin-display"} -->
		<h2 class="wp-block-heading has-text-align-center wooin-display"><em>4,000건</em>의 경험이 만든<br><strong>우인의 6가지 원칙</strong></h2>
		<!-- /wp:heading -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"className":"wooin-why-grid","layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"16rem"}} -->
	<div class="wp-block-group wooin-why-grid">
		<?php foreach ( $items as $i => $item ) : ?>
		<!-- wp:group {"className":"wooin-why-card","layout":{"type":"flex","orientation":"vertical"}} -->
		<div class="wp-block-group wooin-why-card"><!-- wp:paragraph {"className":"wooin-why-no"} --><p class="wooin-why-no"><?php echo esc_html( sprintf( '%02d', $i + 1 ) ); ?></p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3 class="wp-block-heading"><?php echo esc_html( $item[0] ); ?></h3><!-- /wp:heading --><!-- wp:paragraph --><p><?php echo esc_html( $item[1] ); ?></p><!-- /wp:paragraph --></div>
		<!-- /wp:group -->
		<?php endforeach; ?>
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
