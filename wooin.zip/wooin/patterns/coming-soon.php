<?php
/**
 * Title: 서브 · 게시 예정 안내
 * Slug: wooin/coming-soon
 * Categories: wooin
 *
 * 원고·자료가 아직 없는 페이지에 쓴다(메뉴 링크가 404 가 되지 않도록).
 */
?>
<!-- wp:html -->
<section class="wooin-sub-section">
	<div class="wooin-sd-wrap is-narrow wooin-coming">
		<p class="wooin-coming-mark" aria-hidden="true">Coming soon</p>
		<h2>이 페이지는 준비 중입니다</h2>
		<p>자료와 원고가 확정되는 대로 게시됩니다. 지금 궁금한 점은 상담으로 먼저 문의해 주세요.</p>
		<p class="wooin-coming-links"><a class="wooin-pill-link" href="/faq/">자주 묻는 질문</a> <a class="wooin-pill-link" href="/videos/">이서영 변호사 TV</a></p>
	</div>
</section>
<!-- /wp:html -->
