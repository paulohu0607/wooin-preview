<?php
/**
 * Title: 서브 · 자주 묻는 질문
 * Slug: wooin/page-faq
 * Categories: wooin
 * Inserter: no
 *
 * 관리자 「FAQ」에 등록한 질문을 법인 / 개인 탭 · 단계별로 보여준다 (wooin-core includes/faq.php).
 * 법인회생 질문은 클라이언트 노션 FAQ 원문 (2026-10-26).
 */
?>
<!-- wp:group {"className":"wooin-sub-section","layout":{"type":"constrained","contentSize":"860px"}} -->
<div class="wp-block-group wooin-sub-section">
	<!-- wp:wooin/faq-list /-->

	<!-- wp:paragraph {"className":"wooin-mock-note"} -->
	<p class="wooin-mock-note">※ 일반적인 안내이며, 개별 사건과 법원 운영에 따라 달라질 수 있습니다. 구체적인 사안은 상담으로 확인해 주세요.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
