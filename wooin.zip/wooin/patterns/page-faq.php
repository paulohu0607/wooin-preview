<?php
/**
 * Title: 서브 · 자주 묻는 질문
 * Slug: wooin/page-faq
 * Categories: wooin
 * Inserter: no
 *
 * 업무분야 상세의 FAQ 를 모아 개인/법인 탭으로 보여준다(원고 한 곳: inc/service-detail.php).
 * 4단계에서 wooin_faq 글 유형으로 옮겨 관리자에서 편집하도록 바꾼다.
 */
$groups = array( 'personal' => array(), 'corporate' => array() );
foreach ( wooin_services_data() as $d ) {
	$groups[ $d['track'] ] = array_merge( $groups[ $d['track'] ], $d['faq'] );
}
?>
<!-- wp:html -->
<section class="wooin-sub-section">
	<div class="wooin-sd-wrap is-narrow">
		<div class="wooin-tabs is-center" data-wooin-tabs>
			<div class="wooin-tab-list" role="tablist" aria-label="질문 구분">
				<button type="button" role="tab" id="faq-tab-personal" aria-controls="faq-personal" aria-selected="true" data-track="personal">개인회생 · 파산</button>
				<button type="button" role="tab" id="faq-tab-corporate" aria-controls="faq-corporate" aria-selected="false" data-track="corporate" tabindex="-1">법인회생 · 파산</button>
			</div>
			<?php foreach ( $groups as $track => $faqs ) : ?>
			<div role="tabpanel" id="faq-<?php echo esc_attr( $track ); ?>" aria-labelledby="faq-tab-<?php echo esc_attr( $track ); ?>" class="wooin-accordion"<?php echo 'personal' === $track ? '' : ' hidden'; ?>>
				<?php foreach ( $faqs as $q ) : ?>
				<details><summary><?php echo esc_html( $q[0] ); ?></summary><p><?php echo esc_html( $q[1] ); ?></p></details>
				<?php endforeach; ?>
			</div>
			<?php endforeach; ?>
		</div>
		<p class="wooin-mock-note">※ 일반적인 안내이며, 구체적인 사안은 상담을 통해 확인해 주세요.</p>
	</div>
</section>
<!-- /wp:html -->
