<?php
/**
 * Title: 메인 01 · 히어로
 * Slug: wooin/home-hero
 * Categories: wooin
 * Inserter: no
 *
 * 배경은 시안용 샘플 사진(CSS .wooin-hero). 우인 영상이 오면 커버 블록 배경을 영상으로 교체.
 * 카피 4안 (시안 비교용, 확정 후 하나만 남김): 주소 뒤 ?hero=1~4
 *  1 브랜드형 — 「우·인」 두 글자 강조   2 실적형 — 4,000번의 새 출발
 *  3 공감형 — 혼자 버틴 시간은 여기까지   4 선언형 — 부채는 끝이 아닙니다
 */
$wooin_heroes = array(
	1 => array(
		'법인회생 · 법인파산 · 개인회생 · 개인파산 | 법률사무소 우인',
		'<mark>우</mark>리의 새 출발,<br><mark>인</mark>가결정까지 함께합니다.',
		'멈춰 선 회사도, 채무에 묶인 대표님과 전문직도.<br>9년간 오직 도산만 연구한 <span class="wooin-underline">이서영 변호사</span>가 처음부터 끝까지 함께합니다.',
	),
	2 => array(
		'4,000건의 회생·파산 성공사례 | 법률사무소 우인',
		'<mark>4,000번</mark>의 새 출발,<br>다음은 대표님 차례입니다.',
		'회사의 부채도, 대표님 개인의 채무도.<br>9년간 오직 도산만 연구한 <span class="wooin-underline">이서영 변호사</span>가 옳고 빠른 길을 찾습니다.',
	),
	3 => array(
		'자금 압박에 잠 못 드는 밤이 길었다면 | 법률사무소 우인',
		'혼자 버틴 시간은<br><mark>여기까지</mark>입니다.',
		'채권자 독촉과 압류 대응은 이제 우인이 맡습니다.<br>법인 도산부터 개인회생까지, <span class="wooin-underline">이서영 변호사</span>가 끝까지 함께합니다.',
	),
	4 => array(
		'도산만 연구한 변호사 | 법률사무소 우인',
		'부채는 끝이 아닙니다.<br><mark>정리하는 방법</mark>이 있을 뿐.',
		'회사를 살리는 회생, 책임 있게 정리하는 파산.<br>기업과 대표님에게 맞는 길을 <span class="wooin-underline">이서영 변호사</span>가 설계합니다.',
	),
);
$wooin_hero_no = isset( $_GET['hero'] ) ? (int) $_GET['hero'] : 1; // phpcs:ignore WordPress.Security.NonceVerification
$wooin_hero    = $wooin_heroes[ $wooin_hero_no ] ?? $wooin_heroes[1];
?>
<!-- wp:cover {"dimRatio":0,"minHeight":100,"minHeightUnit":"vh","contentPosition":"center left","isDark":true,"align":"full","className":"wooin-hero","style":{"spacing":{"padding":{"top":"8rem","bottom":"7rem","left":"clamp(20px, 7vw, 120px)","right":"clamp(20px, 7vw, 120px)"}}}} -->
<div class="wp-block-cover alignfull is-dark has-custom-content-position is-position-center-left wooin-hero" style="padding-top:8rem;padding-right:clamp(20px, 7vw, 120px);padding-bottom:7rem;padding-left:clamp(20px, 7vw, 120px);min-height:100vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><div class="wp-block-cover__inner-container">
	<!-- wp:paragraph {"className":"wooin-eyebrow is-light"} -->
	<p class="wooin-eyebrow is-light"><?php echo esc_html( $wooin_hero[0] ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"level":1,"className":"wooin-hero-title","textColor":"white"} -->
	<h1 class="wp-block-heading wooin-hero-title has-white-color has-text-color"><?php echo wp_kses_post( $wooin_hero[1] ); ?></h1>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"className":"wooin-hero-lead"} -->
	<p class="wooin-hero-lead"><?php echo wp_kses_post( $wooin_hero[2] ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"2.5rem"}}}} -->
	<div class="wp-block-buttons" style="margin-top:2.5rem">
		<!-- wp:button -->
		<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/corporate/" data-wooin-track="corporate">법인 상담 신청<span class="wooin-arrow" aria-hidden="true"></span></a></div>
		<!-- /wp:button -->

		<!-- wp:button {"className":"is-style-outline","textColor":"white"} -->
		<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-white-color has-text-color wp-element-button" href="/contact/personal/" data-wooin-track="personal">개인 상담 신청<span class="wooin-arrow" aria-hidden="true"></span></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->

	<!-- wp:list {"className":"wooin-hero-badges"} -->
	<ul class="wp-block-list wooin-hero-badges">
		<!-- wp:list-item --><li><strong>대한변호사협회</strong>이사</li><!-- /wp:list-item -->
		<!-- wp:list-item --><li><strong>4,000건+</strong>회생·파산 성공사례</li><!-- /wp:list-item -->
		<!-- wp:list-item --><li><strong>10.1만</strong>유튜브 구독자</li><!-- /wp:list-item -->
	</ul>
	<!-- /wp:list -->
</div></div>
<!-- /wp:cover -->
