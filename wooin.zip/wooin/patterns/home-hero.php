<?php
/**
 * Title: 메인 01 · 히어로
 * Slug: wooin/home-hero
 * Categories: wooin
 * Inserter: no
 *
 * 문구·버튼·배지·배경 사진/영상은 관리자 「메인 화면 편집 › 첫 화면」에서 바꾼다.
 * 배경 사진이 없으면 기본 사진(CSS .wooin-hero).
 */
$wooin_hero    = array(
	wooin_hv( 'hero_eyebrow' ),
	wooin_hf( 'hero_title', 'mark' ),
	wooin_hf( 'hero_lead', 'span class="wooin-underline"' ),
);
$wooin_img     = wooin_hm( 'hero_image' );
$wooin_video   = wooin_hm( 'hero_video' );
$wooin_style   = $wooin_img ? '--wooin-hero-img:url(' . esc_url( $wooin_img ) . ');' : '';
$wooin_buttons = array();
foreach ( array( 1 => 'corporate', 2 => 'personal' ) as $n => $track ) {
	if ( '' !== wooin_hv( "hero_btn{$n}_label" ) ) {
		$wooin_buttons[] = array( wooin_hv( "hero_btn{$n}_label" ), wooin_hu( "hero_btn{$n}_url" ), $track );
	}
}
$wooin_badges = array();
foreach ( array( 1, 2, 3 ) as $n ) {
	if ( '' !== wooin_hv( "hero_badge{$n}_strong" ) ) {
		$wooin_badges[] = array( wooin_hv( "hero_badge{$n}_strong" ), wooin_hv( "hero_badge{$n}_text" ) );
	}
}
?>
<!-- wp:cover {"dimRatio":0,"minHeight":100,"minHeightUnit":"vh","contentPosition":"center left","isDark":true,"align":"full","className":"wooin-hero","style":{"spacing":{"padding":{"top":"8rem","bottom":"7rem","left":"clamp(20px, 7vw, 120px)","right":"clamp(20px, 7vw, 120px)"}}}} -->
<div class="wp-block-cover alignfull is-dark has-custom-content-position is-position-center-left wooin-hero<?php echo $wooin_video ? ' has-video' : ''; ?>" style="<?php echo esc_attr( $wooin_style ); ?>padding-top:8rem;padding-right:clamp(20px, 7vw, 120px);padding-bottom:7rem;padding-left:clamp(20px, 7vw, 120px);min-height:100vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><?php if ( $wooin_video ) : ?><video class="wp-block-cover__video-background intrinsic-ignore" autoplay muted loop playsinline preload="metadata" src="<?php echo esc_url( $wooin_video ); ?>"<?php echo $wooin_img ? ' poster="' . esc_url( $wooin_img ) . '"' : ''; ?>></video><?php endif; ?><div class="wp-block-cover__inner-container">
	<!-- wp:paragraph {"className":"wooin-eyebrow is-light"} -->
	<p class="wooin-eyebrow is-light"><?php echo esc_html( $wooin_hero[0] ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"level":1,"className":"wooin-hero-title","textColor":"white"} -->
	<h1 class="wp-block-heading wooin-hero-title has-white-color has-text-color"><?php echo wp_kses_post( $wooin_hero[1] ); ?></h1>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"className":"wooin-hero-lead"} -->
	<p class="wooin-hero-lead"><?php echo wp_kses_post( $wooin_hero[2] ); ?></p>
	<!-- /wp:paragraph -->
<?php if ( $wooin_buttons ) : ?>

	<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"2.5rem"}}}} -->
	<div class="wp-block-buttons" style="margin-top:2.5rem">
	<?php foreach ( $wooin_buttons as $i => $b ) : ?>
		<?php if ( 0 === $i ) : ?>
		<!-- wp:button -->
		<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $b[1] ); ?>" data-wooin-track="<?php echo esc_attr( $b[2] ); ?>"><?php echo esc_html( $b[0] ); ?><span class="wooin-arrow" aria-hidden="true"></span></a></div>
		<!-- /wp:button -->
		<?php else : ?>
		<!-- wp:button {"className":"is-style-outline","textColor":"white"} -->
		<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-white-color has-text-color wp-element-button" href="<?php echo esc_url( $b[1] ); ?>" data-wooin-track="<?php echo esc_attr( $b[2] ); ?>"><?php echo esc_html( $b[0] ); ?><span class="wooin-arrow" aria-hidden="true"></span></a></div>
		<!-- /wp:button -->
		<?php endif; ?>
	<?php endforeach; ?>
	</div>
	<!-- /wp:buttons -->
<?php endif; ?>
<?php if ( $wooin_badges ) : ?>

	<!-- wp:list {"className":"wooin-hero-badges"} -->
	<ul class="wp-block-list wooin-hero-badges">
	<?php foreach ( $wooin_badges as $b ) : ?>
		<!-- wp:list-item --><li><strong><?php echo esc_html( $b[0] ); ?></strong><?php echo esc_html( $b[1] ); ?></li><!-- /wp:list-item -->
	<?php endforeach; ?>
	</ul>
	<!-- /wp:list -->
<?php endif; ?>
</div></div>
<!-- /wp:cover -->
