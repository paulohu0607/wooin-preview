<?php
/**
 * Title: 메인 01 · 히어로
 * Slug: wooin/home-hero
 * Categories: wooin
 * Inserter: no
 *
 * 문구·버튼·배지·배경 사진/영상은 관리자 「메인 화면 편집 › 첫 화면」에서 바꾼다 (기본값 = 1안).
 * 배경 사진이 없으면 시안용 샘플 사진(CSS .wooin-hero).
 * 카피 4안 비교 (시안용, 확정 후 제거): 주소 뒤 ?hero=1~4
 *  1 브랜드형 — 「우·인」 두 글자 강조   2 실적형 — 4,000번의 새 출발
 *  3 공감형 — 혼자 버틴 시간은 여기까지   4 선언형 — 부채는 끝이 아닙니다
 */
$wooin_heroes = array(
	1 => array(
		'법인회생 · 법인파산 · 개인회생 · 개인파산 | 법률사무소 우인',
		'<mark>우</mark>리의 새 출발,<br><mark>인</mark>가결정까지 함께합니다.',
		'멈춰 선 회사도, 채무에 묶인 대표님과 전문직도.<br>9년간 오직 도산만 연구한 <span class="wooin-underline">이서영 변호사</span>가 처음부터 끝까지 함께합니다.',
	),
	2 => array(
		'4,000건의 회생·파산 성공사례 | 법률사무소 우인',
		'<mark>4,000번</mark>의 새 출발,<br>다음은 대표님 차례입니다.',
		'회사의 부채도, 대표님 개인의 채무도.<br>9년간 오직 도산만 연구한 <span class="wooin-underline">이서영 변호사</span>가 옳고 빠른 길을 찾습니다.',
	),
	3 => array(
		'자금 압박에 잠 못 드는 밤이 길었다면 | 법률사무소 우인',
		'혼자 버틴 시간은<br><mark>여기까지</mark>입니다.',
		'채권자 독촉과 압류 대응은 이제 우인이 맡습니다.<br>법인 도산부터 개인회생까지, <span class="wooin-underline">이서영 변호사</span>가 끝까지 함께합니다.',
	),
	4 => array(
		'도산만 연구한 변호사 | 법률사무소 우인',
		'부채는 끝이 아닙니다.<br><mark>정리하는 방법</mark>이 있을 뿐.',
		'회사를 살리는 회생, 책임 있게 정리하는 파산.<br>기업과 대표님에게 맞는 길을 <span class="wooin-underline">이서영 변호사</span>가 설계합니다.',
	),
);
// 시안 비교(?hero=N)가 아니면 관리자 「메인 화면 편집 › 첫 화면」 값을 쓴다.
$wooin_hero_no = isset( $_GET['hero'] ) ? (int) $_GET['hero'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
$wooin_hero    = $wooin_heroes[ $wooin_hero_no ] ?? array(
	wooin_hv( 'hero_eyebrow' ),
	wooin_hf( 'hero_title', 'mark' ),
	wooin_hf( 'hero_lead', 'span class="wooin-underline"' ),
);
$wooin_img     = wooin_hm( 'hero_image' );
$wooin_video   = wooin_hm( 'hero_video' );
$wooin_style   = $wooin_img ? '--wooin-hero-img:url(' . esc_url( $wooin_img ) . ');' : '';
$wooin_buttons = array();
foreach ( array( 1 => 'corporate', 2 => 'personal' ) as $n => $track ) {
	if ( '' !== wooin_hv( "hero_btn{$n}_label" ) ) {
		$wooin_buttons[] = array( wooin_hv( "hero_btn{$n}_label" ), wooin_hu( "hero_btn{$n}_url" ), $track );
	}
}
$wooin_badges = array();
foreach ( array( 1, 2, 3 ) as $n ) {
	if ( '' !== wooin_hv( "hero_badge{$n}_strong" ) ) {
		$wooin_badges[] = array( wooin_hv( "hero_badge{$n}_strong" ), wooin_hv( "hero_badge{$n}_text" ) );
	}
}
?>
<!-- wp:cover {"dimRatio":0,"minHeight":100,"minHeightUnit":"vh","contentPosition":"center left","isDark":true,"align":"full","className":"wooin-hero","style":{"spacing":{"padding":{"top":"8rem","bottom":"7rem","left":"clamp(20px, 7vw, 120px)","right":"clamp(20px, 7vw, 120px)"}}}} -->
<div class="wp-block-cover alignfull is-dark has-custom-content-position is-position-center-left wooin-hero<?php echo $wooin_video ? ' has-video' : ''; ?>" style="<?php echo esc_attr( $wooin_style ); ?>padding-top:8rem;padding-right:clamp(20px, 7vw, 120px);padding-bottom:7rem;padding-left:clamp(20px, 7vw, 120px);min-height:100vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><?php if ( $wooin_video ) : ?><video class="wp-block-cover__video-background intrinsic-ignore" autoplay muted loop playsinline preload="metadata" src="<?php echo esc_url( $wooin_video ); ?>"<?php echo $wooin_img ? ' poster="' . esc_url( $wooin_img ) . '"' : ''; ?>></video><?php endif; ?><div class="wp-block-cover__inner-container">
	<!-- wp:paragraph {"className":"wooin-eyebrow is-light"} -->
	<p class="wooin-eyebrow is-light"><?php echo esc_html( $wooin_hero[0] ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"level":1,"className":"wooin-hero-title","textColor":"white"} -->
	<h1 class="wp-block-heading wooin-hero-title has-white-color has-text-color"><?php echo wp_kses_post( $wooin_hero[1] ); ?></h1>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"className":"wooin-hero-lead"} -->
	<p class="wooin-hero-lead"><?php echo wp_kses_post( $wooin_hero[2] ); ?></p>
	<!-- /wp:paragraph -->
<?php if ( $wooin_buttons ) : ?>

	<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"2.5rem"}}}} -->
	<div class="wp-block-buttons" style="margin-top:2.5rem">
	<?php foreach ( $wooin_buttons as $i => $b ) : ?>
		<?php if ( 0 === $i ) : ?>
		<!-- wp:button -->
		<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $b[1] ); ?>" data-wooin-track="<?php echo esc_attr( $b[2] ); ?>"><?php echo esc_html( $b[0] ); ?><span class="wooin-arrow" aria-hidden="true"></span></a></div>
		<!-- /wp:button -->
		<?php else : ?>
		<!-- wp:button {"className":"is-style-outline","textColor":"white"} -->
		<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-white-color has-text-color wp-element-button" href="<?php echo esc_url( $b[1] ); ?>" data-wooin-track="<?php echo esc_attr( $b[2] ); ?>"><?php echo esc_html( $b[0] ); ?><span class="wooin-arrow" aria-hidden="true"></span></a></div>
		<!-- /wp:button -->
		<?php endif; ?>
	<?php endforeach; ?>
	</div>
	<!-- /wp:buttons -->
<?php endif; ?>
<?php if ( $wooin_badges ) : ?>

	<!-- wp:list {"className":"wooin-hero-badges"} -->
	<ul class="wp-block-list wooin-hero-badges">
	<?php foreach ( $wooin_badges as $b ) : ?>
		<!-- wp:list-item --><li><strong><?php echo esc_html( $b[0] ); ?></strong><?php echo esc_html( $b[1] ); ?></li><!-- /wp:list-item -->
	<?php endforeach; ?>
	</ul>
	<!-- /wp:list -->
<?php endif; ?>
</div></div>
<!-- /wp:cover -->
