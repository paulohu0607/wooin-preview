<?php
/**
 * Title: 업무분야 상세 · personal-rehabilitation
 * Slug: wooin/service-personal-rehabilitation
 * Categories: wooin
 * Inserter: no
 *
 * 원고·구성: inc/service-detail.php
 */
echo wooin_service_detail( 'personal-rehabilitation' ); // phpcs:ignore WordPress.Security.EscapeOutput -- 함수 안에서 이스케이프
