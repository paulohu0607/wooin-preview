<?php
/**
 * Title: 업무분야 상세 · corporate-bankruptcy
 * Slug: wooin/service-corporate-bankruptcy
 * Categories: wooin
 * Inserter: no
 *
 * 원고·구성: inc/service-detail.php
 */
echo wooin_service_detail( 'corporate-bankruptcy' ); // phpcs:ignore WordPress.Security.EscapeOutput -- 함수 안에서 이스케이프
