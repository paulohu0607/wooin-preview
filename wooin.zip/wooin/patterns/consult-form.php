<?php
/**
 * Title: 상담 신청 폼 (개인 / 법인 구분)
 * Slug: wooin/consult-form
 * Categories: wooin
 *
 * 한 폼 안에서 「개인회생·파산 / 법인회생·파산」을 먼저 고르면 입력 항목이 바뀐다.
 * 선택값은 hidden track(personal|corporate)으로 함께 전송 → 저장·접수번호·알림 담당자를 구분 (기획 v0.4 4절).
 * /contact/personal/, /contact/corporate/, ?type=corporate 로 들어오면 해당 구분이 미리 선택된다 (tabs.js).
 *
 * 간단 작성(기본: 필수 항목 + 동의만)과 「자세히 작성하기」(채무 현황 · 상태 체크리스트 등)로 나뉜다 — 2026-10-26 클라이언트 요청. mode=simple|detail 로 전송.
 * 법인이 먼저 보이고 기본 선택이다.
 * 개인 항목은 우인이 현재 쓰는 구글폼 「개인회생/개인파산 상담신청서」 구성을 그대로 반영 (2026-10-13).
 * 법인 항목은 같은 원칙(진행 가능 여부 판단에 필요한 정보)으로 법인용으로 구성.
 *
 * 지금은 시안: 전송하지 않고 안내 문구만 보여준다. 5단계에서 wooin-core 상담 모듈과 연결.
 */
$chips = static function ( string $name, array $options, string $type = 'radio', bool $required = false ): void {
	foreach ( $options as $i => $label ) {
		printf(
			'<label class="wooin-choice"><input type="%1$s" name="%2$s" value="%3$s"%4$s><span>%3$s</span></label>',
			esc_attr( $type ),
			esc_attr( $name ),
			esc_attr( $label ),
			( $required && 0 === $i ) ? ' required' : ''
		);
	}
};
$regions = static function ( string $name, bool $required = true ): void {
	echo '<select name="' . esc_attr( $name ) . '"' . ( $required ? ' required' : '' ) . '><option value="">선택</option>';
	foreach ( array( '서울', '경기', '인천', '부산', '대구', '광주', '대전', '울산', '세종', '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주' ) as $r ) {
		echo '<option>' . esc_html( $r ) . '</option>';
	}
	echo '</select>';
};
$callback = function_exists( 'wooin_core_site_info' ) ? wooin_core_site_info( 'callback_tail' ) : '';
?>
<!-- wp:html -->
<form class="wooin-form" id="consult" data-wooin-consult novalidate aria-label="1:1 비밀 상담 신청">
	<h3>1:1 비밀 상담 신청</h3>
	<p class="wooin-form-desc">남겨주신 내용은 담당 변호사와 상담 담당자만 확인합니다.</p>
	<input type="hidden" name="track" value="corporate">
	<input type="hidden" name="mode" value="simple">

	<div class="wooin-tabs is-form" data-wooin-tabs>
		<div class="wooin-tab-list is-switch" role="tablist" aria-label="상담 구분">
			<button type="button" role="tab" id="consult-tab-corporate" aria-controls="consult-corporate" aria-selected="true" data-track="corporate"><span><b>법인</b>회생 · 파산</span><small>주식회사 · 유한회사 등</small></button>
			<button type="button" role="tab" id="consult-tab-personal" aria-controls="consult-personal" aria-selected="false" data-track="personal" tabindex="-1"><span><b>개인</b>회생 · 파산</span><small>개인 · 개인사업자 · 전문직</small></button>
		</div>

		<!-- 법인회생 · 법인파산 -->
		<div role="tabpanel" id="consult-corporate" aria-labelledby="consult-tab-corporate" class="wooin-form-panel">
			<p class="wooin-form-lead">회사의 위기, 혼자 판단하지 마세요. 재무 상황을 함께 진단해 회생과 파산 중 맞는 길을 찾겠습니다.</p>
			<div class="wooin-form-row">
				<label>법인명 *<input type="text" name="c_company" autocomplete="organization" required placeholder="㈜우인산업"></label>
				<label>담당자 성함 · 직책 *<input type="text" name="c_name" required placeholder="홍길동 대표이사"></label>
			</div>
			<div class="wooin-form-row">
				<label>연락처 *<input type="tel" name="c_phone" autocomplete="tel" required placeholder="010-0000-0000"></label>
				<fieldset><legend>상담 항목 *</legend><?php $chips( 'c_area', array( '법인회생', '법인파산', '아직 정하지 못함' ), 'radio', true ); ?></fieldset>
			</div>
			<fieldset><legend>부채 규모 *</legend><?php $chips( 'c_debt', array( '50억 미만', '50억~300억', '300억~1,000억', '1,000억 이상' ), 'radio', true ); ?></fieldset>

			<div class="wooin-form-more" id="consult-more-corporate" hidden>
				<p class="wooin-form-more-title">회사 정보</p>
				<div class="wooin-form-row">
					<label>본사 소재지<?php $regions( 'c_region', false ); ?></label>
					<label>업종<select name="c_industry"><option value="">선택</option><option>제조업</option><option>건설업</option><option>유통·도소매</option><option>IT·서비스</option><option>의료·병의원</option><option>요식·프랜차이즈</option><option>운수·물류</option><option>기타</option></select></label>
				</div>
				<div class="wooin-form-row">
					<label>최근 연 매출<select name="c_sales"><option value="">선택</option><option>10억 미만</option><option>10억~50억</option><option>50억~300억</option><option>300억 이상</option></select></label>
					<label>직원 수<select name="c_staff"><option value="">선택</option><option>5인 미만</option><option>5~29인</option><option>30~99인</option><option>100인 이상</option></select></label>
				</div>

				<p class="wooin-form-more-title">채무 현황 <small>알고 계신 범위에서 적어주세요</small></p>
				<div class="wooin-form-row">
					<label>금융기관 채무<input type="text" name="c_debt_bank" placeholder="은행·저축은행·캐피탈 예) 45억 원"></label>
					<label>거래처(상거래) 채무<input type="text" name="c_debt_trade" placeholder="미지급 대금 예) 8억 원"></label>
				</div>
				<div class="wooin-form-row">
					<label>세금 · 4대보험 체납액<input type="text" name="c_debt_tax" placeholder="예) 1억 2천만 원"></label>
					<label>기타 채무<input type="text" name="c_debt_etc" placeholder="사채·가지급금·특수관계인 등"></label>
				</div>
				<fieldset><legend>담보 · 보증 (복수 선택)</legend><?php $chips( 'c_security[]', array( '부동산 담보', '신용보증기금·기술보증기금 보증', '기계·설비 담보', '매출채권 담보', '없음' ), 'checkbox' ); ?></fieldset>
				<div class="wooin-form-row">
					<fieldset><legend>대표이사 연대보증</legend><?php $chips( 'c_guarantee', array( '있음', '없음', '모름' ) ); ?></fieldset>
					<fieldset><legend>회생·파산 신청 이력</legend><?php $chips( 'c_history', array( '없음', '있음' ) ); ?></fieldset>
				</div>

				<p class="wooin-form-more-title">현재 상태 체크리스트 <small>해당하는 항목을 모두 선택</small></p>
				<fieldset class="wooin-checklist"><legend class="screen-reader-text">현재 상태 (복수 선택)</legend><?php $chips( 'c_status[]', array( '강제집행(압류·추심) 진행 중', '부동산 경매 진행 중', '가압류 · 가처분', '세금 · 4대보험 체납', '급여 · 퇴직금 체불', '대출 만기 연장 거절 · 기한이익 상실', '어음 · 수표 부도(위기)', '주요 거래처 대금 미회수', '영업 중단 · 폐업 상태', '해당 없음' ), 'checkbox' ); ?></fieldset>
				<p class="wooin-form-more-title">기타</p>
				<label>특이사항 · 궁금한 점<textarea name="c_note" rows="3" placeholder="예) 다음 달 대출 만기 연장이 거절됐습니다. 거래처 미수금이 많습니다."></textarea></label>
				<fieldset><legend>우인을 알게 된 경로</legend><?php $chips( 'source', array( '유튜브 영상', '네이버(블로그 등)', '구글 검색', '당근마켓', '지인 소개', '기타' ) ); ?></fieldset>
			</div>
			<button type="button" class="wooin-form-more-toggle" aria-expanded="false" aria-controls="consult-more-corporate"><span>+</span> 자세히 작성하기 <small>채무 현황 · 상태 체크리스트 · 특이사항</small></button>
		</div>

		<!-- 개인회생 · 개인파산 -->
		<div role="tabpanel" id="consult-personal" aria-labelledby="consult-tab-personal" class="wooin-form-panel" hidden>
			<p class="wooin-form-lead">채무 문제는 법이 정한 절차로 정리할 수 있습니다. 소득과 채무 상황을 알려주시면 가능한 방법을 검토해 드립니다.</p>
			<div class="wooin-form-row">
				<label>성함 *<input type="text" name="p_name" autocomplete="name" required placeholder="홍길동"></label>
				<label>연락처 *<input type="tel" name="p_phone" autocomplete="tel" required placeholder="010-0000-0000"></label>
			</div>
			<div class="wooin-form-row">
				<fieldset><legend>상담 항목 *</legend><?php $chips( 'p_area', array( '개인회생', '개인파산', '아직 정하지 못함' ), 'radio', true ); ?></fieldset>
				<label>총 채무금액<input type="text" name="p_debt" placeholder="카드·대출·보증 포함 예) 8,000만 원"></label>
			</div>

			<div class="wooin-form-more" id="consult-more-personal" hidden>
				<div class="wooin-form-row">
					<label>거주 지역<?php $regions( 'p_region', false ); ?></label>
					<fieldset><legend>회생·파산 신청 이력</legend><?php $chips( 'p_history', array( '없음', '있음' ) ); ?></fieldset>
				</div>
				<fieldset><legend>소득 현황</legend><?php $chips( 'p_income', array( '무직', '급여소득(아르바이트 포함)', '사업소득', '영업소득', '기타' ) ); ?></fieldset>
				<div class="wooin-form-row">
					<label>월 평균 실수령액<input type="text" name="p_income_amount" inputmode="numeric" placeholder="예) 250만 원"></label>
					<label>재산 현황<input type="text" name="p_assets" placeholder="부동산, 자동차, 전·월세 보증금 등"></label>
				</div>
				<fieldset><legend>해당 사항 (복수 선택)</legend><?php $chips( 'p_flags[]', array( '부양 가족 있음', '지병 있음', '도박·주식·코인 등 사행성 채무' ), 'checkbox' ); ?></fieldset>
				<p class="wooin-form-more-title">기타</p>
				<label>특이사항 · 궁금한 점<textarea name="p_note" rows="3" placeholder="기재하고 싶은 사항이나 궁금한 점을 자유롭게 적어주세요."></textarea></label>
				<fieldset><legend>우인을 알게 된 경로</legend><?php $chips( 'source', array( '유튜브 영상', '네이버(블로그 등)', '구글 검색', '당근마켓', '지인 소개', '기타' ) ); ?></fieldset>
			</div>
			<button type="button" class="wooin-form-more-toggle" aria-expanded="false" aria-controls="consult-more-personal"><span>+</span> 자세히 작성하기 <small>소득 · 재산 · 신청 이력 · 특이사항</small></button>
		</div>
	</div>

	<div class="wooin-form-consent">
		<label class="wooin-form-agree"><input type="checkbox" name="agree" required> <b>[필수]</b> 개인정보 수집·이용에 동의합니다.</label>
		<p>수집 목적: 회생·파산 진행 가능 여부 확인 · 수집 항목: 성명, 연락처, 입력하신 상담 내용 · 보유 기간: 수집일로부터 1년 <a href="/privacy/">전문보기</a></p>
		<label class="wooin-form-agree"><input type="checkbox" name="agree_content"> [선택] 인적사항을 제외하고 익명화한 상담 내용을 유튜브·블로그 콘텐츠 제작에 활용하는 데 동의합니다.</label>
	</div>

	<button type="submit" class="wooin-form-submit"><span data-track-label>법인회생·파산</span> 비밀 상담 신청하기</button>
	<?php if ( $callback ) : ?>
	<p class="wooin-form-callback">※ 상담 연락은 끝자리 <b><?php echo esc_html( $callback ); ?></b> 번호로 드립니다. 모르는 번호라도 꼭 받아주세요.</p>
	<?php endif; ?>
	<p class="wooin-form-status" role="status" aria-live="polite"></p>
	<p class="wooin-mock-note">※ 시안 화면입니다. 실제 접수·알림은 다음 단계에서 연결됩니다.</p>
</form>
<!-- /wp:html -->
