<?php
/**
 * Title: 하단 고정 상담바 (변호사 프로필형)
 * Slug: wooin/bottom-bar
 * Categories: wooin
 * Inserter: no
 *
 * 왼쪽에 이서영 변호사 사진이 바 위로 솟아오르는 형태 (전송 하단바 구성 참고).
 * 전화·유튜브 주소는 wooin-core 공통정보에서 읽는다. 사진은 시안용 wooin.net 프로필 → 최종본은 배경 없는 컷아웃 PNG 로 교체.
 */
$info  = static function ( string $key, string $fallback = '' ): string {
	return function_exists( 'wooin_core_site_info' ) && '' !== wooin_core_site_info( $key ) ? wooin_core_site_info( $key ) : $fallback;
};
$phone = $info( 'phone_display', '상담 전화' );
$tel   = $info( 'phone_href', '/contact/' );
?>
<!-- wp:html -->
<nav class="wooin-bbar" aria-label="빠른 상담">
	<div class="wooin-bbar-inner">
		<div class="wooin-bbar-profile">
			<span class="wooin-bbar-photo" aria-hidden="true"></span>
			<p><small>회생·파산 9년 · 대표 변호사</small><strong>이서영 변호사</strong></p>
		</div>
		<a class="wooin-bbar-item is-phone" href="<?php echo esc_url( $tel ); ?>">
			<small>지금 바로 전화</small><strong><?php echo esc_html( $phone ); ?></strong>
		</a>
		<a class="wooin-bbar-item is-corporate" href="/contact/corporate/" data-wooin-track="corporate">
			<small>법인회생 · 법인파산</small><strong>법인 상담 신청<span class="wooin-arrow" aria-hidden="true"></span></strong>
		</a>
		<a class="wooin-bbar-item is-personal" href="/contact/personal/" data-wooin-track="personal">
			<small>개인회생 · 개인파산</small><strong>개인 상담 신청<span class="wooin-arrow" aria-hidden="true"></span></strong>
		</a>
		<a class="wooin-bbar-item is-youtube" href="<?php echo esc_url( home_url( '/videos/' ) ); ?>">
			<small>구독자 <?php echo esc_html( function_exists( 'wooin_yt_subs_label' ) ? wooin_yt_subs_label() : '' ); ?></small><strong>이서영 변호사 TV</strong>
		</a>
	</div>
</nav>
<!-- /wp:html -->
