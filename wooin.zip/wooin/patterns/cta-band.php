<?php
/**
 * Title: 서브페이지 하단 상담 띠
 * Slug: wooin/cta-band
 * Categories: wooin
 * Inserter: no
 *
 * 모든 서브페이지 템플릿 맨 아래. 전화번호는 공통정보에서 읽는다.
 */
$phone = function_exists( 'wooin_core_site_info' ) ? wooin_core_site_info( 'phone_display' ) : '';
$tel   = function_exists( 'wooin_core_site_info' ) ? wooin_core_site_info( 'phone_href' ) : '';
?>
<!-- wp:html -->
<section class="wooin-cta-band">
	<div class="wooin-cta-band-inner">
		<div>
			<p class="wooin-eyebrow is-light is-spaced">Consultation</p>
			<h2>지금 상황, 혼자 판단하지 마세요.</h2>
			<p>빚의 규모와 소득, 회사의 상황에 따라 맞는 절차가 다릅니다. 먼저 이야기를 들려주세요.</p>
		</div>
		<div class="wooin-cta-band-actions">
			<?php if ( $phone ) : ?>
			<a class="wooin-cta-phone" href="<?php echo esc_url( $tel ); ?>"><small>지금 바로 전화</small><?php echo esc_html( $phone ); ?></a>
			<?php endif; ?>
			<a class="wooin-track-cta" href="/contact/personal/">개인 상담 신청<span class="wooin-arrow" aria-hidden="true"></span></a>
			<a class="wooin-track-cta is-dark" href="/contact/corporate/">법인 상담 신청<span class="wooin-arrow" aria-hidden="true"></span></a>
		</div>
	</div>
</section>
<!-- /wp:html -->
