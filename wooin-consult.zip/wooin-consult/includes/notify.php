<?php
/**
 * 접수 알림 메일 — 구분(개인/법인)별 받는 사람.
 *
 * 메일에는 기본적으로 접수번호 · 구분 · 상담 항목 · 마스킹 이름 · 관리자 링크만 넣는다.
 * 연락처를 메일에 넣을지는 설정에서 고른다(기본 끔). 상담 원문은 메일로 보내지 않는다.
 * 알림 실패는 접수 성공과 별개 — 접수는 유지하고, 관리자 화면 「다시 보내기」와 매일 자동 재시도(3회까지).
 *
 * @package wooin-consult
 */

defined( 'ABSPATH' ) || exit;

/** 알림 보내고 결과를 접수 행에 기록. @return bool 성공 */
function wooin_consult_notify( array $row ): bool {
	$to = wooin_consult_recipients( $row['track'] );
	if ( ! $to ) {
		wooin_consult_update( (int) $row['id'], array( 'notify_status' => 'none', 'notify_error' => '받는 이메일이 설정되지 않음' ) );
		return false;
	}
	$track   = wooin_consult_tracks()[ $row['track'] ];
	$site    = function_exists( 'wooin_core_site_info' ) ? wooin_core_site_info( 'brand_name' ) : get_bloginfo( 'name' );
	$link    = admin_url( 'admin.php?page=wooin-consult&view=' . (int) $row['id'] );
	$subject = sprintf( '[%s] 새 %s 상담 %s', $site, $track[0], $row['number'] );
	$lines   = array(
		'새 상담이 접수되었습니다.',
		'',
		'접수번호: ' . $row['number'],
		'구분: ' . $track[2],
		'상담 항목: ' . ( $row['area'] ? $row['area'] : '-' ),
		'신청인: ' . wooin_consult_mask( $row['name'] ),
	);
	if ( ! empty( wooin_consult_settings()['mail_phone'] ) ) {
		$lines[] = '연락처: ' . $row['phone'];
	}
	$lines[] = '접수 시각: ' . $row['created_at'];
	$lines[] = '';
	$lines[] = '상세 내용은 관리자 화면에서 확인하세요 (로그인 필요):';
	$lines[] = $link;

	$error = '';
	$catch = static function ( WP_Error $e ) use ( &$error ): void {
		$error = $e->get_error_message();
	};
	add_action( 'wp_mail_failed', $catch );
	$ok = wp_mail( $to, $subject, implode( "\n", $lines ) );
	remove_action( 'wp_mail_failed', $catch );

	wooin_consult_update(
		(int) $row['id'],
		array(
			'notify_status' => $ok ? 'sent' : 'failed',
			'notify_tries'  => (int) $row['notify_tries'] + 1,
			'notify_at'     => current_time( 'mysql' ),
			'notify_error'  => $ok ? '' : mb_substr( $error ? $error : '메일 발송 실패', 0, 250 ),
		)
	);
	wooin_consult_log( $row, 'notify', $ok ? '알림 메일 보냄 (' . count( $to ) . '명)' : '알림 메일 실패: ' . mb_substr( $error, 0, 120 ), 0 );
	return $ok;
}

/** 실패한 알림 다시 보내기 (3회까지). */
function wooin_consult_retry_failed(): void {
	global $wpdb;
	$ids = $wpdb->get_col( 'SELECT id FROM ' . wooin_consult_table() . " WHERE notify_status = 'failed' AND notify_tries < 3 ORDER BY id LIMIT 20" ); // phpcs:ignore WordPress.DB
	foreach ( $ids as $id ) {
		$row = wooin_consult_get( (int) $id );
		if ( $row ) {
			wooin_consult_notify( $row );
		}
	}
}
