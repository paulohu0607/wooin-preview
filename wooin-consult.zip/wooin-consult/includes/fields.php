<?php
/**
 * 상담 입력 항목 · 처리 상태 · 설정.
 *
 * 항목 키는 테마 폼(patterns/consult-form.php)의 name 과 같다. 기획 v0.4 4-2절.
 * 선택지 값은 테마 폼에서 바뀔 수 있어 서버에서는 「짧은 글자」로만 받는다(목록 대조 안 함).
 *
 * @package wooin-consult
 */

defined( 'ABSPATH' ) || exit;

function wooin_consult_tracks(): array {
	return array(
		'corporate' => array( '법인', 'C', '법인회생·파산' ),
		'personal'  => array( '개인', 'P', '개인회생·파산' ),
	);
}

/**
 * 구분별 항목: 키 => [이름, 형식(text·multi·textarea·phone), 필수]
 * 이름(name)·연락처(phone)·상담 항목(area) 역할의 키는 wooin_consult_roles() 에서 지정.
 */
function wooin_consult_fields( string $track ): array {
	if ( 'corporate' === $track ) {
		return array(
			'c_company'   => array( '법인명', 'text', true ),
			'c_name'      => array( '담당자 성함 · 직책', 'text', true ),
			'c_phone'     => array( '연락처', 'phone', true ),
			'c_area'      => array( '상담 항목', 'text', true ),
			'c_debt'      => array( '부채 규모', 'text', true ),
			'c_region'    => array( '본사 소재지', 'text', false ),
			'c_industry'  => array( '업종', 'text', false ),
			'c_sales'     => array( '최근 연 매출', 'text', false ),
			'c_staff'     => array( '직원 수', 'text', false ),
			'c_debt_bank' => array( '금융기관 채무', 'text', false ),
			'c_debt_trade' => array( '거래처(상거래) 채무', 'text', false ),
			'c_debt_tax'  => array( '세금 · 4대보험 체납액', 'text', false ),
			'c_debt_etc'  => array( '기타 채무', 'text', false ),
			'c_security'  => array( '담보 · 보증', 'multi', false ),
			'c_guarantee' => array( '대표이사 연대보증', 'text', false ),
			'c_history'   => array( '회생·파산 신청 이력', 'text', false ),
			'c_status'    => array( '현재 상태', 'multi', false ),
			'c_note'      => array( '특이사항 · 궁금한 점', 'textarea', false ),
			'source'      => array( '우인을 알게 된 경로', 'text', false ),
		);
	}
	return array(
		'p_name'          => array( '성함', 'text', true ),
		'p_phone'         => array( '연락처', 'phone', true ),
		'p_area'          => array( '상담 항목', 'text', true ),
		'p_debt'          => array( '총 채무금액', 'text', false ),
		'p_region'        => array( '거주 지역', 'text', false ),
		'p_history'       => array( '회생·파산 신청 이력', 'text', false ),
		'p_income'        => array( '소득 현황', 'text', false ),
		'p_income_amount' => array( '월 평균 실수령액', 'text', false ),
		'p_assets'        => array( '재산 현황', 'text', false ),
		'p_flags'         => array( '해당 사항', 'multi', false ),
		'p_note'          => array( '특이사항 · 궁금한 점', 'textarea', false ),
		'source'          => array( '우인을 알게 된 경로', 'text', false ),
	);
}

/** 목록에 쓰는 대표 항목 키: [이름, 연락처, 상담 항목, 회사명(법인)] */
function wooin_consult_roles( string $track ): array {
	return 'corporate' === $track
		? array( 'name' => 'c_name', 'phone' => 'c_phone', 'area' => 'c_area', 'org' => 'c_company' )
		: array( 'name' => 'p_name', 'phone' => 'p_phone', 'area' => 'p_area', 'org' => '' );
}

function wooin_consult_statuses(): array {
	return array(
		'new'       => '신규',
		'checking'  => '확인 중',
		'contacted' => '연락 완료',
		'retained'  => '수임',
		'closed'    => '종결',
	);
}

/* ---------------------------------------------------------------- 설정 */

const WOOIN_CONSULT_SETTINGS = 'wooin_consult_settings';

function wooin_consult_settings(): array {
	$saved = get_option( WOOIN_CONSULT_SETTINGS, array() );
	return wp_parse_args(
		is_array( $saved ) ? $saved : array(),
		array(
			'emails_personal'  => '',
			'emails_corporate' => '',
			'mail_phone'       => false,
			'retention_days'   => 365, // 상담폼 동의 문구 「수집일로부터 1년」과 같게
			'auto_purge'       => true,
			'consent_version'  => '2026-11 (보유 1년)',
			'paused'           => false,
		)
	);
}

/**
 * 처음 받을 알림 이메일 (2026-11-06 사무소 요청 — 개인·법인 모두 두 주소로).
 * 설정 화면에서 비어 있을 때만 한 번 채운다. 이후에는 「상담 관리 › 알림 · 보관 설정」에서 바꾼다.
 */
const WOOIN_CONSULT_DEFAULT_EMAILS = 'lawyerleesy@naver.com, obin147@naver.com';

add_action(
	'init',
	static function () {
		if ( get_option( 'wooin_consult_emails_seeded' ) ) {
			return;
		}
		$s = wooin_consult_settings();
		if ( '' === trim( (string) $s['emails_personal'] ) && '' === trim( (string) $s['emails_corporate'] ) ) {
			$s['emails_personal']  = WOOIN_CONSULT_DEFAULT_EMAILS;
			$s['emails_corporate'] = WOOIN_CONSULT_DEFAULT_EMAILS;
			update_option( WOOIN_CONSULT_SETTINGS, $s, false );
		}
		update_option( 'wooin_consult_emails_seeded', time(), false );
	}
);

/** 알림 받을 이메일 목록. */
function wooin_consult_recipients( string $track ): array {
	$s    = wooin_consult_settings();
	$list = preg_split( '/[\s,;]+/', (string) ( 'corporate' === $track ? $s['emails_corporate'] : $s['emails_personal'] ) );
	return array_values( array_filter( array_map( 'sanitize_email', $list ), 'is_email' ) );
}
