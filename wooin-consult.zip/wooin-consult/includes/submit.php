<?php
/**
 * 상담 접수 받기 — POST /wp-json/wooin/v1/consult (보내기 전용, 조회 경로 없음).
 *
 * 막는 것: 자동 등록(숨은 칸·너무 빠른 제출), 같은 곳에서 연속 제출(10분 5건), 두 번 누르기(같은 키·같은 번호 5분 안 → 처음 번호를 돌려줌).
 * 응답에는 접수번호만 담고 입력 내용은 돌려주지 않는다.
 *
 * @package wooin-consult
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'rest_api_init',
	static function () {
		register_rest_route(
			'wooin/v1',
			'/consult',
			array(
				'methods'             => 'POST',
				'callback'            => 'wooin_consult_receive',
				'permission_callback' => '__return_true',
			)
		);
	}
);

// 폼 동작 스크립트 (테마의 상담폼이 있는 화면에서만 작동)
add_action(
	'wp_enqueue_scripts',
	static function () {
		wp_enqueue_script( 'wooin-consult', plugins_url( 'assets/consult.js', WOOIN_CONSULT_FILE ), array(), WOOIN_CONSULT_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );
		wp_localize_script(
			'wooin-consult',
			'wooinConsult',
			array(
				'endpoint' => esc_url_raw( rest_url( 'wooin/v1/consult' ) ),
				'paused'   => ! empty( wooin_consult_settings()['paused'] ),
				'phone'    => function_exists( 'wooin_core_site_info' ) ? wooin_core_site_info( 'phone_display' ) : '',
			)
		);
	}
);

function wooin_consult_error( string $message, int $status = 400 ): WP_REST_Response {
	return new WP_REST_Response( array( 'ok' => false, 'message' => $message ), $status );
}

function wooin_consult_receive( WP_REST_Request $req ): WP_REST_Response {
	$in       = (array) $req->get_json_params();
	$settings = wooin_consult_settings();
	$phone    = function_exists( 'wooin_core_site_info' ) ? wooin_core_site_info( 'phone_display' ) : '';
	$call     = $phone ? ' 급하시면 ' . $phone . '로 전화 주세요.' : '';

	if ( ! empty( $settings['paused'] ) ) {
		return wooin_consult_error( '지금은 온라인 상담 접수를 잠시 쉬고 있습니다.' . $call, 503 );
	}

	// 자동 등록: 사람에게는 안 보이는 칸이 채워졌으면 저장하지 않고 성공처럼 답한다
	if ( ! empty( $in['website'] ) ) {
		return new WP_REST_Response( array( 'ok' => true, 'number' => '', 'message' => '접수되었습니다.' ), 200 );
	}
	if ( (int) ( $in['elapsed'] ?? 0 ) < 3000 ) {
		return wooin_consult_error( '입력이 너무 빨리 끝났습니다. 잠시 후 다시 눌러 주세요.' );
	}

	// 연속 제출 제한 (IP 는 저장하지 않고 해시만)
	$ip_hash = hash( 'sha256', wp_salt( 'nonce' ) . ( $_SERVER['REMOTE_ADDR'] ?? '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$rate    = 'wooin_consult_rate_' . substr( $ip_hash, 0, 20 );
	$count   = (int) get_transient( $rate );
	if ( $count >= 5 ) {
		return wooin_consult_error( '짧은 시간에 여러 번 신청하셨습니다. 10분 뒤 다시 시도해 주세요.' . $call, 429 );
	}

	$track = (string) ( $in['track'] ?? '' );
	if ( ! isset( wooin_consult_tracks()[ $track ] ) ) {
		return wooin_consult_error( '상담 구분(개인/법인)을 선택해 주세요.' );
	}
	if ( empty( $in['agree'] ) ) {
		return wooin_consult_error( '개인정보 수집·이용에 동의해 주세요.' );
	}

	// 항목 정리 · 필수 확인
	$data    = array();
	$missing = array();
	foreach ( wooin_consult_fields( $track ) as $key => $f ) {
		$raw = $in[ $key ] ?? ( $in[ $key . '[]' ] ?? '' );
		switch ( $f[1] ) {
			case 'multi':
				$val = array_slice( array_values( array_filter( array_map( static fn( $v ) => mb_substr( sanitize_text_field( (string) $v ), 0, 100 ), (array) $raw ) ) ), 0, 15 );
				break;
			case 'textarea':
				$val = mb_substr( sanitize_textarea_field( (string) $raw ), 0, 3000 );
				break;
			case 'phone':
				// 휴대폰만 받는다: 010 으로 시작하는 숫자 11자리 (폼에서도 같은 규칙으로 막음)
				$val = preg_replace( '/[^0-9]/', '', (string) $raw );
				if ( '' !== $val && ! preg_match( '/^010\d{8}$/', $val ) ) {
					return wooin_consult_error( '연락처는 010으로 시작하는 휴대폰 번호 11자리로 입력해 주세요. (예: 010-1234-5678)' );
				}
				$val = wooin_consult_format_phone( $val );
				break;
			default:
				$val = mb_substr( sanitize_text_field( (string) $raw ), 0, 200 );
		}
		if ( $f[2] && ( '' === $val || array() === $val ) ) {
			$missing[] = $f[0];
		}
		if ( '' !== $val && array() !== $val ) {
			$data[ $key ] = $val;
		}
	}
	if ( $missing ) {
		return wooin_consult_error( '필수 항목을 입력해 주세요: ' . implode( ', ', $missing ) );
	}

	$roles = wooin_consult_roles( $track );
	$idem  = preg_replace( '/[^A-Za-z0-9-]/', '', (string) ( $in['idem'] ?? '' ) );
	$idem  = substr( $idem, 0, 64 );

	// 두 번 누르기 · 바로 다시 보내기 → 처음 접수번호를 돌려준다
	global $wpdb;
	$dup = $wpdb->get_row( // phpcs:ignore WordPress.DB
		$wpdb->prepare(
			'SELECT id, number FROM ' . wooin_consult_table() . ' WHERE ( idem_key <> %s AND idem_key = %s ) OR ( track = %s AND phone = %s AND created_at > %s ) ORDER BY id DESC LIMIT 1', // phpcs:ignore WordPress.DB
			'',
			$idem,
			$track,
			$data[ $roles['phone'] ],
			wp_date( 'Y-m-d H:i:s', time() - 5 * MINUTE_IN_SECONDS )
		),
		ARRAY_A
	);
	if ( $dup ) {
		return new WP_REST_Response( array( 'ok' => true, 'number' => $dup['number'], 'message' => wooin_consult_thanks( $dup['number'] ) ), 200 );
	}

	$row = wooin_consult_insert(
		array(
			'track'           => $track,
			'mode'            => 'detail' === ( $in['mode'] ?? '' ) ? 'detail' : 'simple',
			'status'          => 'new',
			'name'            => trim( ( $roles['org'] && ! empty( $data[ $roles['org'] ] ) ? $data[ $roles['org'] ] . ' · ' : '' ) . $data[ $roles['name'] ] ),
			'phone'           => $data[ $roles['phone'] ],
			'area'            => $data[ $roles['area'] ] ?? '',
			'data'            => wp_json_encode( $data, JSON_UNESCAPED_UNICODE ),
			'consent_version' => (string) $settings['consent_version'],
			'source_page'     => mb_substr( esc_url_raw( (string) ( $in['page'] ?? '' ) ), 0, 250 ),
			'referrer'        => mb_substr( esc_url_raw( (string) ( $in['ref'] ?? '' ) ), 0, 250 ),
			'ip_hash'         => $ip_hash,
			'idem_key'        => $idem,
		)
	);
	if ( is_wp_error( $row ) ) {
		return wooin_consult_error( '접수 중 문제가 생겼습니다. 잠시 후 다시 시도해 주세요.' . $call, 500 );
	}
	set_transient( $rate, $count + 1, 10 * MINUTE_IN_SECONDS );
	wooin_consult_log( $row, 'create', '홈페이지 접수 (' . ( 'detail' === $row['mode'] ? '자세히' : '간단히' ) . ')', 0 );

	// 알림 실패해도 접수는 성공
	wooin_consult_notify( $row );

	return new WP_REST_Response( array( 'ok' => true, 'number' => $row['number'], 'message' => wooin_consult_thanks( $row['number'] ) ), 201 );
}

function wooin_consult_thanks( string $number ): string {
	return '접수번호는 ' . $number . '입니다. 확인 후 빠르게 연락드리겠습니다.';
}

function wooin_consult_format_phone( string $digits ): string {
	if ( preg_match( '/^(02)(\d{3,4})(\d{4})$/', $digits, $m ) || preg_match( '/^(0\d{2})(\d{3,4})(\d{4})$/', $digits, $m ) ) {
		return $m[1] . '-' . $m[2] . '-' . $m[3];
	}
	return $digits;
}
