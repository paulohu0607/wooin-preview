<?php
/**
 * 상담 저장소 — 전용 표, 접수번호, 열람 권한, 기록, 보유기간 삭제.
 *
 * @package wooin-consult
 */

defined( 'ABSPATH' ) || exit;

function wooin_consult_table( string $which = 'main' ): string {
	global $wpdb;
	return $wpdb->prefix . ( 'log' === $which ? 'wooin_inquiry_log' : 'wooin_inquiries' );
}

function wooin_consult_install(): void {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$charset = $wpdb->get_charset_collate();
	$main    = wooin_consult_table();
	$log     = wooin_consult_table( 'log' );

	dbDelta(
		"CREATE TABLE {$main} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			number varchar(20) NOT NULL,
			track varchar(12) NOT NULL,
			mode varchar(8) NOT NULL DEFAULT 'simple',
			status varchar(12) NOT NULL DEFAULT 'new',
			assignee bigint(20) unsigned NOT NULL DEFAULT 0,
			name varchar(120) NOT NULL DEFAULT '',
			phone varchar(30) NOT NULL DEFAULT '',
			area varchar(60) NOT NULL DEFAULT '',
			data longtext NOT NULL,
			consent_version varchar(60) NOT NULL DEFAULT '',
			consent_content tinyint(1) NOT NULL DEFAULT 0,
			source_page varchar(255) NOT NULL DEFAULT '',
			referrer varchar(255) NOT NULL DEFAULT '',
			ip_hash char(64) NOT NULL DEFAULT '',
			idem_key varchar(64) NOT NULL DEFAULT '',
			notify_status varchar(12) NOT NULL DEFAULT 'pending',
			notify_tries smallint(5) unsigned NOT NULL DEFAULT 0,
			notify_at datetime NULL DEFAULT NULL,
			notify_error varchar(255) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY number (number),
			KEY idem_key (idem_key),
			KEY track_status (track,status),
			KEY created_at (created_at)
		) {$charset};"
	);
	dbDelta(
		"CREATE TABLE {$log} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			inquiry_id bigint(20) unsigned NOT NULL,
			number varchar(20) NOT NULL DEFAULT '',
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			action varchar(20) NOT NULL,
			detail text NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY inquiry_id (inquiry_id)
		) {$charset};"
	);
	update_option( 'wooin_consult_db', WOOIN_CONSULT_DB, false );
}

/* ---------------------------------------------------------------- 권한 */

function wooin_consult_can_view( string $track ): bool {
	return in_array( $track, array( 'personal', 'corporate' ), true ) && current_user_can( 'wooin_view_inquiries_' . $track );
}

/** 현재 사용자가 볼 수 있는 구분 목록. */
function wooin_consult_visible_tracks(): array {
	return array_values( array_filter( array_keys( wooin_consult_tracks() ), 'wooin_consult_can_view' ) );
}

function wooin_consult_can_any(): bool {
	return (bool) wooin_consult_visible_tracks();
}

/* ---------------------------------------------------------------- 저장 · 조회 */

/** 다음 접수번호 (예: C-2026-0007). 같은 번호가 이미 있으면 insert 가 실패하므로 호출부에서 재시도. */
function wooin_consult_next_number( string $track ): string {
	global $wpdb;
	$prefix = wooin_consult_tracks()[ $track ][1] . '-' . wp_date( 'Y' ) . '-';
	$last   = $wpdb->get_var( $wpdb->prepare( 'SELECT number FROM ' . wooin_consult_table() . ' WHERE number LIKE %s ORDER BY id DESC LIMIT 1', $wpdb->esc_like( $prefix ) . '%' ) ); // phpcs:ignore WordPress.DB
	$seq    = $last ? (int) substr( $last, strlen( $prefix ) ) + 1 : 1;
	return $prefix . str_pad( (string) $seq, 4, '0', STR_PAD_LEFT );
}

/**
 * 접수 저장.
 *
 * @return array|WP_Error 저장된 행.
 */
function wooin_consult_insert( array $row ) {
	global $wpdb;
	$now = current_time( 'mysql' );
	for ( $try = 0; $try < 5; $try++ ) {
		$row['number']     = wooin_consult_next_number( $row['track'] );
		$row['created_at'] = $now;
		$row['updated_at'] = $now;
		$wpdb->suppress_errors( true );
		$ok = $wpdb->insert( wooin_consult_table(), $row ); // phpcs:ignore WordPress.DB
		$wpdb->suppress_errors( false );
		if ( $ok ) {
			return wooin_consult_get( (int) $wpdb->insert_id );
		}
	}
	return new WP_Error( 'wooin_consult_save', '저장하지 못했습니다.' );
}

function wooin_consult_get( int $id ): ?array {
	global $wpdb;
	$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wooin_consult_table() . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore WordPress.DB
	if ( ! $row ) {
		return null;
	}
	$row['data'] = json_decode( (string) $row['data'], true ) ?: array();
	return $row;
}

function wooin_consult_update( int $id, array $fields ): void {
	global $wpdb;
	$fields['updated_at'] = current_time( 'mysql' );
	$wpdb->update( wooin_consult_table(), $fields, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB
}

/**
 * 목록 조회 — 볼 수 있는 구분만.
 *
 * @param array $q track · status · s(접수번호/연락처 끝자리) · from · to · page · per.
 * @return array{rows: array, total: int}
 */
function wooin_consult_query( array $q ): array {
	global $wpdb;
	$tracks = wooin_consult_visible_tracks();
	if ( ! empty( $q['track'] ) ) {
		$tracks = array_intersect( $tracks, array( $q['track'] ) );
	}
	if ( ! $tracks ) {
		return array( 'rows' => array(), 'total' => 0 );
	}
	$where = array( "track IN ('" . implode( "','", array_map( 'esc_sql', $tracks ) ) . "')" );
	$args  = array();
	if ( ! empty( $q['status'] ) ) {
		$where[] = 'status = %s';
		$args[]  = $q['status'];
	}
	if ( ! empty( $q['assignee'] ) ) {
		$where[] = 'assignee = %d';
		$args[]  = (int) $q['assignee'];
	}
	if ( ! empty( $q['s'] ) ) {
		$s = trim( $q['s'] );
		if ( preg_match( '/^\d{4}$/', $s ) ) {
			$where[] = 'phone LIKE %s';
			$args[]  = '%' . $wpdb->esc_like( $s );
		} else {
			$where[] = 'number LIKE %s';
			$args[]  = '%' . $wpdb->esc_like( strtoupper( $s ) ) . '%';
		}
	}
	if ( ! empty( $q['from'] ) ) {
		$where[] = 'created_at >= %s';
		$args[]  = $q['from'] . ' 00:00:00';
	}
	if ( ! empty( $q['to'] ) ) {
		$where[] = 'created_at <= %s';
		$args[]  = $q['to'] . ' 23:59:59';
	}
	$sql_where = 'WHERE ' . implode( ' AND ', $where );
	$per       = max( 1, (int) ( $q['per'] ?? 30 ) );
	$offset    = max( 0, ( (int) ( $q['page'] ?? 1 ) - 1 ) * $per );
	$table     = wooin_consult_table();
	$prep      = static fn( string $sql ) => $args ? $wpdb->prepare( $sql, $args ) : $sql; // phpcs:ignore WordPress.DB
	$total     = (int) $wpdb->get_var( $prep( "SELECT COUNT(*) FROM {$table} {$sql_where}" ) ); // phpcs:ignore WordPress.DB
	$rows      = $wpdb->get_results( $prep( "SELECT id, number, track, mode, status, assignee, name, phone, area, notify_status, created_at FROM {$table} {$sql_where} ORDER BY id DESC LIMIT {$per} OFFSET {$offset}" ), ARRAY_A ); // phpcs:ignore WordPress.DB
	return array( 'rows' => $rows ? $rows : array(), 'total' => $total );
}

/** 구분별·상태별 개수 (볼 수 있는 구분만). */
function wooin_consult_counts(): array {
	global $wpdb;
	$out = array();
	foreach ( wooin_consult_visible_tracks() as $track ) {
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT status, COUNT(*) n FROM ' . wooin_consult_table() . ' WHERE track = %s GROUP BY status', $track ), ARRAY_A ); // phpcs:ignore WordPress.DB
		foreach ( (array) $rows as $r ) {
			$out[ $track ][ $r['status'] ] = (int) $r['n'];
		}
	}
	return $out;
}

/* ---------------------------------------------------------------- 기록 */

/** 기록 — detail 에는 상담 원문을 넣지 않는다 (상태명·담당자명·메모처럼 직원이 쓴 것만). */
function wooin_consult_log( array $row, string $action, string $detail = '', int $user = -1 ): void {
	global $wpdb;
	$wpdb->insert( // phpcs:ignore WordPress.DB
		wooin_consult_table( 'log' ),
		array(
			'inquiry_id' => (int) $row['id'],
			'number'     => (string) $row['number'],
			'user_id'    => $user >= 0 ? $user : get_current_user_id(),
			'action'     => $action,
			'detail'     => $detail,
			'created_at' => current_time( 'mysql' ),
		)
	);
}

function wooin_consult_logs( int $id ): array {
	global $wpdb;
	return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . wooin_consult_table( 'log' ) . ' WHERE inquiry_id = %d ORDER BY id DESC', $id ), ARRAY_A ); // phpcs:ignore WordPress.DB
}

/* ---------------------------------------------------------------- 삭제 */

function wooin_consult_delete( array $row, string $why ): void {
	global $wpdb;
	$wpdb->delete( wooin_consult_table(), array( 'id' => (int) $row['id'] ) ); // phpcs:ignore WordPress.DB
	wooin_consult_log( $row, 'delete', $why );
}

/** 보유기간이 지난 접수 삭제 (설정에서 끄면 하지 않음). @return int 삭제 수 */
function wooin_consult_purge_expired(): int {
	global $wpdb;
	$s = wooin_consult_settings();
	if ( empty( $s['auto_purge'] ) || (int) $s['retention_days'] < 1 ) {
		return 0;
	}
	$cut  = wp_date( 'Y-m-d H:i:s', time() - (int) $s['retention_days'] * DAY_IN_SECONDS );
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, number FROM ' . wooin_consult_table() . ' WHERE created_at < %s', $cut ), ARRAY_A ); // phpcs:ignore WordPress.DB
	foreach ( (array) $rows as $r ) {
		wooin_consult_delete( $r, '보유기간(' . (int) $s['retention_days'] . '일) 경과 자동 삭제' );
	}
	return count( (array) $rows );
}

/* ---------------------------------------------------------------- 표시 도우미 */

/** 홍길동 → 홍*동, 홍길 → 홍*, ㈜우인산업 → ㈜우**업. 「회사 · 담당자」는 각각, 「박대표 대표이사」는 이름만 가린다. */
function wooin_consult_mask( string $text ): string {
	if ( str_contains( $text, ' · ' ) ) {
		return implode( ' · ', array_map( 'wooin_consult_mask', explode( ' · ', $text ) ) );
	}
	$text = trim( $text );
	$lead = '';
	if ( preg_match( '/^(㈜|\(주\)|주식회사)\s*(.+)$/u', $text, $m ) ) {
		$lead = '㈜';
		$text = $m[2];
	} elseif ( preg_match( '/^(\S+)\s+(.+)$/u', $text, $m ) && mb_strlen( $m[1] ) <= 5 ) {
		return wooin_consult_mask( $m[1] ) . ' ' . $m[2];
	}
	$chars = preg_split( '//u', $text, -1, PREG_SPLIT_NO_EMPTY );
	$n     = count( $chars );
	if ( $n <= 1 ) {
		return $lead . $text;
	}
	if ( 2 === $n ) {
		return $lead . $chars[0] . '*';
	}
	return $lead . $chars[0] . str_repeat( '*', min( $n - 2, 4 ) ) . $chars[ $n - 1 ];
}
