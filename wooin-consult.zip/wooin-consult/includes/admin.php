<?php
/**
 * 상담 관리 화면 — 목록(본문 없음) · 상세(원본 읽기 전용 + 처리) · 설정.
 *
 * 모든 화면·처리는 구분별 열람 권한(wooin_view_inquiries_personal/_corporate)을 다시 확인한다.
 * 상세를 열 때마다 「열람」 기록을 남긴다.
 *
 * @package wooin-consult
 */

defined( 'ABSPATH' ) || exit;

/* ---------------------------------------------------------------- 메뉴 */

add_action(
	'admin_menu',
	static function () {
		if ( ! wooin_consult_can_any() && ! current_user_can( 'wooin_inquiry_settings' ) ) {
			return;
		}
		$new    = wooin_consult_new_count();
		$bubble = $new ? ' <span class="awaiting-mod count-' . $new . '"><span class="pending-count">' . $new . '</span></span>' : '';
		add_menu_page( '상담 관리', '상담 관리' . $bubble, 'read', 'wooin-consult', 'wooin_consult_render_page', 'dashicons-email-alt', 3 );
		add_submenu_page( 'wooin-consult', '상담 목록', '상담 목록', 'read', 'wooin-consult', 'wooin_consult_render_page' );
		add_submenu_page( 'wooin-consult', '상담 설정', '알림 · 보관 설정', 'wooin_inquiry_settings', 'wooin-consult-settings', 'wooin_consult_render_settings' );
	}
);

function wooin_consult_new_count(): int {
	$n = 0;
	foreach ( wooin_consult_counts() as $by_status ) {
		$n += (int) ( $by_status['new'] ?? 0 );
	}
	return $n;
}

// 운영 홈(wooin-core)에 버튼 · 확인할 일
add_filter(
	'wooin_admin_quick',
	static function ( array $quick ): array {
		if ( wooin_consult_can_any() ) {
			array_unshift( $quick, array( '상담 관리', 'dashicons-email-alt', admin_url( 'admin.php?page=wooin-consult' ) ) );
		}
		return $quick;
	}
);
add_filter(
	'wooin_admin_todo',
	static function ( array $todo ): array {
		foreach ( wooin_consult_counts() as $track => $by_status ) {
			if ( ! empty( $by_status['new'] ) ) {
				array_unshift( $todo, array( '새 ' . wooin_consult_tracks()[ $track ][0] . ' 상담 ' . $by_status['new'] . '건', admin_url( 'admin.php?page=wooin-consult&track=' . $track . '&status=new' ), 'warn' ) );
			}
		}
		if ( wooin_consult_can_any() ) {
			global $wpdb;
			$failed = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . wooin_consult_table() . " WHERE notify_status = 'failed'" ); // phpcs:ignore WordPress.DB
			if ( $failed ) {
				$todo[] = array( '상담 알림 메일 실패 ' . $failed . '건', admin_url( 'admin.php?page=wooin-consult' ), 'warn' );
			}
		}
		if ( current_user_can( 'wooin_inquiry_settings' ) && ( ! wooin_consult_recipients( 'personal' ) || ! wooin_consult_recipients( 'corporate' ) ) ) {
			$todo[] = array( '상담 알림 받을 이메일을 설정하세요', admin_url( 'admin.php?page=wooin-consult-settings' ), 'warn' );
		}
		return $todo;
	}
);

add_action(
	'admin_enqueue_scripts',
	static function () {
		$screen = get_current_screen();
		if ( $screen && str_contains( $screen->id, 'wooin-consult' ) ) {
			wp_enqueue_style( 'wooin-consult-admin', plugins_url( 'assets/admin.css', WOOIN_CONSULT_FILE ), array(), WOOIN_CONSULT_VERSION );
		}
	}
);

/* ---------------------------------------------------------------- 처리 (상태 · 담당자 · 메모 · 알림 · 삭제) */

add_action(
	'admin_post_wooin_consult_action',
	static function () {
		$id  = absint( $_POST['id'] ?? 0 );
		$row = $id ? wooin_consult_get( $id ) : null;
		if ( ! $row || ! wooin_consult_can_view( $row['track'] ) ) {
			wp_die( '이 상담을 볼 권한이 없습니다.', 403 );
		}
		check_admin_referer( 'wooin_consult_' . $id );
		$do   = sanitize_key( wp_unslash( $_POST['do'] ?? '' ) );
		$back = admin_url( 'admin.php?page=wooin-consult&view=' . $id );

		if ( 'delete' === $do ) {
			if ( ! current_user_can( 'wooin_delete_inquiries' ) ) {
				wp_die( '삭제 권한이 없습니다.', 403 );
			}
			wooin_consult_delete( $row, '직원 삭제' );
			wp_safe_redirect( admin_url( 'admin.php?page=wooin-consult&notice=deleted' ) );
			exit;
		}
		if ( 'notify' === $do ) {
			$ok = wooin_consult_notify( $row );
			wp_safe_redirect( add_query_arg( 'notice', $ok ? 'notified' : 'notify_failed', $back ) );
			exit;
		}
		if ( ! current_user_can( 'wooin_manage_inquiries' ) ) {
			wp_die( '처리 권한이 없습니다.', 403 );
		}

		$statuses = wooin_consult_statuses();
		$status   = sanitize_key( wp_unslash( $_POST['status'] ?? '' ) );
		if ( isset( $statuses[ $status ] ) && $status !== $row['status'] ) {
			wooin_consult_update( $id, array( 'status' => $status ) );
			wooin_consult_log( $row, 'status', $statuses[ $row['status'] ] . ' → ' . $statuses[ $status ] );
		}
		$assignee = absint( $_POST['assignee'] ?? 0 );
		if ( $assignee !== (int) $row['assignee'] ) {
			if ( $assignee && ! user_can( $assignee, 'wooin_view_inquiries_' . $row['track'] ) ) {
				wp_die( '그 직원은 이 구분의 상담을 볼 권한이 없습니다.' );
			}
			wooin_consult_update( $id, array( 'assignee' => $assignee ) );
			$user = $assignee ? get_userdata( $assignee ) : null;
			wooin_consult_log( $row, 'assign', $user ? '담당자: ' . $user->display_name : '담당자 해제' );
		}
		$memo = trim( sanitize_textarea_field( wp_unslash( $_POST['memo'] ?? '' ) ) );
		if ( '' !== $memo ) {
			wooin_consult_log( $row, 'memo', mb_substr( $memo, 0, 2000 ) );
		}
		wp_safe_redirect( add_query_arg( 'notice', 'saved', $back ) );
		exit;
	}
);

/* ---------------------------------------------------------------- 화면 */

function wooin_consult_render_page(): void {
	if ( ! wooin_consult_can_any() ) {
		echo '<div class="wrap"><h1>상담 관리</h1><p>상담을 볼 권한이 없습니다. 운영 책임자에게 「상담 담당자」 권한을 요청하세요.</p></div>';
		return;
	}
	$view = absint( $_GET['view'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( $view ) {
		wooin_consult_render_detail( $view );
		return;
	}
	wooin_consult_render_list();
}

function wooin_consult_header( string $title, string $desc ): void {
	if ( function_exists( 'wooin_admin_header' ) ) {
		wooin_admin_header( $title, $desc );
	} else {
		printf( '<h1>%s</h1><p>%s</p>', esc_html( $title ), esc_html( $desc ) );
	}
}

function wooin_consult_status_badge( string $status ): string {
	$label = wooin_consult_statuses()[ $status ] ?? $status;
	return '<span class="wc-badge is-' . esc_attr( $status ) . '">' . esc_html( $label ) . '</span>';
}

function wooin_consult_notify_badge( string $status ): string {
	$map = array( 'sent' => array( '보냄', 'ok' ), 'failed' => array( '실패', 'bad' ), 'none' => array( '받는 사람 없음', 'bad' ), 'pending' => array( '대기', '' ) );
	$m   = $map[ $status ] ?? array( $status, '' );
	return '<span class="wc-notify is-' . esc_attr( $m[1] ) . '">' . esc_html( $m[0] ) . '</span>';
}

function wooin_consult_render_list(): void {
	// phpcs:disable WordPress.Security.NonceVerification
	$q = array(
		'track'    => sanitize_key( wp_unslash( $_GET['track'] ?? '' ) ),
		'status'   => sanitize_key( wp_unslash( $_GET['status'] ?? '' ) ),
		'assignee' => absint( $_GET['assignee'] ?? 0 ),
		's'        => sanitize_text_field( wp_unslash( $_GET['s'] ?? '' ) ),
		'from'     => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $_GET['from'] ?? '' ) ) ? $_GET['from'] : '',
		'to'       => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $_GET['to'] ?? '' ) ) ? $_GET['to'] : '',
		'page'     => max( 1, absint( $_GET['paged'] ?? 1 ) ),
		'per'      => 30,
	);
	$notice = sanitize_key( wp_unslash( $_GET['notice'] ?? '' ) );
	// phpcs:enable
	$result  = wooin_consult_query( $q );
	$tracks  = wooin_consult_tracks();
	$visible = wooin_consult_visible_tracks();
	$counts  = wooin_consult_counts();
	$base    = admin_url( 'admin.php?page=wooin-consult' );
	$link    = static fn( array $over ) => esc_url( add_query_arg( array_filter( array_merge( array( 'track' => $q['track'], 'status' => $q['status'] ), $over ) ), $base ) );
	?>
	<div class="wrap wooin-admin wooin-consult">
		<?php wooin_consult_header( '상담 관리', '홈페이지로 들어온 상담 신청입니다. 목록에는 내용이 나오지 않으며, 접수번호를 눌러 상세를 확인합니다. 열람은 기록됩니다.' ); ?>
		<?php if ( 'deleted' === $notice ) : ?><div class="notice notice-success is-dismissible"><p>삭제했습니다.</p></div><?php endif; ?>

		<div class="wc-summary">
			<?php foreach ( $visible as $t ) : ?>
				<?php $c = $counts[ $t ] ?? array(); ?>
				<a class="wc-sum<?php echo $q['track'] === $t ? ' is-active' : ''; ?>" href="<?php echo $link( array( 'track' => $t, 'status' => '' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>">
					<span><?php echo esc_html( $tracks[ $t ][2] ); ?></span>
					<b><?php echo (int) array_sum( $c ); ?>건</b>
					<?php if ( ! empty( $c['new'] ) ) : ?><em>새 상담 <?php echo (int) $c['new']; ?></em><?php endif; ?>
				</a>
			<?php endforeach; ?>
		</div>

		<ul class="subsubsub">
			<li><a href="<?php echo $link( array( 'track' => $q['track'], 'status' => '' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" class="<?php echo '' === $q['status'] ? 'current' : ''; ?>">전체</a> |</li>
			<?php foreach ( wooin_consult_statuses() as $key => $label ) : ?>
				<li><a href="<?php echo $link( array( 'status' => $key ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" class="<?php echo $key === $q['status'] ? 'current' : ''; ?>"><?php echo esc_html( $label ); ?></a><?php echo 'closed' !== $key ? ' |' : ''; ?></li>
			<?php endforeach; ?>
		</ul>

		<form method="get" class="wc-filter">
			<input type="hidden" name="page" value="wooin-consult">
			<?php if ( count( $visible ) > 1 ) : ?>
			<select name="track"><option value="">개인 · 법인 전체</option><?php foreach ( $visible as $t ) : ?><option value="<?php echo esc_attr( $t ); ?>" <?php selected( $q['track'], $t ); ?>><?php echo esc_html( $tracks[ $t ][0] ); ?></option><?php endforeach; ?></select>
			<?php endif; ?>
			<select name="status"><option value="">모든 상태</option><?php foreach ( wooin_consult_statuses() as $k => $l ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $q['status'], $k ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select>
			<select name="assignee"><option value="0">모든 담당자</option><option value="<?php echo (int) get_current_user_id(); ?>" <?php selected( $q['assignee'], get_current_user_id() ); ?>>내 담당</option></select>
			<label>기간 <input type="date" name="from" value="<?php echo esc_attr( $q['from'] ); ?>"> ~ <input type="date" name="to" value="<?php echo esc_attr( $q['to'] ); ?>"></label>
			<input type="search" name="s" value="<?php echo esc_attr( $q['s'] ); ?>" placeholder="접수번호 또는 전화 끝 4자리">
			<button class="button">찾기</button>
			<?php if ( array_filter( array( $q['status'], $q['assignee'], $q['s'], $q['from'], $q['to'] ) ) ) : ?><a class="button-link" href="<?php echo esc_url( $base ); ?>">조건 지우기</a><?php endif; ?>
		</form>

		<table class="widefat striped wc-table">
			<thead><tr><th>접수번호</th><th>접수 시각</th><th>구분</th><th>상담 항목</th><th>신청인</th><th>담당자</th><th>상태</th><th>알림</th></tr></thead>
			<tbody>
			<?php if ( ! $result['rows'] ) : ?>
				<tr><td colspan="8" class="wc-empty">조건에 맞는 상담이 없습니다.</td></tr>
			<?php endif; ?>
			<?php foreach ( $result['rows'] as $r ) : ?>
				<?php $user = $r['assignee'] ? get_userdata( (int) $r['assignee'] ) : null; ?>
				<tr class="<?php echo 'new' === $r['status'] ? 'is-new' : ''; ?>">
					<td><a class="wc-number" href="<?php echo esc_url( add_query_arg( 'view', (int) $r['id'], $base ) ); ?>"><?php echo esc_html( $r['number'] ); ?></a></td>
					<td><?php echo esc_html( substr( $r['created_at'], 0, 16 ) ); ?></td>
					<td><span class="wc-track is-<?php echo esc_attr( $r['track'] ); ?>"><?php echo esc_html( $tracks[ $r['track'] ][0] ); ?></span></td>
					<td><?php echo esc_html( $r['area'] ); ?></td>
					<td><?php echo esc_html( wooin_consult_mask( $r['name'] ) ); ?></td>
					<td><?php echo $user ? esc_html( $user->display_name ) : '<span class="wc-muted">미배정</span>'; ?></td>
					<td><?php echo wooin_consult_status_badge( $r['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
					<td><?php echo wooin_consult_notify_badge( $r['notify_status'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		$pages = (int) ceil( $result['total'] / $q['per'] );
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $q['page'], 'total' => $pages ) ) ) . '</div></div>';
		}
		?>
		<p class="description">상담 내용은 공개 화면·검색·사이트맵에 나오지 않습니다. 보유기간(<?php echo (int) wooin_consult_settings()['retention_days']; ?>일)이 지난 상담은 <?php echo wooin_consult_settings()['auto_purge'] ? '매일 자동으로 삭제됩니다' : '자동 삭제가 꺼져 있습니다'; ?>.</p>
	</div>
	<?php
}

function wooin_consult_render_detail( int $id ): void {
	$row = wooin_consult_get( $id );
	if ( ! $row || ! wooin_consult_can_view( $row['track'] ) ) {
		echo '<div class="wrap"><h1>상담 관리</h1><p>상담을 찾을 수 없거나 볼 권한이 없습니다.</p></div>';
		return;
	}
	wooin_consult_log( $row, 'view' );
	$tracks   = wooin_consult_tracks();
	$fields   = wooin_consult_fields( $row['track'] );
	$can_edit = current_user_can( 'wooin_manage_inquiries' );
	$notice   = sanitize_key( wp_unslash( $_GET['notice'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$messages = array( 'saved' => '저장했습니다.', 'notified' => '알림 메일을 다시 보냈습니다.', 'notify_failed' => '알림 메일을 보내지 못했습니다. 설정과 메일 발송(WP Mail SMTP)을 확인하세요.' );
	$staff    = get_users( array( 'capability' => 'wooin_view_inquiries_' . $row['track'], 'fields' => array( 'ID', 'display_name' ) ) );
	$actions  = array( 'create' => '접수', 'view' => '열람', 'status' => '상태', 'assign' => '배정', 'memo' => '메모', 'notify' => '알림', 'delete' => '삭제' );
	?>
	<div class="wrap wooin-admin wooin-consult">
		<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=wooin-consult' ) ); ?>">← 상담 목록</a></p>
		<?php wooin_consult_header( $row['number'] . ' · ' . $tracks[ $row['track'] ][2], '접수 ' . substr( $row['created_at'], 0, 16 ) . ' · ' . ( 'detail' === $row['mode'] ? '자세히 작성' : '간단히 작성' ) ); ?>
		<?php if ( isset( $messages[ $notice ] ) ) : ?><div class="notice notice-<?php echo 'notify_failed' === $notice ? 'error' : 'success'; ?> is-dismissible"><p><?php echo esc_html( $messages[ $notice ] ); ?></p></div><?php endif; ?>

		<div class="wc-detail">
			<div>
				<div class="wooin-card">
					<h3>신청 내용 <small>읽기 전용 · 신청인이 입력한 그대로</small></h3>
					<table class="wc-fields"><tbody>
					<?php foreach ( $fields as $key => $f ) : ?>
						<?php
						if ( ! isset( $row['data'][ $key ] ) ) {
							continue;
						}
						$v = $row['data'][ $key ];
						?>
						<tr><th><?php echo esc_html( $f[0] ); ?></th><td>
							<?php if ( 'phone' === $f[1] ) : ?>
								<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9]/', '', $v ) ); ?>" class="wc-phone"><?php echo esc_html( $v ); ?></a>
							<?php elseif ( is_array( $v ) ) : ?>
								<?php echo esc_html( implode( ' · ', $v ) ); ?>
							<?php else : ?>
								<?php echo nl2br( esc_html( $v ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<?php endif; ?>
						</td></tr>
					<?php endforeach; ?>
					</tbody></table>
				</div>
				<div class="wooin-card">
					<h3>동의 · 유입</h3>
					<table class="wc-fields"><tbody>
						<tr><th>개인정보 수집·이용</th><td>동의 · 문구 버전 <?php echo esc_html( $row['consent_version'] ); ?> · <?php echo esc_html( substr( $row['created_at'], 0, 16 ) ); ?></td></tr>
						<tr><th>신청한 페이지</th><td><?php echo esc_html( $row['source_page'] ? wp_parse_url( $row['source_page'], PHP_URL_PATH ) : '-' ); ?></td></tr>
						<tr><th>들어온 곳</th><td><?php echo esc_html( $row['referrer'] ? (string) wp_parse_url( $row['referrer'], PHP_URL_HOST ) : '직접 방문 / 알 수 없음' ); ?></td></tr>
					</tbody></table>
				</div>
			</div>

			<div>
				<form class="wooin-card" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<h3>처리</h3>
					<input type="hidden" name="action" value="wooin_consult_action">
					<input type="hidden" name="id" value="<?php echo (int) $row['id']; ?>">
					<?php wp_nonce_field( 'wooin_consult_' . $row['id'] ); ?>
					<p><label>상태<br><select name="status" <?php disabled( ! $can_edit ); ?>><?php foreach ( wooin_consult_statuses() as $k => $l ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $row['status'], $k ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></label></p>
					<p><label>담당자<br><select name="assignee" <?php disabled( ! $can_edit ); ?>><option value="0">미배정</option><?php foreach ( $staff as $u ) : ?><option value="<?php echo (int) $u->ID; ?>" <?php selected( (int) $row['assignee'], (int) $u->ID ); ?>><?php echo esc_html( $u->display_name ); ?></option><?php endforeach; ?></select></label></p>
					<p><label>내부 메모 추가 <small>(신청인에게 보이지 않음)</small><br><textarea name="memo" rows="3" class="large-text" placeholder="예) 11/4 14시 통화, 서류 안내함" <?php disabled( ! $can_edit ); ?>></textarea></label></p>
					<?php if ( $can_edit ) : ?><button class="button button-primary" name="do" value="save">저장</button><?php endif; ?>
				</form>

				<form class="wooin-card" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<h3>알림 메일</h3>
					<input type="hidden" name="action" value="wooin_consult_action">
					<input type="hidden" name="id" value="<?php echo (int) $row['id']; ?>">
					<?php wp_nonce_field( 'wooin_consult_' . $row['id'] ); ?>
					<p><?php echo wooin_consult_notify_badge( $row['notify_status'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php echo $row['notify_at'] ? esc_html( ' ' . substr( $row['notify_at'], 0, 16 ) . ' · ' . (int) $row['notify_tries'] . '회 시도' ) : ''; ?></p>
					<?php if ( $row['notify_error'] ) : ?><p class="wc-error"><?php echo esc_html( $row['notify_error'] ); ?></p><?php endif; ?>
					<button class="button" name="do" value="notify">알림 다시 보내기</button>
				</form>

				<div class="wooin-card">
					<h3>기록</h3>
					<ul class="wc-log">
					<?php foreach ( wooin_consult_logs( (int) $row['id'] ) as $l ) : ?>
						<?php $u = $l['user_id'] ? get_userdata( (int) $l['user_id'] ) : null; ?>
						<li class="is-<?php echo esc_attr( $l['action'] ); ?>"><time><?php echo esc_html( substr( $l['created_at'], 5, 11 ) ); ?></time> <b><?php echo esc_html( $actions[ $l['action'] ] ?? $l['action'] ); ?></b> <?php echo esc_html( $u ? $u->display_name : '시스템' ); ?><?php echo $l['detail'] ? '<span>' . nl2br( esc_html( $l['detail'] ) ) . '</span>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput ?></li>
					<?php endforeach; ?>
					</ul>
				</div>

				<?php if ( current_user_can( 'wooin_delete_inquiries' ) ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('이 상담을 완전히 삭제할까요? 되돌릴 수 없습니다. (삭제했다는 기록만 남습니다)')">
					<input type="hidden" name="action" value="wooin_consult_action">
					<input type="hidden" name="id" value="<?php echo (int) $row['id']; ?>">
					<?php wp_nonce_field( 'wooin_consult_' . $row['id'] ); ?>
					<button class="button-link wooin-danger" name="do" value="delete">이 상담 삭제</button>
				</form>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php
}

/* ---------------------------------------------------------------- 설정 */

add_action(
	'admin_post_wooin_consult_settings',
	static function () {
		if ( ! current_user_can( 'wooin_inquiry_settings' ) ) {
			wp_die( '권한이 없습니다.', 403 );
		}
		check_admin_referer( 'wooin_consult_settings' );
		$in    = wp_unslash( $_POST );
		$clean = static fn( $v ) => implode( ', ', array_filter( array_map( 'sanitize_email', preg_split( '/[\s,;]+/', (string) $v ) ), 'is_email' ) );
		update_option(
			WOOIN_CONSULT_SETTINGS,
			array(
				'emails_personal'  => $clean( $in['emails_personal'] ?? '' ),
				'emails_corporate' => $clean( $in['emails_corporate'] ?? '' ),
				'mail_phone'       => ! empty( $in['mail_phone'] ),
				'retention_days'   => max( 30, min( 3650, absint( $in['retention_days'] ?? 365 ) ) ),
				'auto_purge'       => ! empty( $in['auto_purge'] ),
				'consent_version'  => sanitize_text_field( $in['consent_version'] ?? '' ),
				'paused'           => ! empty( $in['paused'] ),
			),
			false
		);
		$notice = 'saved';
		if ( ! empty( $in['test'] ) ) {
			$to     = array_unique( array_merge( wooin_consult_recipients( 'personal' ), wooin_consult_recipients( 'corporate' ) ) );
			$notice = $to && wp_mail( $to, '[우인 홈페이지] 상담 알림 테스트', "상담 알림 메일이 정상적으로 도착했습니다.\n이 메일은 「상담 관리 › 알림 · 보관 설정」에서 보낸 테스트입니다." ) ? 'test_ok' : 'test_fail';
		}
		wp_safe_redirect( admin_url( 'admin.php?page=wooin-consult-settings&notice=' . $notice ) );
		exit;
	}
);

function wooin_consult_render_settings(): void {
	if ( ! current_user_can( 'wooin_inquiry_settings' ) ) {
		return;
	}
	$s        = wooin_consult_settings();
	$notice   = sanitize_key( wp_unslash( $_GET['notice'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$messages = array( 'saved' => array( 'success', '저장했습니다.' ), 'test_ok' => array( 'success', '테스트 메일을 보냈습니다. 받은편지함(스팸함 포함)을 확인하세요.' ), 'test_fail' => array( 'error', '테스트 메일을 보내지 못했습니다. 이메일 주소를 확인하고, 「추천 플러그인」의 WP Mail SMTP 로 메일 계정을 연결하세요.' ) );
	?>
	<div class="wrap wooin-admin wooin-consult">
		<?php wooin_consult_header( '알림 · 보관 설정', '상담이 들어오면 누구에게 알릴지, 얼마나 보관할지 정합니다.' ); ?>
		<?php if ( isset( $messages[ $notice ] ) ) : ?><div class="notice notice-<?php echo esc_attr( $messages[ $notice ][0] ); ?> is-dismissible"><p><?php echo esc_html( $messages[ $notice ][1] ); ?></p></div><?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="wooin_consult_settings">
			<?php wp_nonce_field( 'wooin_consult_settings' ); ?>
			<div class="wooin-card">
				<h3>알림 메일 받을 사람</h3>
				<div class="wooin-field"><label for="wc-ep">개인회생·파산 상담</label><input id="wc-ep" class="large-text" name="emails_personal" value="<?php echo esc_attr( $s['emails_personal'] ); ?>" placeholder="a@example.com, b@example.com"><p class="description">여러 명이면 쉼표로 구분합니다.</p></div>
				<div class="wooin-field"><label for="wc-ec">법인회생·파산 상담</label><input id="wc-ec" class="large-text" name="emails_corporate" value="<?php echo esc_attr( $s['emails_corporate'] ); ?>"><p class="description">개인과 같은 사람이면 같은 주소를 넣으세요.</p></div>
				<div class="wooin-field"><label class="wooin-inline"><input type="checkbox" name="mail_phone" value="1" <?php checked( $s['mail_phone'] ); ?>> 알림 메일에 신청인 연락처 포함</label><p class="description">기본은 끔 — 메일에는 접수번호·구분·상담 항목·가린 이름만 가고, 연락처와 내용은 관리자 화면에서 봅니다. 휴대폰 메일로 바로 전화하려면 켜세요(메일이 유출되면 연락처도 함께 노출됩니다).</p></div>
			</div>
			<div class="wooin-card">
				<h3>보관</h3>
				<div class="wooin-field"><label for="wc-days">보유기간 (일)</label><input id="wc-days" type="number" min="30" max="3650" name="retention_days" value="<?php echo (int) $s['retention_days']; ?>" style="width:120px"><p class="description">상담폼 동의 문구의 보유기간(현재 「수집일로부터 1년」)과 같아야 합니다. 바꾸면 동의 문구와 개인정보처리방침도 함께 고치세요.</p></div>
				<div class="wooin-field"><label class="wooin-inline"><input type="checkbox" name="auto_purge" value="1" <?php checked( $s['auto_purge'] ); ?>> 보유기간이 지난 상담 매일 자동 삭제</label></div>
				<div class="wooin-field"><label for="wc-cv">동의 문구 버전</label><input id="wc-cv" class="regular-text" name="consent_version" value="<?php echo esc_attr( $s['consent_version'] ); ?>"><p class="description">동의 문구나 개인정보처리방침을 바꾸면 버전을 새로 적으세요. 상담마다 어느 버전에 동의했는지 기록됩니다.</p></div>
			</div>
			<div class="wooin-card">
				<h3>접수 일시 중지</h3>
				<div class="wooin-field"><label class="wooin-inline"><input type="checkbox" name="paused" value="1" <?php checked( $s['paused'] ); ?>> 온라인 접수 잠시 멈춤</label><p class="description">켜면 신청 버튼을 눌러도 저장되지 않고 「전화로 문의」 안내가 나옵니다.</p></div>
			</div>
			<p><button class="button button-primary button-large">저장</button> <button class="button button-large" name="test" value="1">저장 후 테스트 메일 보내기</button></p>
		</form>
	</div>
	<?php
}
