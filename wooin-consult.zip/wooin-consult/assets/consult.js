// 상담폼 전송 — 테마 폼([data-wooin-consult])의 입력값을 모아 접수 API 로 보낸다.
( function () {
	var cfg = window.wooinConsult;
	var form = document.querySelector( '[data-wooin-consult]' );
	if ( ! cfg || ! form ) {
		return;
	}
	var started = Date.now();
	var idem = ( window.crypto && crypto.randomUUID ) ? crypto.randomUUID() : String( Date.now() ) + Math.random().toString( 16 ).slice( 2 );
	var status = form.querySelector( '.wooin-form-status' );
	var button = form.querySelector( '.wooin-form-submit' );
	var busy = false;

	function collect() {
		var data = {};
		new FormData( form ).forEach( function ( value, name ) {
			if ( name.slice( -2 ) === '[]' ) {
				name = name.slice( 0, -2 );
				( data[ name ] = data[ name ] || [] ).push( value );
			} else {
				data[ name ] = value;
			}
		} );
		data.elapsed = Date.now() - started;
		data.idem = idem;
		data.page = location.href.split( '#' )[ 0 ];
		data.ref = document.referrer;
		return data;
	}

	function say( text, kind ) {
		status.textContent = text;
		status.classList.toggle( 'is-error', kind === 'error' );
		status.classList.toggle( 'is-ok', kind === 'ok' );
	}

	// 접수 완료 팝업 (Esc · 바깥 누르기 · 확인 버튼으로 닫힘, 닫으면 폼의 완료 안내로 초점 이동)
	function popup( bodyNode ) {
		var dlg = document.createElement( 'dialog' );
		dlg.className = 'wooin-popup';
		dlg.setAttribute( 'aria-labelledby', 'wooin-popup-title' );
		var icon = document.createElement( 'span' );
		icon.className = 'wooin-popup-icon';
		icon.setAttribute( 'aria-hidden', 'true' );
		icon.textContent = '✓';
		var h = document.createElement( 'h2' );
		h.id = 'wooin-popup-title';
		h.textContent = '상담 신청이 정상적으로 접수되었습니다';
		bodyNode.className = 'wooin-popup-body';
		var ok = document.createElement( 'button' );
		ok.type = 'button';
		ok.className = 'wooin-popup-ok';
		ok.textContent = '확인';
		dlg.appendChild( icon );
		dlg.appendChild( h );
		dlg.appendChild( bodyNode );
		dlg.appendChild( ok );
		document.body.appendChild( dlg );
		function close() { if ( dlg.open ) { dlg.close(); } }
		ok.addEventListener( 'click', close );
		dlg.addEventListener( 'click', function ( e ) { if ( e.target === dlg ) { close(); } } );
		dlg.addEventListener( 'close', function () {
			dlg.remove();
			var done = form.querySelector( '.wooin-form-done' );
			if ( done ) { done.focus(); }
		} );
		if ( dlg.showModal ) {
			dlg.showModal();
			ok.focus();
		} else {
			window.alert( h.textContent + '\n' + bodyNode.textContent );
			dlg.remove();
		}
	}

	form.addEventListener( 'submit', function ( e ) {
		e.preventDefault();
		e.stopImmediatePropagation();
		if ( busy ) {
			return;
		}
		if ( ! form.checkValidity() ) {
			var bad = form.querySelector( ':invalid' );
			say( '필수 항목을 확인해 주세요.', 'error' );
			if ( bad ) { bad.focus(); }
			return;
		}
		busy = true;
		button.disabled = true;
		say( '접수하는 중입니다…' );

		fetch( cfg.endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify( collect() ), credentials: 'same-origin' } )
			.then( function ( r ) { return r.json().catch( function () { return { ok: false }; } ); } )
			.then( function ( res ) {
				if ( res && res.ok ) {
					form.classList.add( 'is-sent' );
					var done = document.createElement( 'div' );
					done.className = 'wooin-form-done';
					done.setAttribute( 'role', 'status' );
					done.setAttribute( 'tabindex', '-1' );
					var title = document.createElement( 'p' );
					title.className = 'wooin-form-done-title';
					title.textContent = '신청이 접수되었습니다';
					var body = document.createElement( 'p' );
					var msg = res.message || '';
					var at = res.number ? msg.indexOf( res.number ) : -1;
					if ( at >= 0 ) {
						var num = document.createElement( 'strong' );
						num.className = 'wooin-form-number';
						num.textContent = res.number;
						body.appendChild( document.createTextNode( msg.slice( 0, at ) ) );
						body.appendChild( num );
						body.appendChild( document.createTextNode( msg.slice( at + res.number.length ) ) );
					} else {
						body.textContent = msg;
					}
					done.appendChild( title );
					done.appendChild( body );
					form.appendChild( done );
					say( '' );
					popup( body.cloneNode( true ) );
					if ( window.gtag ) { window.gtag( 'event', 'generate_lead', { form_track: form.querySelector( 'input[name="track"]' ).value } ); }
				} else {
					say( ( res && res.message ) || ( '접수하지 못했습니다. 잠시 후 다시 시도해 주세요.' + ( cfg.phone ? ' 급하시면 ' + cfg.phone + '로 전화 주세요.' : '' ) ), 'error' );
					button.disabled = false;
					busy = false;
				}
			} )
			.catch( function () {
				say( '인터넷 연결을 확인한 뒤 다시 눌러 주세요.' + ( cfg.phone ? ' 급하시면 ' + cfg.phone + '로 전화 주세요.' : '' ), 'error' );
				button.disabled = false;
				busy = false;
			} );
	}, true );
} )();
