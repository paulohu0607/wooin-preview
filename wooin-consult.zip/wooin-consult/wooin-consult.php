<?php
/**
 * Plugin Name: Wooin Consult
 * Description: 법률사무소 우인 상담 접수 — 비공개 저장 · 접수번호(P-/C-) · 개인/법인 알림 분리 · 관리자 처리(상태·담당자·메모·기록). 상담 내용은 공개 화면·피드·사이트맵·REST 조회에 나오지 않습니다.
 * Version: 0.1.4
 * Requires at least: 6.6
 * Requires PHP: 8.0
 * Requires Plugins: wooin-core
 * Author: 법률사무소 우인 제작팀
 * License: Proprietary
 * Text Domain: wooin-consult
 *
 * 저장은 글(post)이 아닌 전용 표 두 개 — 공개 조회 경로가 처음부터 없다.
 *   {prefix}wooin_inquiries     접수 1건 = 1줄 (입력값은 data 열에 JSON)
 *   {prefix}wooin_inquiry_log   열람·배정·상태·메모·알림·삭제 기록 (상담 원문은 남기지 않음)
 * 권한 이름은 wooin-core capabilities.php 에 정의.
 *
 * @package wooin-consult
 */

defined( 'ABSPATH' ) || exit;

const WOOIN_CONSULT_VERSION = '0.1.4';
const WOOIN_CONSULT_DB      = '1';
const WOOIN_CONSULT_FILE    = __FILE__;
const WOOIN_CONSULT_CRON    = 'wooin_consult_daily';

require_once __DIR__ . '/includes/fields.php';
require_once __DIR__ . '/includes/store.php';
require_once __DIR__ . '/includes/notify.php';
require_once __DIR__ . '/includes/submit.php';
require_once __DIR__ . '/includes/admin.php';

register_activation_hook(
	__FILE__,
	static function () {
		wooin_consult_install();
		if ( ! wp_next_scheduled( WOOIN_CONSULT_CRON ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', WOOIN_CONSULT_CRON );
		}
	}
);

register_deactivation_hook(
	__FILE__,
	static function () {
		wp_clear_scheduled_hook( WOOIN_CONSULT_CRON );
	}
);

// zip 으로 교체 업로드하면 활성화 훅이 다시 돌지 않으므로 버전을 보고 표를 맞춘다.
add_action(
	'plugins_loaded',
	static function () {
		if ( get_option( 'wooin_consult_db' ) !== WOOIN_CONSULT_DB ) {
			wooin_consult_install();
		}
		if ( ! wp_next_scheduled( WOOIN_CONSULT_CRON ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', WOOIN_CONSULT_CRON );
		}
	}
);

add_action( WOOIN_CONSULT_CRON, 'wooin_consult_daily' );

/** 매일: 보유기간 지난 접수 삭제 · 실패한 알림 다시 보내기. */
function wooin_consult_daily(): void {
	wooin_consult_purge_expired();
	wooin_consult_retry_failed();
}
